/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: '#0B1B45', 900: '#071230', 700: '#1B2E63', 500: '#4A5A85', 300: '#93A0C2' },
        brand: { DEFAULT: '#D81F2A', dark: '#AE1520', soft: '#FDECEE' },
        mist: { DEFAULT: '#F3F5FA', line: '#E1E6F0' },
        ok: { DEFAULT: '#0E8A5A', soft: '#E4F5EC' },
        wait: { DEFAULT: '#B26A00', soft: '#FFF3DC' },
      },
      fontFamily: { sans: ['"Anek Latin Variable"', '"Anek Devanagari Variable"', 'system-ui', 'sans-serif'] },
      boxShadow: { card: '0 1px 2px rgba(11,27,69,.06), 0 8px 24px -12px rgba(11,27,69,.18)', lift: '0 2px 4px rgba(11,27,69,.08), 0 18px 40px -16px rgba(11,27,69,.30)' },
      borderRadius: { xl2: '1.25rem' },
      keyframes: { blip: { '0%,80%,100%': { opacity: '.25', transform: 'translateY(0)' }, '40%': { opacity: '1', transform: 'translateY(-3px)' } }, rise: { from: { opacity: '0', transform: 'translateY(6px)' }, to: { opacity: '1', transform: 'none' } } },
      animation: { blip: 'blip 1.2s infinite', rise: 'rise .25s ease-out both' },
    },
  },
  plugins: [],
};
