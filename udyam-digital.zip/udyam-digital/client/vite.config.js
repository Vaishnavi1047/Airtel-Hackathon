import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The website runs on http://localhost:5173 and forwards every /api call to the server on port 4000.
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, host: true, proxy: { '/api': { target: process.env.VITE_API_TARGET || 'http://localhost:4000', changeOrigin: true } } },
});
