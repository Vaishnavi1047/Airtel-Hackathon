import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { MessagesSquare, LayoutGrid, PackageSearch, BarChart3, Check } from 'lucide-react';
import { Logo } from './ui.jsx';
import { useApp } from '../lib/store.jsx';

const NAV = [
  { to: '/advisor', en: 'Advisor', hi: 'सलाहकार', Icon: MessagesSquare },
  { to: '/catalogue', en: 'Plans', hi: 'प्लान', Icon: LayoutGrid },
  { to: '/track', en: 'Track order', hi: 'ऑर्डर ट्रैक', Icon: PackageSearch },
  { to: '/partner', en: 'Partner', hi: 'पार्टनर', Icon: BarChart3 },
];

const JOURNEY = [
  { match: ['/advisor'], en: 'Advisor', hi: 'सलाह' },
  { match: ['/bundle'], en: 'Bundle', hi: 'बंडल' },
  { match: ['/checkout', '/confirmation'], en: 'Checkout', hi: 'चेकआउट' },
  { match: ['/kyc'], en: 'KYC', hi: 'KYC' },
  { match: ['/track/'], en: 'Track', hi: 'ट्रैक' },
];

// The one-sitting journey shown as a line with five stops, like a route map.
function JourneyRail() {
  const { pathname } = useLocation();
  const { tr } = useApp();
  const current = JOURNEY.findIndex((s) => s.match.some((m) => pathname.startsWith(m)));
  if (current < 0) return null;
  return (
    <div className="no-print border-b border-mist-line bg-white">
      <div className="mx-auto max-w-6xl px-4 py-3 sm:px-6">
        <p className="mb-2 text-sm font-medium text-ink-500 sm:hidden">{tr('Step', 'चरण')} {current + 1} / {JOURNEY.length}: <span className="text-ink">{tr(JOURNEY[current].en, JOURNEY[current].hi)}</span></p>
        <ol className="flex items-center" aria-label="Your progress">
          {JOURNEY.map((s, i) => {
            const state = i < current ? 'done' : i === current ? 'current' : 'next';
            return (
              <li key={s.en} className={`flex items-center ${i < JOURNEY.length - 1 ? 'flex-1' : ''}`} aria-current={state === 'current' ? 'step' : undefined}>
                <span className="flex items-center gap-2">
                  <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 text-xs font-bold ${state === 'done' ? 'border-brand bg-brand text-white' : state === 'current' ? 'border-brand bg-white text-brand ring-4 ring-brand/15' : 'border-mist-line bg-white text-ink-300'}`}>
                    {state === 'done' ? <Check className="h-3.5 w-3.5" strokeWidth={3} /> : i + 1}
                  </span>
                  <span className={`hidden text-[15px] sm:inline ${state === 'next' ? 'text-ink-300' : 'font-semibold text-ink'}`}>{tr(s.en, s.hi)}</span>
                </span>
                {i < JOURNEY.length - 1 && <span className={`mx-2 h-0.5 flex-1 rounded sm:mx-3 ${i < current ? 'bg-brand' : 'bg-mist-line'}`} />}
              </li>
            );
          })}
        </ol>
      </div>
    </div>
  );
}

function LangToggle() {
  const { lang, setLang } = useApp();
  return (
    <div className="inline-flex rounded-full border border-mist-line bg-white p-0.5 text-sm font-semibold" role="group" aria-label="Language">
      {[['en', 'English'], ['hi', 'हिंदी']].map(([code, label]) => (
        <button key={code} onClick={() => setLang(code)} aria-pressed={lang === code} className={`rounded-full px-3 py-1.5 transition-colors ${lang === code ? 'bg-ink text-white' : 'text-ink-500 hover:text-ink'}`}>{label}</button>
      ))}
    </div>
  );
}

export default function Layout() {
  const { tr } = useApp();
  return (
    <div className="flex min-h-screen flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-white focus:px-3 focus:py-2">Skip to content</a>
      <header className="no-print sticky top-0 z-40 border-b border-mist-line bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <Link to="/" aria-label="Udyam Digital home"><Logo /></Link>
          <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
            {NAV.map((n) => (
              <NavLink key={n.to} to={n.to} className={({ isActive }) => `rounded-full px-4 py-2 text-[15px] font-medium transition-colors ${isActive ? 'bg-mist text-ink' : 'text-ink-500 hover:text-ink'}`}>{tr(n.en, n.hi)}</NavLink>
            ))}
          </nav>
          <LangToggle />
        </div>
      </header>
      <JourneyRail />
      <main id="main" className="flex-1 pb-24 md:pb-10"><Outlet /></main>
      <footer className="no-print hidden border-t border-mist-line bg-white md:block">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-6 py-5 text-sm text-ink-500">
          <span>Hackathon prototype built on synthetic data. Not a live telecom service. Payments and KYC checks are simulated.</span>
          <span>Udyam Digital</span>
        </div>
      </footer>
      <nav className="no-print fixed inset-x-0 bottom-0 z-40 border-t border-mist-line bg-white pb-[env(safe-area-inset-bottom)] md:hidden" aria-label="Main">
        <div className="grid grid-cols-4">
          {NAV.map(({ to, en, hi, Icon }) => (
            <NavLink key={to} to={to} className={({ isActive }) => `flex flex-col items-center gap-0.5 py-2.5 text-xs font-medium ${isActive ? 'text-brand' : 'text-ink-500'}`}>
              <Icon className="h-5 w-5" aria-hidden="true" />{tr(en, hi)}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}
