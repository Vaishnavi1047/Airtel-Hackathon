import { AlertTriangle, CheckCircle2, Clock3, Info, Loader2, XCircle, MinusCircle } from 'lucide-react';

export function Logo({ light = false, size = 36 }) {
  return (
    <span className="inline-flex items-center gap-2.5">
      <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
        <rect width="32" height="32" rx="9" fill="#D81F2A" />
        <path d="M9 9v8a7 7 0 0 0 14 0V9" fill="none" stroke="#fff" strokeWidth="3.2" strokeLinecap="round" />
        <circle cx="16" cy="10" r="2.2" fill="#fff" />
      </svg>
      <span className={`text-[21px] font-bold leading-none tracking-tight ${light ? 'text-white' : 'text-ink'}`}>
        Udyam <span className="font-medium">Digital</span>
      </span>
    </span>
  );
}

export const Spinner = ({ label = 'Loading' }) => (
  <span className="inline-flex items-center gap-2 text-ink-500" role="status"><Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />{label}</span>
);

export function PageLoader({ label }) {
  return <div className="flex min-h-[40vh] items-center justify-center"><Spinner label={label} /></div>;
}

const TONES = {
  error: { cls: 'border-brand/30 bg-brand-soft text-brand-dark', Icon: XCircle },
  warn: { cls: 'border-wait/30 bg-wait-soft text-wait', Icon: AlertTriangle },
  ok: { cls: 'border-ok/30 bg-ok-soft text-ok', Icon: CheckCircle2 },
  info: { cls: 'border-ink-300/50 bg-white text-ink-700', Icon: Info },
};
export function Alert({ tone = 'info', title, children, details, className = '' }) {
  const { cls, Icon } = TONES[tone];
  return (
    <div role={tone === 'error' ? 'alert' : 'status'} className={`flex gap-3 rounded-xl border px-4 py-3 ${cls} ${className}`}>
      <Icon className="mt-0.5 h-5 w-5 shrink-0" aria-hidden="true" />
      <div className="min-w-0 text-[15px]">
        {title && <p className="font-semibold">{title}</p>}
        {children && <div>{children}</div>}
        {details?.length > 0 && <ul className="mt-1 list-disc pl-5">{details.map((d, i) => <li key={i}>{d}</li>)}</ul>}
      </div>
    </div>
  );
}

const STATUS = {
  Verified: ['bg-ok-soft text-ok', CheckCircle2], Approved: ['bg-ok-soft text-ok', CheckCircle2], Given: ['bg-ok-soft text-ok', CheckCircle2],
  Pending: ['bg-wait-soft text-wait', Clock3], 'In progress': ['bg-wait-soft text-wait', Clock3], 'Not started': ['bg-mist text-ink-500', MinusCircle], 'Not given': ['bg-mist text-ink-500', MinusCircle],
  Skipped: ['bg-mist text-ink-500', MinusCircle],
  Mismatch: ['bg-brand-soft text-brand-dark', AlertTriangle], 'Action needed': ['bg-brand-soft text-brand-dark', AlertTriangle], Rejected: ['bg-brand-soft text-brand-dark', XCircle],
};
export function StatusBadge({ status, className = '' }) {
  const [cls, Icon] = STATUS[status] || STATUS['Not started'];
  return <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1 text-sm font-semibold ${cls} ${className}`}><Icon className="h-4 w-4" aria-hidden="true" />{status}</span>;
}

export function CheckList({ checks = [] }) {
  const icon = { pass: <CheckCircle2 className="h-4 w-4 text-ok" />, fail: <XCircle className="h-4 w-4 text-brand" />, warn: <AlertTriangle className="h-4 w-4 text-wait" />, info: <Info className="h-4 w-4 text-ink-500" /> };
  return (
    <ul className="space-y-1.5">
      {checks.map((c, i) => (
        <li key={i} className="flex gap-2 text-[15px]">
          <span className="mt-1 shrink-0" aria-label={c.result}>{icon[c.result]}</span>
          <span><span className="font-medium">{c.label}:</span> <span className="text-ink-700">{c.detail}</span></span>
        </li>
      ))}
    </ul>
  );
}

export function Modal({ title, onClose, children, wide = false }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink-900/50 p-0 sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-white p-5 shadow-lift sm:rounded-3xl sm:p-7 ${wide ? 'sm:max-w-3xl' : 'sm:max-w-lg'} animate-rise`}>
        <div className="mb-4 flex items-start justify-between gap-4">
          <h2 className="text-xl">{title}</h2>
          <button onClick={onClose} className="-mr-1 -mt-1 rounded-full p-2 text-ink-500 hover:bg-mist" aria-label="Close"><XCircle className="h-6 w-6" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export const DemoTag = ({ children = 'Demo' }) => <span className="rounded-md bg-wait-soft px-2 py-0.5 text-xs font-semibold text-wait">{children}</span>;
