import { inr } from '../lib/format.js';
import { useApp } from '../lib/store.jsx';

// The transparent price breakdown used on the bundle, checkout and confirmation screens.
export default function PriceSummary({ quote, compact = false }) {
  const { tr } = useApp();
  if (!quote) return null;
  const t = quote.totals;
  const Row = ({ label, value, strong, sub }) => (
    <div className={`flex items-baseline justify-between gap-4 ${strong ? 'text-lg font-bold' : ''}`}>
      <dt className={strong ? '' : 'text-ink-700'}>{label}{sub && <span className="block text-sm font-normal text-ink-500">{sub}</span>}</dt>
      <dd className="shrink-0 tabular-nums">{value}</dd>
    </div>
  );
  return (
    <dl className="space-y-2.5">
      {!compact && quote.lines.map((l) => <Row key={l.productId} label={`${l.name} × ${l.qty}`} sub={`${inr(l.unitPrice)} ${l.unit}`} value={inr(l.monthly)} />)}
      {!compact && <div className="border-t border-mist-line" />}
      {t.monthlySavings > 0 && <Row label={tr('If bought separately (list price)', 'अलग-अलग लेने पर (लिस्ट कीमत)')} value={<s className="text-ink-500">{inr(t.listMonthly)}</s>} />}
      <Row strong label={tr('Monthly charges', 'मासिक शुल्क')} value={inr(t.monthly)} />
      {t.monthlySavings > 0 && <p className="rounded-lg bg-ok-soft px-3 py-2 text-[15px] font-semibold text-ok">{tr('You save', 'आपकी बचत')} {inr(t.monthlySavings)} {tr('every month with bundle pricing', 'हर महीने, बंडल कीमत से')}</p>}
      <Row label={tr('One-time setup fee', 'एक बार की सेटअप फ़ीस')} value={inr(t.setup)} />
      <Row label={tr('Minimum contract', 'न्यूनतम कॉन्ट्रैक्ट')} value={`${t.contractMonths} ${tr('months', 'महीने')}`} />
      <Row label={tr('Typical time to go live', 'चालू होने में आम तौर पर')} value={`${t.installDays} ${tr('days after KYC', 'दिन (KYC के बाद)')}`} />
      <div className="border-t border-mist-line" />
      <Row strong label={tr('Pay today', 'आज का भुगतान')} sub={tr('First month + setup', 'पहला महीना + सेटअप')} value={inr(t.firstBill)} />
      <p className="text-sm text-ink-500">{tr('Prices are from the product catalogue and exclude taxes.', 'दाम प्रोडक्ट कैटलॉग से हैं, टैक्स अलग।')} {quote.pricePolicy.label}.</p>
    </dl>
  );
}
