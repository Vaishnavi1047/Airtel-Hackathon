import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Layout from './components/Layout.jsx';
import Landing from './pages/Landing.jsx';
import Advisor from './pages/Advisor.jsx';
import Bundle from './pages/Bundle.jsx';
import Catalogue from './pages/Catalogue.jsx';
import Checkout from './pages/Checkout.jsx';
import Confirmation from './pages/Confirmation.jsx';
import Kyc from './pages/Kyc.jsx';
import Tracker from './pages/Tracker.jsx';
import TrackLookup from './pages/TrackLookup.jsx';
import Partner from './pages/Partner.jsx';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Landing />} />
          <Route path="/advisor" element={<Advisor />} />
          <Route path="/bundle" element={<Bundle />} />
          <Route path="/catalogue" element={<Catalogue />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/confirmation/:orderId" element={<Confirmation />} />
          <Route path="/kyc/:orderId" element={<Kyc />} />
          <Route path="/track" element={<TrackLookup />} />
          <Route path="/track/:orderId" element={<Tracker />} />
          <Route path="/partner" element={<Partner />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </>
  );
}
