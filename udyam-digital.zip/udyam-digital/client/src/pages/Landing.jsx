import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, PlayCircle, ShieldCheck, FileX2, EyeOff, Store, Pill, Stethoscope, GraduationCap, UtensilsCrossed, Briefcase, Factory } from 'lucide-react';
import { api } from '../lib/api.js';
import { inr } from '../lib/format.js';
import { useApp } from '../lib/store.jsx';

const DEMO_PROFILE = { businessType: 'pharmacy', employees: 5, sites: 1, city: 'Lucknow', currentInternet: 'Home broadband', needs: ['internet', 'pos', 'cctv'], hasGstin: true };

// A phone showing the real advisor conversation. The bundle and price in the last bubble are fetched live from the catalogue engine.
function PhonePreview({ rec, tr }) {
  const opt = rec?.options.find((o) => o.key === rec.recommendedKey);
  const Bot = ({ children }) => <div className="max-w-[85%] rounded-2xl rounded-bl-md bg-white px-3.5 py-2.5 text-[15px] text-ink shadow-sm">{children}</div>;
  const Me = ({ children }) => <div className="ml-auto max-w-[80%] rounded-2xl rounded-br-md bg-ink px-3.5 py-2.5 text-[15px] text-white">{children}</div>;
  return (
    <div className="mx-auto w-full max-w-[340px] rounded-[2.4rem] border-[10px] border-ink-900 bg-mist shadow-lift" aria-label="Preview of the advisor conversation">
      <div className="flex items-center gap-2 rounded-t-[1.7rem] bg-ink px-4 py-3 text-white">
        <span className="h-2.5 w-2.5 rounded-full bg-ok" /><span className="text-[15px] font-semibold">{tr('Udyam advisor', 'उद्यम सलाहकार')}</span>
      </div>
      <div className="space-y-2.5 px-3 py-4">
        <Bot>{tr('What type of business do you operate?', 'आप किस तरह का कारोबार चलाते हैं?')}</Bot>
        <Me>{tr('Medical store, 5 people', 'मेडिकल स्टोर, 5 लोग')}</Me>
        <Bot>{tr('Which digital services do you need?', 'आपको कौन-सी डिजिटल सेवाएँ चाहिए?')}</Bot>
        <Me>{tr('Internet, UPI billing, CCTV', 'इंटरनेट, UPI बिलिंग, CCTV')}</Me>
        <div className="rounded-2xl rounded-bl-md border border-brand/20 bg-white p-3.5 shadow-sm">
          {opt ? (
            <>
              <p className="text-sm font-medium text-brand">{tr('Recommended for you', 'आपके लिए सुझाव')}</p>
              <p className="mt-0.5 text-lg font-semibold">{tr(opt.name.en, opt.name.hi)}</p>
              <ul className="mt-1.5 space-y-0.5 text-[15px] text-ink-700">{opt.quote.lines.map((l) => <li key={l.productId}>{l.name} × {l.qty}</li>)}</ul>
              <p className="mt-2 text-2xl font-bold">{inr(opt.quote.totals.monthly)}<span className="text-sm font-medium text-ink-500"> {tr('/ month', '/ माह')}</span></p>
              <p className="text-sm text-ink-500">{tr('Typically live in', 'आम तौर पर चालू')} {opt.quote.totals.installDays} {tr('days', 'दिन में')}</p>
            </>
          ) : <div className="h-36 animate-pulse rounded-xl bg-mist" />}
        </div>
      </div>
    </div>
  );
}

const WHO = [[Store, 'Kirana / Retail', 'किराना'], [Pill, 'Pharmacy', 'फार्मेसी'], [Stethoscope, 'Clinic', 'क्लिनिक'], [GraduationCap, 'Coaching', 'कोचिंग'], [UtensilsCrossed, 'Restaurant', 'रेस्टोरेंट'], [Briefcase, 'CA / Office', 'सीए / ऑफिस'], [Factory, 'Manufacturing', 'मैन्युफैक्चरिंग']];

export default function Landing() {
  const { tr } = useApp();
  const [rec, setRec] = useState(null);
  const [base, setBase] = useState(null);
  useEffect(() => {
    api.recommend(DEMO_PROFILE).then(setRec).catch(() => {});
    api.meta().then((m) => setBase(m.baseline)).catch(() => {});
  }, []);

  const steps = [
    [tr('Tell us about your business', 'अपने कारोबार के बारे में बताइए'), tr('Seven quick questions, in Hindi or English. Tap or speak your answers.', 'हिंदी या अंग्रेज़ी में सात छोटे सवाल। जवाब चुनें या बोलकर दें।')],
    [tr('See one clear price', 'एक साफ़ दाम देखिए'), tr('A bundle sized for your shop with monthly cost, setup fee and contract shown up front.', 'आपकी दुकान के हिसाब का बंडल, मासिक खर्च, सेटअप फ़ीस और कॉन्ट्रैक्ट पहले से साफ़।')],
    [tr('Verify from your phone', 'फ़ोन से ही वेरिफ़ाई करें'), tr('Enter your GSTIN, photograph your documents and get the result in seconds.', 'GSTIN डालें, दस्तावेज़ों की फ़ोटो लें और कुछ सेकंड में नतीजा पाएँ।')],
    [tr('Book installation and track it', 'इंस्टॉलेशन बुक करें और ट्रैक करें'), tr('Pick your own installation date and follow every stage until you are live.', 'अपनी पसंद की तारीख़ चुनें और सेवा चालू होने तक हर चरण देखें।')],
  ];

  return (
    <>
      <section className="bg-white">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-10 sm:px-6 md:grid-cols-[1.15fr_.85fr] md:py-16">
          <div>
            <p className="text-[15px] font-semibold text-brand">{tr('Where Small Businesses Meet Big Possibilities', 'जहाँ छोटे कारोबार को मिलती हैं बड़ी संभावनाएँ')}</p>
            <h1 className="mt-3 text-[2.5rem] font-bold leading-[1.05] sm:text-6xl">{tr('Get your business connected in one sitting.', 'एक ही बैठक में अपना कारोबार कनेक्ट करें।')}</h1>
            <p className="mt-5 max-w-xl text-lg text-ink-700">{tr('Internet, billing, CCTV and more for your shop or office. Answer a few questions, see a clear price, finish KYC on your phone and track installation. No sales visit needed.', 'आपकी दुकान या ऑफिस के लिए इंटरनेट, बिलिंग, CCTV और बहुत कुछ। कुछ सवालों के जवाब दें, साफ़ दाम देखें, फ़ोन पर KYC पूरा करें और इंस्टॉलेशन ट्रैक करें। सेल्स विज़िट की ज़रूरत नहीं।')}</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/advisor" className="btn-primary">{tr('Start with the advisor', 'सलाहकार से शुरू करें')}<ArrowRight className="h-5 w-5" aria-hidden="true" /></Link>
              <Link to="/advisor?demo=pharmacy" className="btn-ghost"><PlayCircle className="h-5 w-5" aria-hidden="true" />{tr('Play the medical-store demo', 'मेडिकल स्टोर डेमो चलाएँ')}</Link>
            </div>
            <div className="mt-8 flex flex-wrap gap-2">
              {WHO.map(([Icon, en, hi]) => <span key={en} className="inline-flex items-center gap-1.5 rounded-full bg-mist px-3 py-1.5 text-sm font-medium text-ink-700"><Icon className="h-4 w-4" aria-hidden="true" />{tr(en, hi)}</span>)}
            </div>
          </div>
          <PhonePreview rec={rec} tr={tr} />
        </div>
      </section>

      {base && (
        <section className="bg-ink text-white">
          <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
            <h2 className="max-w-2xl text-2xl text-white sm:text-3xl">{tr('Buying business services today is slow. Last quarter, out of 5,000 enquiries:', 'आज बिज़नेस सेवाएँ लेना धीमा है। पिछली तिमाही के 5,000 लीड में से:')}</h2>
            <dl className="mt-7 grid gap-6 sm:grid-cols-3">
              {[
                [`${base.avgActivationDays.toFixed(1)} ${tr('days', 'दिन')}`, tr('average wait from enquiry to a working connection', 'पूछताछ से कनेक्शन चालू होने तक औसत इंतज़ार')],
                [`${Math.round(base.avgFollowUpCalls)} ${tr('calls', 'कॉल')}`, tr('a customer makes to chase their own order', 'ग्राहक को अपने ही ऑर्डर के लिए करने पड़ते हैं')],
                [`${(base.conversionRate * 100).toFixed(2)}%`, tr(`of enquiries got connected (${base.activatedCustomers} of ${base.totalLeads.toLocaleString('en-IN')})`, `लीड ही कनेक्ट हो पाए (${base.totalLeads.toLocaleString('en-IN')} में से ${base.activatedCustomers})`)],
              ].map(([big, small]) => (
                <div key={small} className="border-l-2 border-brand pl-4">
                  <dt className="text-4xl font-bold">{big}</dt>
                  <dd className="mt-1 text-ink-300">{small}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-6 text-sm text-ink-300">{tr('Source: synthetic hackathon dataset (smb_leads.csv, Apr-Jun 2026).', 'स्रोत: हैकाथॉन का सिंथेटिक डेटा (smb_leads.csv, अप्रैल-जून 2026)।')}</p>
          </div>
        </section>
      )}

      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <h2 className="text-2xl sm:text-3xl">{tr('How one sitting works', 'एक बैठक में कैसे होता है')}</h2>
        <ol className="mt-7 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map(([title, body], i) => (
            <li key={title} className="relative">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand text-lg font-bold text-white">{i + 1}</span>
              <h3 className="mt-3 text-lg">{title}</h3>
              <p className="mt-1.5 text-ink-700">{body}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-12 sm:px-6">
        <div className="card grid gap-6 p-6 sm:grid-cols-3 sm:p-8">
          {[
            [ShieldCheck, tr('Consent comes first', 'पहले आपकी सहमति'), tr('Nothing is checked until you have read what we collect and agreed.', 'जब तक आप पढ़कर सहमति नहीं देते, कोई जाँच नहीं होती।')],
            [FileX2, tr('Document photos are not stored', 'दस्तावेज़ की फ़ोटो सेव नहीं होती'), tr('We read the few details we need and discard the image.', 'हम केवल ज़रूरी जानकारी पढ़ते हैं और फ़ोटो हटा देते हैं।')],
            [EyeOff, tr('Numbers stay masked', 'नंबर छिपे रहते हैं'), tr('GSTIN, Udyam and phone numbers are masked on screens and in logs.', 'GSTIN, उद्यम और फ़ोन नंबर स्क्रीन और लॉग में छिपे रहते हैं।')],
          ].map(([Icon, title, body]) => (
            <div key={title}>
              <Icon className="h-7 w-7 text-brand" aria-hidden="true" />
              <h3 className="mt-2 text-lg">{title}</h3>
              <p className="mt-1 text-ink-700">{body}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
