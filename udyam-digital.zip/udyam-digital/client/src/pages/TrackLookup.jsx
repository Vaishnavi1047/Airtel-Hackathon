import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, ChevronRight } from 'lucide-react';
import { useApp } from '../lib/store.jsx';
import { date } from '../lib/format.js';

export default function TrackLookup() {
  const { tr, orders, lang } = useApp();
  const navigate = useNavigate();
  const [id, setId] = useState('');
  const valid = /^UD-\d{6}-[A-Z0-9]{6}$/.test(id);
  return (
    <div className="mx-auto max-w-xl px-4 py-10 sm:px-6">
      <h1 className="text-3xl sm:text-4xl">{tr('Track your order', 'अपना ऑर्डर ट्रैक करें')}</h1>
      <p className="mt-2 text-ink-700">{tr('Enter the order ID from your confirmation screen.', 'कन्फ़र्मेशन स्क्रीन पर मिला ऑर्डर ID डालें।')}</p>
      <form className="mt-5 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (valid) navigate(`/track/${id}`); }}>
        <label className="sr-only" htmlFor="oid">Order ID</label>
        <input id="oid" className="field uppercase tracking-wide" placeholder="UD-000000-XXXXXX" value={id} onChange={(e) => setId(e.target.value.toUpperCase().trim().slice(0, 16))} autoComplete="off" />
        <button className="btn-primary shrink-0" disabled={!valid}><Search className="h-5 w-5" aria-hidden="true" />{tr('Track', 'ट्रैक')}</button>
      </form>
      {id && !valid && <p className="mt-2 text-sm text-ink-500">{tr('Order IDs look like UD-261120-AB12CD.', 'ऑर्डर ID ऐसा दिखता है: UD-261120-AB12CD')}</p>}

      <h2 className="mt-10 text-xl">{tr('Orders placed on this device', 'इस डिवाइस से किए गए ऑर्डर')}</h2>
      {orders.length === 0 ? (
        <div className="card mt-3 p-5"><p className="text-ink-700">{tr('No orders yet. The advisor can build your plan in about a minute.', 'अभी कोई ऑर्डर नहीं। सलाहकार एक मिनट में आपका प्लान बना सकता है।')}</p><Link to="/advisor" className="btn-dark btn-sm mt-3">{tr('Start with the advisor', 'सलाहकार से शुरू करें')}</Link></div>
      ) : (
        <ul className="card mt-3 divide-y divide-mist-line">
          {orders.map((o) => (
            <li key={o.orderId}><Link to={`/track/${o.orderId}`} className="flex items-center justify-between gap-3 px-5 py-4 hover:bg-mist"><span><span className="block font-semibold">{o.businessName}</span><span className="text-sm text-ink-500">{o.orderId}, {date(o.at, lang)}</span></span><ChevronRight className="h-5 w-5 text-ink-500" aria-hidden="true" /></Link></li>
          ))}
        </ul>
      )}
    </div>
  );
}
