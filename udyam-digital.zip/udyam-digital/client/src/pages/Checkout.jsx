import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Lock, Search, CreditCard } from 'lucide-react';
import { api } from '../lib/api.js';
import { inr } from '../lib/format.js';
import { useApp } from '../lib/store.jsx';
import { Alert, DemoTag, PageLoader, Spinner } from '../components/ui.jsx';
import PriceSummary from '../components/PriceSummary.jsx';

const RULES = {
  businessName: (v) => (v.trim().length >= 2 ? '' : 'Enter your business name.'),
  ownerName: (v) => (/^[\p{L}\p{M} .'-]{2,80}$/u.test(v.trim()) ? '' : 'Enter the owner\'s name (letters only).'),
  mobile: (v) => (/^[6-9]\d{9}$/.test(v) ? '' : 'Enter a 10-digit mobile number starting with 6, 7, 8 or 9.'),
  email: (v) => (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Enter a valid email address.'),
  address: (v) => (v.trim().length >= 10 ? '' : 'Enter the full business address (at least 10 characters).'),
};

function Field({ id, label, hint, error, children }) {
  return (
    <div>
      <label className="label" htmlFor={id}>{label}</label>
      {children}
      {error ? <p className="mt-1 text-sm font-medium text-brand" id={`${id}-err`}>{error}</p> : hint ? <p className="mt-1 text-sm text-ink-500">{hint}</p> : null}
    </div>
  );
}

export default function Checkout() {
  const { tr, cart, profile, bundleName, rememberOrder, clearJourney } = useApp();
  const navigate = useNavigate();
  const [form, setForm] = useState({ businessName: '', ownerName: '', mobile: '', email: '', address: '', city: profile?.city || '' });
  const [touched, setTouched] = useState({});
  const [quote, setQuote] = useState(null);
  const [meta, setMeta] = useState(null);
  const [samples, setSamples] = useState([]);
  const [gstin, setGstin] = useState('');
  const [lookup, setLookup] = useState({ state: 'idle' });
  const [agree, setAgree] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const p = profile || { cityTier: 2, employees: 1, sites: 1, hasGstin: false };

  useEffect(() => {
    if (!cart.length) return;
    api.quote(cart, p).then(setQuote).catch(setError);
    api.meta().then((m) => { setMeta(m); if (m.demoMode) api.demoApplicants().then(setSamples).catch(() => {}); }).catch(() => {});
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  if (!cart.length) return <div className="mx-auto max-w-xl px-4 py-16 text-center"><h1 className="text-3xl">{tr('Nothing to check out yet', 'चेकआउट के लिए अभी कुछ नहीं है')}</h1><Link to="/advisor" className="btn-primary mt-6">{tr('Start with the advisor', 'सलाहकार से शुरू करें')}</Link></div>;
  if (!quote && !error) return <PageLoader label={tr('Preparing your quotation', 'आपका कोटेशन तैयार हो रहा है')} />;

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: k === 'mobile' ? e.target.value.replace(/\D/g, '').slice(0, 10) : e.target.value }));
  const errs = Object.fromEntries(Object.entries(RULES).map(([k, fn]) => [k, fn(form[k])]));
  const formOk = Object.values(errs).every((e) => !e);

  const fillSample = (id) => {
    const s = samples.find((x) => x.id === id);
    if (!s) return;
    setForm({ businessName: s.businessName, ownerName: s.ownerName, mobile: `98765${String(10000 + (parseInt(id.slice(1), 10) || 0) + (id[0] === 'D' ? 500 : 0))}`, email: 'owner@example.com', address: s.address, city: s.city });
    setGstin(s.gstin || '');
  };
  const autofill = async () => {
    setLookup({ state: 'loading' });
    try {
      const r = await api.lookupGstin(gstin);
      setForm((f) => ({ ...f, businessName: r.tradeName, address: r.address, city: r.city || f.city }));
      setLookup({ state: 'ok', msg: `${tr('Filled from the mock GST registry. Registration status', 'मॉक GST रजिस्ट्री से भरा गया। स्थिति')}: ${r.status}.` });
    } catch (e) { setLookup({ state: 'err', msg: e.message }); }
  };

  const submit = async (e) => {
    e.preventDefault();
    setTouched({ businessName: true, ownerName: true, mobile: true, email: true, address: true });
    if (!formOk || !agree) return;
    setBusy(true); setError(null);
    try {
      const order = await api.createOrder({ ...form, businessType: profile?.businessType, bundleName: bundleName || 'Custom bundle', items: cart, profile: p, paymentConfirmed: true });
      rememberOrder(order);
      clearJourney();
      navigate(`/confirmation/${order.orderId}`, { replace: true });
    } catch (err) { setError(err); setBusy(false); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  };

  const input = (id, props = {}) => ({ id, className: `field ${touched[id] && errs[id] ? '!border-brand' : ''}`, value: form[id], onChange: set(id), onBlur: () => setTouched((t) => ({ ...t, [id]: true })), 'aria-invalid': Boolean(touched[id] && errs[id]), 'aria-describedby': touched[id] && errs[id] ? `${id}-err` : undefined, ...props });

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <h1 className="text-3xl sm:text-4xl">{tr('Quotation and checkout', 'कोटेशन और चेकआउट')}</h1>
      {error && <Alert tone="error" className="mt-4" title={error.message} details={error.details} />}
      <form onSubmit={submit} noValidate className="mt-6 grid gap-6 lg:grid-cols-[1fr_400px]">
        <div className="space-y-6">
          {meta?.demoMode && samples.length > 0 && (
            <div className="rounded-2xl border border-dashed border-wait/50 bg-wait-soft/60 p-4">
              <label className="label flex items-center gap-2" htmlFor="sample"><DemoTag /> {tr('Fill the form with a sample business from the hackathon data', 'हैकाथॉन डेटा के सैंपल कारोबार से फ़ॉर्म भरें')}</label>
              <select id="sample" className="field" defaultValue="" onChange={(e) => fillSample(e.target.value)}>
                <option value="" disabled>{tr('Choose a sample business', 'सैंपल कारोबार चुनें')}</option>
                {samples.map((s) => <option key={s.id} value={s.id}>{s.id}: {s.businessName}, {s.city}</option>)}
              </select>
            </div>
          )}

          <section className="card space-y-4 p-5">
            <h2 className="text-xl">{tr('Business details', 'कारोबार की जानकारी')}</h2>
            <div>
              <label className="label" htmlFor="gstin-fill">{tr('Have a GSTIN? Fill your details automatically (optional)', 'GSTIN है? जानकारी अपने-आप भरें (वैकल्पिक)')}</label>
              <div className="flex gap-2">
                <input id="gstin-fill" className="field uppercase" value={gstin} onChange={(e) => setGstin(e.target.value.toUpperCase().replace(/[^0-9A-Z]/g, '').slice(0, 15))} placeholder="15-character GSTIN" autoComplete="off" />
                <button type="button" onClick={autofill} disabled={gstin.length !== 15 || lookup.state === 'loading'} className="btn-ghost shrink-0"><Search className="h-4 w-4" aria-hidden="true" />{tr('Fill', 'भरें')}</button>
              </div>
              {lookup.msg && <p className={`mt-1 text-sm font-medium ${lookup.state === 'ok' ? 'text-ok' : 'text-brand'}`} role="status">{lookup.msg}</p>}
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="businessName" error={touched.businessName && errs.businessName} label={tr('Business name', 'कारोबार का नाम')}><input {...input('businessName', { autoComplete: 'organization', maxLength: 120 })} /></Field>
              <Field id="ownerName" error={touched.ownerName && errs.ownerName} label={tr('Owner name', 'मालिक का नाम')}><input {...input('ownerName', { autoComplete: 'name', maxLength: 80 })} /></Field>
              <Field id="mobile" error={touched.mobile && errs.mobile} label={tr('Mobile number', 'मोबाइल नंबर')} hint={tr('We send order updates here.', 'ऑर्डर की जानकारी इसी पर आएगी।')}><input {...input('mobile', { inputMode: 'numeric', autoComplete: 'tel-national', placeholder: '10 digits' })} /></Field>
              <Field id="email" error={touched.email && errs.email} label={tr('Email', 'ईमेल')}><input {...input('email', { type: 'email', autoComplete: 'email', maxLength: 120 })} /></Field>
            </div>
            <Field id="address" error={touched.address && errs.address} label={tr('Business address (where services will be installed)', 'कारोबार का पता (जहाँ सेवा लगेगी)')}><textarea {...input('address', { rows: 3, autoComplete: 'street-address', maxLength: 300 })} /></Field>
            <div className="sm:max-w-xs">
              <label className="label" htmlFor="city">{tr('City', 'शहर')}</label>
              <select id="city" className="field" value={form.city} onChange={set('city')}>
                <option value="">{tr('Other', 'अन्य')}</option>
                {(meta?.cities || []).map((c) => <option key={c.city} value={c.city}>{c.city}</option>)}
                {form.city && !(meta?.cities || []).some((c) => c.city === form.city) && <option value={form.city}>{form.city}</option>}
              </select>
            </div>
          </section>

          <section className="card space-y-4 p-5">
            <h2 className="flex items-center gap-2 text-xl"><CreditCard className="h-5 w-5" aria-hidden="true" />{tr('Payment', 'भुगतान')} <DemoTag>{tr('Demo payment', 'डेमो भुगतान')}</DemoTag></h2>
            <Alert tone="warn" title={tr('This is a simulated payment. No money is charged and no card or UPI details are collected.', 'यह नकली (डेमो) भुगतान है। कोई पैसा नहीं कटेगा और कार्ड या UPI की जानकारी नहीं ली जाएगी।')} />
            <label className="flex cursor-pointer items-start gap-3">
              <input type="checkbox" className="mt-1 h-5 w-5 accent-[#D81F2A]" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
              <span>{tr('I confirm this demo payment of', 'मैं इस डेमो भुगतान की पुष्टि करता/करती हूँ:')} <strong>{inr(quote.totals.firstBill)}</strong> {tr(`and a minimum ${quote.totals.contractMonths}-month contract.`, `और कम से कम ${quote.totals.contractMonths} महीने का कॉन्ट्रैक्ट।`)}</span>
            </label>
            {touched.address && !agree && <p className="text-sm font-medium text-brand">{tr('Tick the box to confirm the demo payment.', 'डेमो भुगतान की पुष्टि के लिए बॉक्स पर टिक करें।')}</p>}
          </section>
        </div>

        <aside className="h-fit lg:sticky lg:top-36">
          <div className="card p-5">
            <p className="text-sm font-medium text-ink-500">{tr('Selected bundle', 'चुना गया बंडल')}</p>
            <h2 className="text-xl">{bundleName || 'Custom bundle'}</h2>
            <div className="mt-4"><PriceSummary quote={quote} /></div>
            {!quote.valid && <Alert tone="warn" className="mt-4" title={tr('This bundle needs a change', 'इस बंडल में बदलाव ज़रूरी है')} details={quote.issues.map((i) => i.en)}><Link to="/bundle" className="font-semibold underline">{tr('Edit bundle', 'बंडल बदलें')}</Link></Alert>}
            <button type="submit" disabled={busy || !quote.valid} className="btn-primary mt-5 w-full">
              {busy ? <Spinner label={tr('Placing your order', 'ऑर्डर हो रहा है')} /> : <><Lock className="h-4 w-4" aria-hidden="true" />{tr('Pay', 'भुगतान करें')} {inr(quote.totals.firstBill)} {tr('(demo) and place order', '(डेमो) और ऑर्डर करें')}</>}
            </button>
            <Link to="/bundle" className="mt-3 block text-center font-medium text-ink-700 underline">{tr('Back to bundle', 'बंडल पर वापस')}</Link>
          </div>
        </aside>
      </form>
    </div>
  );
}
