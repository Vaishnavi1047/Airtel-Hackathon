import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Plus, Lock, Link2, ShoppingBag } from 'lucide-react';
import { api } from '../lib/api.js';
import { inr } from '../lib/format.js';
import { useApp } from '../lib/store.jsx';
import { Alert, PageLoader } from '../components/ui.jsx';

export default function Catalogue() {
  const { tr, lang, cart, setCart, profile, setBundleName, bundleName } = useApp();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [category, setCategory] = useState('All');

  useEffect(() => {
    const params = profile ? { cityTier: profile.cityTier, employees: profile.employees, sites: profile.sites, hasGstin: profile.hasGstin } : undefined;
    api.products(params).then(setData).catch(setError);
  }, [profile]);

  const inCart = useMemo(() => new Set(cart.map((c) => c.productId)), [cart]);
  const toggle = (p) => {
    setCart((c) => (inCart.has(p.id) ? c.filter((x) => x.productId !== p.id) : [...c, { productId: p.id, qty: 1 }]));
    if (!bundleName) setBundleName('Custom bundle');
  };

  if (error) return <div className="mx-auto max-w-3xl px-4 py-10"><Alert tone="error" title={error.message} /></div>;
  if (!data) return <PageLoader label={tr('Loading plans', 'प्लान लोड हो रहे हैं')} />;
  const list = data.products.filter((p) => category === 'All' || p.category === category);

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <h1 className="text-3xl sm:text-4xl">{tr('All plans and services', 'सभी प्लान और सेवाएँ')}</h1>
      <p className="mt-2 max-w-2xl text-ink-700">{tr(`${data.products.length} services with catalogue prices. ${profile ? 'Eligibility is shown for the business details you gave the advisor.' : 'Talk to the advisor to see which ones your business is eligible for.'}`, `${data.products.length} सेवाएँ, कैटलॉग दामों के साथ। ${profile ? 'पात्रता आपके दिए गए कारोबारी विवरण के हिसाब से दिखाई गई है।' : 'आपका कारोबार किनके लिए पात्र है, यह जानने के लिए सलाहकार से बात करें।'}`)}</p>

      <div className="mt-5 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label={tr('Categories', 'श्रेणियाँ')}>
        {['All', ...data.categories].map((c) => <button key={c} role="tab" aria-selected={category === c} onClick={() => setCategory(c)} className={`chip shrink-0 ${category === c ? 'chip-on' : ''}`}>{c === 'All' ? tr('All', 'सभी') : c}</button>)}
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((p) => {
          const el = p.eligibility;
          const blocked = el && !el.eligible;
          const added = inCart.has(p.id);
          return (
            <article key={p.id} className={`card flex flex-col p-5 ${blocked ? 'opacity-80' : ''}`}>
              <p className="text-sm font-medium text-ink-500">{p.category}</p>
              <h2 className="mt-0.5 text-xl">{p.name}</h2>
              <p className="mt-1 flex-1 text-[15px] text-ink-700">{p.description}</p>
              <p className="mt-3 text-2xl font-bold tabular-nums">{inr(p.priceMin)}{p.priceMax > p.priceMin && <span className="text-lg font-semibold text-ink-500"> – {inr(p.priceMax)}</span>}</p>
              <p className="text-sm text-ink-500">{p.unit}, {tr('per month', 'प्रति माह')}</p>
              <ul className="mt-3 space-y-1 text-[15px] text-ink-700">
                <li>{p.setupFee ? `${inr(p.setupFee)} ${tr('one-time setup', 'एक बार सेटअप')}` : tr('No setup fee', 'सेटअप फ़ीस नहीं')}, {p.minContractMonths} {tr('month minimum', 'माह न्यूनतम')}</li>
                <li>{tr('Typically installed in', 'आम तौर पर इंस्टॉल')} {p.installDays} {tr('day(s)', 'दिन में')}</li>
                {p.requiresGstin && <li className="flex items-center gap-1.5"><Lock className="h-3.5 w-3.5" aria-hidden="true" />{tr('Needs an active GSTIN', 'सक्रिय GSTIN ज़रूरी')}</li>}
                {(p.minEmployees > 1 || p.minSites > 1) && <li>{tr('For businesses with', 'ऐसे कारोबार के लिए')} {p.minEmployees > 1 ? `${p.minEmployees}+ ${tr('employees', 'कर्मचारी')}` : ''}{p.minEmployees > 1 && p.minSites > 1 ? ', ' : ''}{p.minSites > 1 ? `${p.minSites}+ ${tr('locations', 'लोकेशन')}` : ''}</li>}
                {p.cityTiers.length === 1 && <li>{tr('Tier', 'टियर')} {p.cityTiers[0]} {tr('cities only', 'शहरों में ही')}</li>}
                {p.requiresOneOf.length > 0 && <li className="flex gap-1.5"><Link2 className="mt-1 h-3.5 w-3.5 shrink-0" aria-hidden="true" /><span>{tr('Works with', 'इनके साथ चलता है')}: {p.requiresOneOf.map((r) => r.name).join(', ')}</span></li>}
              </ul>
              {blocked && <p className="mt-3 rounded-lg bg-wait-soft px-3 py-2 text-sm font-medium text-wait">{tr('Not available for your business', 'आपके कारोबार के लिए उपलब्ध नहीं')}: {el.reasons.map((r) => r[lang] || r.en).join('; ')}</p>}
              <button onClick={() => toggle(p)} disabled={blocked && !added} className={`mt-4 ${added ? 'btn-dark' : 'btn-ghost'} btn-sm`}>
                {added ? <><Check className="h-4 w-4" aria-hidden="true" />{tr('In your bundle', 'आपके बंडल में')}</> : <><Plus className="h-4 w-4" aria-hidden="true" />{tr('Add to bundle', 'बंडल में जोड़ें')}</>}
              </button>
            </article>
          );
        })}
      </div>

      {cart.length > 0 && (
        <div className="fixed inset-x-0 bottom-[57px] z-30 border-t border-mist-line bg-white px-4 py-3 shadow-lift md:bottom-0">
          <div className="mx-auto flex max-w-6xl items-center justify-between gap-3">
            <p className="font-medium">{cart.length} {tr('service(s) in your bundle', 'सेवाएँ आपके बंडल में')}</p>
            <button onClick={() => navigate('/bundle')} className="btn-primary btn-sm"><ShoppingBag className="h-4 w-4" aria-hidden="true" />{tr('View bundle', 'बंडल देखें')}</button>
          </div>
        </div>
      )}
      {cart.length > 0 && <div className="h-20" />}
    </div>
  );
}
