import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Copy, Check } from 'lucide-react';
import { api } from '../lib/api.js';
import { inr, date } from '../lib/format.js';
import { useApp } from '../lib/store.jsx';
import { Alert, DemoTag, PageLoader } from '../components/ui.jsx';

export default function Confirmation() {
  const { orderId } = useParams();
  const { tr, lang } = useApp();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);
  const [seconds, setSeconds] = useState(10);
  const [auto, setAuto] = useState(true);

  useEffect(() => { api.order(orderId).then(setOrder).catch(setError); }, [orderId]);
  // After a short pause the customer is taken to KYC automatically (they can stay on this page instead).
  useEffect(() => {
    if (!order || !auto) return undefined;
    if (seconds <= 0) { navigate(`/kyc/${order.orderId}`); return undefined; }
    const t = setTimeout(() => setSeconds((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [order, auto, seconds, navigate]);

  if (error) return <div className="mx-auto max-w-xl px-4 py-10"><Alert tone="error" title={error.message} /><Link to="/track" className="btn-ghost mt-4">{tr('Find my order', 'मेरा ऑर्डर ढूँढें')}</Link></div>;
  if (!order) return <PageLoader label={tr('Loading your order', 'ऑर्डर लोड हो रहा है')} />;
  const copy = async () => { try { await navigator.clipboard.writeText(order.orderId); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { /* clipboard blocked: the ID is still visible on screen */ } };

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-6">
      <div className="card overflow-hidden">
        <div className="bg-ink px-6 py-7 text-center text-white">
          <CheckCircle2 className="mx-auto h-12 w-12 text-[#5BE0A5]" aria-hidden="true" />
          <h1 className="mt-3 text-3xl text-white">{tr('Order placed', 'ऑर्डर हो गया')}</h1>
          <p className="mt-1 text-ink-300">{tr('Thank you', 'धन्यवाद')}, {order.ownerName}. {tr('One step left: verify your business.', 'बस एक कदम बाकी: अपने कारोबार को वेरिफ़ाई करें।')}</p>
        </div>
        <div className="space-y-5 p-6">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-mist p-4">
            <div><p className="text-sm text-ink-500">{tr('Your order ID (save this to track your order)', 'आपका ऑर्डर ID (ट्रैक करने के लिए सँभालकर रखें)')}</p><p className="text-2xl font-bold tracking-wide">{order.orderId}</p></div>
            <button onClick={copy} className="btn-ghost btn-sm">{copied ? <><Check className="h-4 w-4 text-ok" />{tr('Copied', 'कॉपी हो गया')}</> : <><Copy className="h-4 w-4" />{tr('Copy', 'कॉपी')}</>}</button>
          </div>
          <dl className="grid gap-4 sm:grid-cols-2">
            <div><dt className="text-sm text-ink-500">{tr('Business', 'कारोबार')}</dt><dd className="font-semibold">{order.businessName}</dd></div>
            <div><dt className="text-sm text-ink-500">{tr('Bundle', 'बंडल')}</dt><dd className="font-semibold">{order.bundleName}</dd></div>
            <div><dt className="text-sm text-ink-500">{tr('Monthly charges', 'मासिक शुल्क')}</dt><dd className="font-semibold">{inr(order.monthlyPrice)} {tr('for at least', 'कम से कम')} {order.contractDuration} {tr('months', 'महीने')}</dd></div>
            <div><dt className="text-sm text-ink-500">{tr('Expected activation', 'सेवा चालू होने की उम्मीद')}</dt><dd className="font-semibold">{date(order.expectedActivationDate, lang)}</dd></div>
            <div className="sm:col-span-2"><dt className="text-sm text-ink-500">{tr('Paid today', 'आज का भुगतान')} <DemoTag>{tr('Demo payment', 'डेमो भुगतान')}</DemoTag></dt><dd className="font-semibold">{inr(order.payment.amount)} <span className="font-normal text-ink-500">({tr('reference', 'संदर्भ')} {order.payment.reference}, {tr('no money charged', 'कोई पैसा नहीं कटा')})</span></dd></div>
          </dl>
          <ul className="divide-y divide-mist-line rounded-xl border border-mist-line">
            {order.selectedProducts.map((l) => <li key={l.productId} className="flex justify-between gap-3 px-4 py-2.5"><span>{l.name} × {l.qty}</span><span className="tabular-nums text-ink-700">{inr(l.monthly)}{tr('/mo', '/माह')}</span></li>)}
          </ul>
          <Link to={`/kyc/${order.orderId}`} className="btn-primary w-full">{tr('Continue to KYC (about 3 minutes)', 'KYC जारी रखें (लगभग 3 मिनट)')}<ArrowRight className="h-5 w-5" aria-hidden="true" /></Link>
          {auto ? <p className="text-center text-sm text-ink-500" role="status">{tr(`Taking you to KYC in ${seconds} seconds.`, `${seconds} सेकंड में KYC पर ले जा रहे हैं।`)} <button className="font-semibold underline" onClick={() => setAuto(false)}>{tr('Stay on this page', 'इसी पेज पर रहें')}</button></p>
            : <p className="text-center text-sm"><Link className="font-semibold underline" to={`/track/${order.orderId}`}>{tr('Or open the order tracker', 'या ऑर्डर ट्रैकर खोलें')}</Link></p>}
        </div>
      </div>
    </div>
  );
}
