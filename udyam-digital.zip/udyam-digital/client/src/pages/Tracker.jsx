import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Check, CalendarDays, LifeBuoy, FastForward, ChevronRight, RefreshCw, PartyPopper } from 'lucide-react';
import { api } from '../lib/api.js';
import { inr, date, dateTime } from '../lib/format.js';
import { useApp } from '../lib/store.jsx';
import { Alert, DemoTag, Modal, PageLoader, Spinner, StatusBadge } from '../components/ui.jsx';

const TOPICS = ['Where is my order?', 'Change installation date', 'KYC or document help', 'Billing question', 'Something else'];

function Timeline({ stages }) {
  const { tr } = useApp();
  return (
    <ol className="relative">
      {stages.map((s, i) => (
        <li key={s.status} className="relative flex gap-4 pb-7 last:pb-0" aria-current={s.state === 'current' ? 'step' : undefined}>
          {i < stages.length - 1 && <span className={`absolute left-[15px] top-8 h-[calc(100%-2rem)] w-0.5 ${s.state === 'done' ? 'bg-brand' : 'bg-mist-line'}`} aria-hidden="true" />}
          <span className={`z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-sm font-bold ${s.state === 'done' ? 'border-brand bg-brand text-white' : s.state === 'current' ? 'border-brand bg-white text-brand ring-4 ring-brand/15' : 'border-mist-line bg-white text-ink-300'}`}>
            {s.state === 'done' ? <Check className="h-4 w-4" strokeWidth={3} aria-label="Done" /> : i + 1}
          </span>
          <div className="min-w-0 pt-0.5">
            <p className={`text-lg leading-tight ${s.state === 'upcoming' ? 'text-ink-300' : 'font-semibold'}`}>{tr(s.en, s.hi)} {s.state === 'current' && <span className="ml-1 rounded-full bg-brand-soft px-2 py-0.5 text-xs font-semibold text-brand-dark">{tr('In progress', 'जारी')}</span>}</p>
            {s.at && <p className="text-sm text-ink-500">{dateTime(s.at)}{s.note ? `: ${s.note}` : ''}</p>}
          </div>
        </li>
      ))}
    </ol>
  );
}

export default function Tracker() {
  const { orderId } = useParams();
  const { tr, lang, rememberOrder } = useApp();
  const [order, setOrder] = useState(null);
  const [error, setError] = useState(null);
  const [actionError, setActionError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [slot, setSlot] = useState({ date: '', window: '' });
  const [help, setHelp] = useState(null); // null | { topic, message, ticket }
  const [showDetails, setShowDetails] = useState(false);

  const load = useCallback(async (quiet) => {
    try { const o = await api.order(orderId); setOrder(o); setError(null); rememberOrder(o); } catch (e) { if (!quiet) setError(e); }
  }, [orderId, rememberOrder]);
  useEffect(() => { load(); const t = setInterval(() => load(true), 10000); return () => clearInterval(t); }, [load]);

  const act = async (fn) => { setBusy(true); setActionError(null); try { setOrder(await fn()); } catch (e) { setActionError(e); } finally { setBusy(false); } };

  if (error) return <div className="mx-auto max-w-xl px-4 py-10"><Alert tone="error" title={error.message} /><Link to="/track" className="btn-ghost mt-4">{tr('Try another order ID', 'दूसरा ऑर्डर ID डालें')}</Link></div>;
  if (!order) return <PageLoader label={tr('Loading your order', 'ऑर्डर लोड हो रहा है')} />;

  const active = order.orderStatus === 'SERVICE_ACTIVATED';
  const current = order.stages.find((s) => s.state === 'current') || order.stages[order.stages.length - 1];
  const doneCount = order.stages.filter((s) => s.state === 'done').length;
  const canSimulate = order.demoMode && ['INSTALLATION_SCHEDULED', 'INSTALLATION_IN_PROGRESS'].includes(order.orderStatus);

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <div className="card overflow-hidden">
        <div className="bg-ink p-5 text-white sm:p-7">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-ink-300">{tr('Order', 'ऑर्डर')} <span className="font-semibold tracking-wide text-white">{order.orderId}</span></p>
              <h1 className="mt-1 text-3xl text-white sm:text-4xl">{order.businessName}</h1>
              <p className="mt-1 text-ink-300">{order.bundleName}, {tr('ordered', 'ऑर्डर किया')} {date(order.orderDate, lang)}</p>
            </div>
            <div className="text-left sm:text-right">
              <p className="text-ink-300">{active ? tr('Activated on', 'चालू हुआ') : tr('Expected activation', 'चालू होने की उम्मीद')}</p>
              <p className="text-2xl font-bold">{date(active ? order.stages[5].at : order.expectedActivationDate, lang)}</p>
              {order.installationSlot && !active && <p className="text-sm text-ink-300">{tr('Installation', 'इंस्टॉलेशन')}: {order.installationSlot.window}</p>}
            </div>
          </div>
          <div className="mt-5" role="progressbar" aria-valuemin={0} aria-valuemax={6} aria-valuenow={active ? 6 : doneCount} aria-label={tr('Order progress', 'ऑर्डर की प्रगति')}>
            <div className="h-2 overflow-hidden rounded-full bg-white/15"><div className="h-full rounded-full bg-brand transition-all duration-700" style={{ width: `${((active ? 6 : doneCount + 0.5) / 6) * 100}%` }} /></div>
            <p className="mt-2 text-[15px]">{active ? tr('All done. Your services are live.', 'सब पूरा। आपकी सेवाएँ चालू हैं।') : <>{tr('Now', 'अभी')}: <strong>{tr(current.en, current.hi)}</strong> ({tr('step', 'चरण')} {doneCount + 1} / 6)</>}</p>
          </div>
        </div>
      </div>

      {active && <div className="mt-5 flex items-start gap-3 rounded-2xl bg-ok px-5 py-4 text-white"><PartyPopper className="mt-0.5 h-6 w-6 shrink-0" aria-hidden="true" /><p><strong>{tr('Your services are active.', 'आपकी सेवाएँ चालू हैं।')}</strong> {tr('Welcome aboard. Your first bill will follow the plan shown below.', 'स्वागत है। आपका पहला बिल नीचे दिखाए प्लान के अनुसार आएगा।')}</p></div>}

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_400px]">
        <div className="space-y-6">
          {actionError && <Alert tone="error" title={actionError.message} details={actionError.details} />}

          {order.pendingActions.length > 0 && (
            <section className="card p-5" aria-label={tr('What you need to do', 'आपको क्या करना है')}>
              <h2 className="text-xl">{tr('What you need to do', 'आपको क्या करना है')}</h2>
              <ul className="mt-3 divide-y divide-mist-line">
                {order.pendingActions.map((a, i) => (
                  <li key={i} className="flex items-center justify-between gap-3 py-3">
                    <span className="flex items-start gap-3"><span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-brand" aria-hidden="true" /><span>{a.text}</span></span>
                    {a.link === 'kyc' && <Link to={`/kyc/${order.orderId}`} className="btn-dark btn-sm shrink-0">{tr('Open KYC', 'KYC खोलें')}<ChevronRight className="h-4 w-4" aria-hidden="true" /></Link>}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {order.slotOptions && (
            <section className="card border-2 !border-brand p-5" aria-label={tr('Choose installation date', 'इंस्टॉलेशन की तारीख़ चुनें')}>
              <h2 className="flex items-center gap-2 text-xl"><CalendarDays className="h-5 w-5 text-brand" aria-hidden="true" />{tr('Choose your installation date', 'इंस्टॉलेशन की तारीख़ चुनें')}</h2>
              <p className="mt-1 text-ink-700">{tr(`The earliest date allows the ${order.installDays} days this bundle typically needs.`, `सबसे पहली तारीख़ में इस बंडल के लिए लगने वाले ${order.installDays} दिन शामिल हैं।`)}</p>
              <fieldset className="mt-4"><legend className="label">{tr('Date', 'तारीख़')}</legend><div className="flex flex-wrap gap-2">{order.slotOptions.dates.map((d) => <button key={d} type="button" aria-pressed={slot.date === d} onClick={() => setSlot((s) => ({ ...s, date: d }))} className={`chip ${slot.date === d ? 'chip-on' : ''}`}>{new Date(`${d}T12:00:00`).toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-IN', { weekday: 'short', day: 'numeric', month: 'short' })}</button>)}</div></fieldset>
              <fieldset className="mt-4"><legend className="label">{tr('Time', 'समय')}</legend><div className="flex flex-wrap gap-2">{order.slotOptions.windows.map((w) => <button key={w} type="button" aria-pressed={slot.window === w} onClick={() => setSlot((s) => ({ ...s, window: w }))} className={`chip ${slot.window === w ? 'chip-on' : ''}`}>{w}</button>)}</div></fieldset>
              <button disabled={!slot.date || !slot.window || busy} onClick={() => act(() => api.schedule(order.orderId, slot.date, slot.window))} className="btn-primary mt-5">{busy ? <Spinner label="" /> : null}{tr('Book installation', 'इंस्टॉलेशन बुक करें')}</button>
            </section>
          )}

          <section className="card p-5 sm:p-6" aria-label={tr('Order timeline', 'ऑर्डर की टाइमलाइन')}>
            <div className="mb-5 flex items-center justify-between gap-3"><h2 className="text-xl">{tr('Order timeline', 'ऑर्डर की टाइमलाइन')}</h2><button onClick={() => load()} className="rounded-full p-2 text-ink-500 hover:bg-mist" aria-label={tr('Refresh', 'रीफ़्रेश')}><RefreshCw className="h-4 w-4" /></button></div>
            <Timeline stages={order.stages} />
            {canSimulate && (
              <div className="mt-6 rounded-xl border border-dashed border-wait/50 bg-wait-soft/60 p-4">
                <p className="text-[15px]"><DemoTag>{tr('Demo control', 'डेमो कंट्रोल')}</DemoTag> {tr('In a live service the field team updates these stages. For the demo you can move the order forward yourself.', 'असली सेवा में ये चरण फ़ील्ड टीम अपडेट करती है। डेमो के लिए आप ख़ुद आगे बढ़ा सकते हैं।')}</p>
                <button disabled={busy} onClick={() => act(() => api.advance(order.orderId))} className="btn-dark btn-sm mt-3"><FastForward className="h-4 w-4" aria-hidden="true" />{tr('Simulate next stage', 'अगला चरण सिम्युलेट करें')}</button>
              </div>
            )}
          </section>
        </div>

        <aside className="h-fit space-y-6">
          <section className="card p-5">
            <div className="flex items-center justify-between gap-3"><h2 className="text-xl">{tr('KYC', 'KYC')}</h2><StatusBadge status={order.kyc?.overallStatus || 'In progress'} /></div>
            <dl className="mt-3 space-y-2 text-[15px]">
              {[[tr('Consent', 'सहमति'), order.kyc?.consentStatus], ['GSTIN', order.kyc?.gstinStatus], [tr('Udyam', 'उद्यम'), order.kyc?.udyamStatus], [tr('Documents', 'दस्तावेज़'), order.kyc?.documentStatus]].map(([k, v]) => <div key={k} className="flex items-center justify-between gap-3"><dt className="text-ink-700">{k}</dt><dd><StatusBadge status={v} /></dd></div>)}
            </dl>
            <Link to={`/kyc/${order.orderId}`} className="mt-4 inline-block font-semibold underline">{tr('View KYC details', 'KYC विवरण देखें')}</Link>
          </section>

          <section className="card p-5">
            <button className="flex w-full items-center justify-between gap-3 text-left" onClick={() => setShowDetails((s) => !s)} aria-expanded={showDetails}><h2 className="text-xl">{tr('Order details', 'ऑर्डर का विवरण')}</h2><span className="font-semibold underline">{showDetails ? tr('Hide', 'छिपाएँ') : tr('View', 'देखें')}</span></button>
            <ul className="mt-3 space-y-1.5">{order.selectedProducts.map((l) => <li key={l.productId} className="flex justify-between gap-3"><span>{l.name} × {l.qty}</span>{showDetails && <span className="tabular-nums text-ink-700">{inr(l.monthly)}</span>}</li>)}</ul>
            {showDetails && (
              <dl className="mt-4 space-y-2 border-t border-mist-line pt-4 text-[15px]">
                {[[tr('Monthly charges', 'मासिक शुल्क'), inr(order.monthlyPrice)], [tr('One-time setup fee', 'सेटअप फ़ीस'), inr(order.setupFee)], [tr('Contract', 'कॉन्ट्रैक्ट'), `${order.contractDuration} ${tr('months', 'महीने')}`], [tr('Paid (demo)', 'भुगतान (डेमो)'), `${inr(order.payment.amount)}, ${order.payment.reference}`], [tr('Owner', 'मालिक'), order.ownerName], [tr('Mobile', 'मोबाइल'), order.contact?.mobile], [tr('Email', 'ईमेल'), order.contact?.email]].map(([k, v]) => <div key={k} className="flex justify-between gap-4"><dt className="text-ink-500">{k}</dt><dd className="text-right font-medium break-all">{v}</dd></div>)}
              </dl>
            )}
          </section>

          <section className="card p-5">
            <h2 className="flex items-center gap-2 text-xl"><LifeBuoy className="h-5 w-5" aria-hidden="true" />{tr('Need help?', 'मदद चाहिए?')}</h2>
            <p className="mt-1 text-ink-700">{tr('Ask for a call back about this order.', 'इस ऑर्डर के बारे में कॉल बैक माँगें।')}</p>
            <button onClick={() => setHelp({ topic: TOPICS[0], message: '' })} className="btn-ghost btn-sm mt-3">{tr('Request a call back', 'कॉल बैक माँगें')} <DemoTag>{tr('Simulated', 'नकली')}</DemoTag></button>
            {order.supportRequests.length > 0 && <ul className="mt-3 space-y-1 text-sm text-ink-500">{order.supportRequests.map((s) => <li key={s.ticketId}>{s.ticketId}: {s.topic} ({dateTime(s.at)})</li>)}</ul>}
          </section>
        </aside>
      </div>

      {help && (
        <Modal title={tr('Request a call back', 'कॉल बैक माँगें')} onClose={() => setHelp(null)}>
          {help.ticket ? (
            <div className="space-y-4"><Alert tone="ok" title={`${tr('Request received. Ticket', 'अनुरोध मिल गया। टिकट')} ${help.ticket.ticketId}`}>{help.ticket.message}</Alert><button className="btn-dark w-full" onClick={() => setHelp(null)}>{tr('Close', 'बंद करें')}</button></div>
          ) : (
            <form className="space-y-4" onSubmit={async (e) => { e.preventDefault(); try { const ticket = await api.support(order.orderId, help.topic, help.message); setHelp((h) => ({ ...h, ticket })); load(true); } catch (err) { setHelp((h) => ({ ...h, error: err.message })); } }}>
              <div><label className="label" htmlFor="topic">{tr('What do you need help with?', 'किस बारे में मदद चाहिए?')}</label><select id="topic" className="field" value={help.topic} onChange={(e) => setHelp((h) => ({ ...h, topic: e.target.value }))}>{TOPICS.map((t) => <option key={t}>{t}</option>)}</select></div>
              <div><label className="label" htmlFor="msg">{tr('Anything else we should know? (optional)', 'कुछ और बताना चाहेंगे? (वैकल्पिक)')}</label><textarea id="msg" rows={3} maxLength={500} className="field" value={help.message} onChange={(e) => setHelp((h) => ({ ...h, message: e.target.value }))} /></div>
              {help.error && <Alert tone="error" title={help.error} />}
              <button className="btn-primary w-full">{tr('Send request', 'अनुरोध भेजें')}</button>
            </form>
          )}
        </Modal>
      )}
    </div>
  );
}
