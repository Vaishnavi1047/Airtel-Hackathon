import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowRight, Camera, FileImage, ShieldCheck, PartyPopper, ChevronDown } from 'lucide-react';
import { api } from '../lib/api.js';
import { dateTime, date } from '../lib/format.js';
import { useApp } from '../lib/store.jsx';
import { Alert, CheckList, DemoTag, PageLoader, Spinner, StatusBadge } from '../components/ui.jsx';

const DOC_HINT = {
  gst_certificate: 'The certificate that shows your GSTIN, legal name and address.',
  udyam_certificate: 'The certificate that shows your Udyam registration number.',
  signatory_id: 'Photo ID of the person signing for the business.',
  address_proof: 'An electricity or other utility bill from the last 90 days.',
};
const FIELD_LABEL = { gstin: 'GSTIN', legalName: 'Legal name', tradeName: 'Trade name', constitution: 'Constitution', address: 'Address', documentDate: 'Document date', udyamNumber: 'Udyam number', enterpriseName: 'Enterprise name', majorActivity: 'Major activity', city: 'City', state: 'State', name: 'Name', designation: 'Designation', forBusiness: 'For business', idNumber: 'ID number', validTill: 'Valid till', billedTo: 'Billed to', consumerNumber: 'Consumer number' };

function Step({ n, title, status, open, onToggle, children }) {
  return (
    <section className="card overflow-hidden">
      <button className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left" onClick={onToggle} aria-expanded={open}>
        <span className="flex items-center gap-3"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-ink font-bold text-white">{n}</span><span className="text-lg font-semibold">{title}</span></span>
        <span className="flex items-center gap-2"><StatusBadge status={status} /><ChevronDown className={`h-5 w-5 text-ink-500 transition-transform ${open ? 'rotate-180' : ''}`} aria-hidden="true" /></span>
      </button>
      {open && <div className="border-t border-mist-line px-5 py-5">{children}</div>}
    </section>
  );
}

function Details({ rows }) {
  return (
    <dl className="grid gap-x-6 gap-y-2 sm:grid-cols-2">
      {rows.filter(([, v]) => v).map(([k, v]) => <div key={k}><dt className="text-sm text-ink-500">{k}</dt><dd className="font-medium break-words">{v}</dd></div>)}
    </dl>
  );
}

function DocSlot({ type, label, doc, sample, busy, onFile, onSample }) {
  const { tr } = useApp();
  const ref = useRef(null);
  return (
    <div className="rounded-2xl border border-mist-line p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div><h3 className="font-semibold">{label}</h3><p className="text-sm text-ink-500">{DOC_HINT[type]}</p></div>
        <StatusBadge status={busy ? 'Pending' : doc?.status || 'Not started'} />
      </div>
      {busy ? <div className="mt-3"><Spinner label={tr('Reading the document (OCR)…', 'दस्तावेज़ पढ़ा जा रहा है (OCR)…')} /></div> : (
        <div className="mt-3 flex flex-wrap gap-2">
          <input ref={ref} type="file" accept="image/png,image/jpeg" className="sr-only" id={`file-${type}`} onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) onFile(f); }} />
          <label htmlFor={`file-${type}`} className="btn-dark btn-sm cursor-pointer"><Camera className="h-4 w-4" aria-hidden="true" />{doc ? tr('Upload again', 'दोबारा अपलोड करें') : tr('Take or choose photo', 'फ़ोटो लें या चुनें')}</label>
          {sample && <button type="button" onClick={onSample} className="btn-ghost btn-sm"><FileImage className="h-4 w-4" aria-hidden="true" />{tr('Use sample document', 'सैंपल दस्तावेज़ लें')} <DemoTag /></button>}
        </div>
      )}
      {doc && !busy && (
        <div className="mt-4 space-y-3">
          <Alert tone={doc.status === 'Verified' ? 'ok' : doc.status === 'Pending' ? 'warn' : 'error'} title={doc.message} />
          {doc.fields && Object.values(doc.fields).some(Boolean) && (
            <div><p className="mb-1.5 text-sm font-semibold text-ink-500">{tr('Read from your document', 'आपके दस्तावेज़ से पढ़ा गया')}</p><Details rows={Object.entries(doc.fields).map(([k, v]) => [FIELD_LABEL[k] || k, v])} /></div>
          )}
          <div><p className="mb-1.5 text-sm font-semibold text-ink-500">{tr('Checks', 'जाँच')}</p><CheckList checks={doc.checks} /></div>
        </div>
      )}
    </div>
  );
}

export default function Kyc() {
  const { orderId } = useParams();
  const { tr, lang } = useApp();
  const [status, setStatus] = useState(null);
  const [notice, setNotice] = useState(null);
  const [sample, setSample] = useState(null);
  const [error, setError] = useState(null);
  const [stepError, setStepError] = useState({});
  const [busy, setBusy] = useState({});
  const [open, setOpen] = useState(null);
  const [agree, setAgree] = useState(false);
  const [gstin, setGstin] = useState('');
  const [udyam, setUdyam] = useState('');

  const refresh = useCallback(async () => { const s = await api.kycStatus(orderId); setStatus(s); return s; }, [orderId]);
  useEffect(() => {
    (async () => {
      try {
        const [s, n, m] = await Promise.all([refresh(), api.kycNotice(), api.meta()]);
        setNotice(n);
        if (m.demoMode) { const list = await api.demoApplicants(); setSample(list.find((a) => a.businessName === s.business.name) || null); }
      } catch (e) { setError(e); }
    })();
  }, [refresh]);

  const kyc = status?.kyc;
  const active = !kyc ? null : kyc.consentStatus !== 'Given' ? 'consent' : ['Not started', 'Mismatch', 'Rejected'].includes(kyc.gstinStatus) ? 'gstin' : ['Not started', 'Mismatch', 'Rejected'].includes(kyc.udyamStatus) ? 'udyam' : 'documents';
  useEffect(() => { if (active) setOpen(active); }, [active]);

  const run = async (key, fn) => {
    setBusy((b) => ({ ...b, [key]: true })); setStepError((e) => ({ ...e, [key]: null }));
    try { await fn(); await refresh(); } catch (e) { setStepError((x) => ({ ...x, [key]: e })); } finally { setBusy((b) => ({ ...b, [key]: false })); }
  };
  const uploadDoc = (type, file) => {
    if (file.size > 5 * 1024 * 1024) return setStepError((e) => ({ ...e, [type]: new Error('This file is larger than 5 MB. Please choose a smaller photo.') }));
    if (!['image/png', 'image/jpeg'].includes(file.type)) return setStepError((e) => ({ ...e, [type]: new Error('Only PNG or JPG photos are accepted.') }));
    return run(type, () => api.upload(orderId, type, file));
  };
  const uploadSample = (type) => run(type, async () => api.upload(orderId, type, await api.demoDocument(`${sample.id}_${type}.png`)));

  if (error) return <div className="mx-auto max-w-xl px-4 py-10"><Alert tone="error" title={error.message} /><Link to="/track" className="btn-ghost mt-4">{tr('Find my order', 'मेरा ऑर्डर ढूँढें')}</Link></div>;
  if (!status || !notice) return <PageLoader label={tr('Loading KYC', 'KYC लोड हो रहा है')} />;

  const toggle = (k) => setOpen((o) => (o === k ? null : k));
  const consentGiven = kyc.consentStatus === 'Given';
  const docs = Object.fromEntries(kyc.documents.map((d) => [d.type, d]));
  const approved = kyc.overallStatus === 'Approved';

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div><p className="text-[15px] font-medium text-ink-500">{tr('Order', 'ऑर्डर')} {orderId}, {status.business.name}</p><h1 className="text-3xl sm:text-4xl">{tr('Smart KYC', 'स्मार्ट KYC')}</h1></div>
        <StatusBadge status={kyc.overallStatus} className="!text-base" />
      </div>
      <Alert tone="info" className="mt-4">{notice.disclaimer} {tr('Document dates are checked against', 'दस्तावेज़ की तारीख़ें इस तारीख़ से जाँची जाती हैं:')} {date(status.referenceDate)} {tr('(the "today" set by the dataset).', '(डेटासेट का "आज")।')}</Alert>

      {approved && (
        <div className="mt-5 rounded-2xl bg-ok px-5 py-5 text-white">
          <p className="flex items-center gap-2 text-xl font-bold"><PartyPopper className="h-6 w-6" aria-hidden="true" />{tr('KYC approved', 'KYC मंज़ूर')}</p>
          <p className="mt-1">{tr('Every check passed, so approval was automatic.', 'सभी जाँचें सही रहीं, इसलिए मंज़ूरी अपने-आप मिल गई।')} {status.orderStatus === 'KYC_APPROVED' && tr('Next, choose your installation date.', 'अब इंस्टॉलेशन की तारीख़ चुनें।')}</p>
          <Link to={`/track/${orderId}`} className="btn mt-4 bg-white text-ok hover:bg-ok-soft">{status.orderStatus === 'KYC_APPROVED' ? tr('Choose installation date', 'इंस्टॉलेशन की तारीख़ चुनें') : tr('Open order tracker', 'ऑर्डर ट्रैकर खोलें')}<ArrowRight className="h-5 w-5" aria-hidden="true" /></Link>
        </div>
      )}
      {sample && !approved && <p className="mt-4 rounded-xl border border-dashed border-wait/50 bg-wait-soft/60 px-4 py-3 text-[15px]"><DemoTag /> {tr('Sample applicant', 'सैंपल आवेदक')} <strong>{sample.id}</strong>: {sample.expect}</p>}

      <div className="mt-5 space-y-4">
        <Step n={1} title={tr('Your consent', 'आपकी सहमति')} status={consentGiven ? 'Given' : 'Not given'} open={open === 'consent'} onToggle={() => toggle('consent')}>
          <div className="grid gap-5 sm:grid-cols-2">
            {notice.sections.map((s) => <div key={s.title}><h3 className="font-semibold">{s.title}</h3><ul className="mt-1 list-disc space-y-1 pl-5 text-[15px] text-ink-700">{s.points.map((p) => <li key={p}>{p}</li>)}</ul></div>)}
          </div>
          {consentGiven ? <p className="mt-5 flex items-center gap-2 font-medium text-ok"><ShieldCheck className="h-5 w-5" aria-hidden="true" />{tr('Consent given on', 'सहमति दी गई:')} {dateTime(kyc.consentGivenAt)}. {tr('Your KYC record will be deleted on', 'आपका KYC रिकॉर्ड हटाया जाएगा:')} {date(kyc.retention.deleteAfter, lang)}.</p> : (
            <div className="mt-5 space-y-3 border-t border-mist-line pt-5">
              <label className="flex cursor-pointer items-start gap-3"><input type="checkbox" className="mt-1 h-5 w-5 accent-[#D81F2A]" checked={agree} onChange={(e) => setAgree(e.target.checked)} /><span>{tr('I have read the above and I agree to my business details and documents being processed for KYC as described.', 'मैंने ऊपर लिखा पढ़ लिया है और KYC के लिए अपने कारोबार की जानकारी और दस्तावेज़ों की जाँच के लिए सहमत हूँ।')}</span></label>
              <button disabled={!agree || busy.consent} onClick={() => run('consent', () => api.consent(orderId))} className="btn-primary">{busy.consent ? <Spinner label="" /> : null}{tr('I agree, start KYC', 'मैं सहमत हूँ, KYC शुरू करें')}</button>
              <p className="text-sm text-ink-500">{tr('Nothing is checked or uploaded until you agree.', 'आपकी सहमति से पहले कोई जाँच या अपलोड नहीं होता।')}</p>
            </div>
          )}
          {stepError.consent && <Alert tone="error" className="mt-3" title={stepError.consent.message} />}
        </Step>

        <Step n={2} title={tr('GSTIN check', 'GSTIN जाँच')} status={kyc.gstinStatus} open={open === 'gstin'} onToggle={() => toggle('gstin')}>
          {!consentGiven ? <p className="text-ink-500">{tr('Give consent first.', 'पहले सहमति दें।')}</p> : (
            <>
              <form onSubmit={(e) => { e.preventDefault(); run('gstin', () => api.verifyGstin(orderId, { gstin })); }} className="space-y-3">
                <label className="label" htmlFor="gstin">{tr('Your 15-character GSTIN', 'आपका 15 अक्षरों का GSTIN')}</label>
                <div className="flex flex-wrap gap-2">
                  <input id="gstin" className="field max-w-xs uppercase tracking-wide" value={gstin} onChange={(e) => setGstin(e.target.value.toUpperCase().replace(/[^0-9A-Z]/g, '').slice(0, 15))} placeholder="e.g. 09ABCDE1234F1Z5" autoComplete="off" />
                  <button className="btn-dark" disabled={gstin.length !== 15 || busy.gstin}>{busy.gstin ? <Spinner label="" /> : null}{tr('Check GSTIN', 'GSTIN जाँचें')}</button>
                </div>
                <div className="flex flex-wrap gap-x-5 gap-y-2 text-[15px]">
                  {sample?.gstin && <button type="button" className="font-semibold underline" onClick={() => setGstin(sample.gstin)}>{tr('Fill sample GSTIN', 'सैंपल GSTIN भरें')} <DemoTag /></button>}
                  {!status.requiresGstin && <button type="button" className="font-medium text-ink-700 underline" onClick={() => run('gstin', () => api.verifyGstin(orderId, { skip: true }))}>{tr('I do not have a GSTIN, skip', 'मेरे पास GSTIN नहीं है, छोड़ें')}</button>}
                </div>
                {status.requiresGstin && <p className="text-sm text-ink-500">{tr('Your order includes services that need an active GSTIN, so this step is required.', 'आपके ऑर्डर में ऐसी सेवाएँ हैं जिनके लिए सक्रिय GSTIN ज़रूरी है।')}</p>}
              </form>
              {stepError.gstin && <Alert tone="error" className="mt-3" title={stepError.gstin.message} details={stepError.gstin.details} />}
              {kyc.gstin && (
                <div className="mt-5 space-y-4 rounded-2xl bg-mist p-4">
                  <Details rows={[['GSTIN', kyc.gstin.masked], [tr('GST registration status', 'GST पंजीकरण स्थिति'), kyc.gstin.registrationStatus], [tr('Legal business name', 'कानूनी नाम'), kyc.gstin.legalName], [tr('Trade name', 'ट्रेड नाम'), kyc.gstin.tradeName], [tr('Constitution', 'गठन'), kyc.gstin.constitution], [tr('Registered address', 'पंजीकृत पता'), kyc.gstin.address]]} />
                  {['Cancelled', 'Suspended'].includes(kyc.gstin.registrationStatus) && <Alert tone="error" title={`${tr('This GST registration is', 'यह GST पंजीकरण है:')} ${kyc.gstin.registrationStatus}.`}>{tr('Services cannot be activated on it. Please use an active GSTIN or contact support.', 'इस पर सेवा चालू नहीं हो सकती। सक्रिय GSTIN दें या सहायता से संपर्क करें।')}</Alert>}
                  <CheckList checks={kyc.gstin.checks} />
                </div>
              )}
            </>
          )}
        </Step>

        <Step n={3} title={tr('Udyam check (optional)', 'उद्यम जाँच (वैकल्पिक)')} status={kyc.udyamStatus} open={open === 'udyam'} onToggle={() => toggle('udyam')}>
          {!consentGiven ? <p className="text-ink-500">{tr('Give consent first.', 'पहले सहमति दें।')}</p> : (
            <>
              <form onSubmit={(e) => { e.preventDefault(); run('udyam', () => api.verifyUdyam(orderId, { udyamNumber: udyam })); }} className="space-y-3">
                <label className="label" htmlFor="udyam">{tr('Your Udyam registration number', 'आपका उद्यम पंजीकरण नंबर')}</label>
                <div className="flex flex-wrap gap-2">
                  <input id="udyam" className="field max-w-xs uppercase" value={udyam} onChange={(e) => setUdyam(e.target.value.toUpperCase().slice(0, 22))} placeholder="UDYAM-XX-00-0000000" autoComplete="off" />
                  <button className="btn-dark" disabled={udyam.length < 12 || busy.udyam}>{busy.udyam ? <Spinner label="" /> : null}{tr('Check Udyam', 'उद्यम जाँचें')}</button>
                </div>
                <div className="flex flex-wrap gap-x-5 gap-y-2 text-[15px]">
                  {sample?.udyam && <button type="button" className="font-semibold underline" onClick={() => setUdyam(sample.udyam)}>{tr('Fill sample Udyam number', 'सैंपल उद्यम नंबर भरें')} <DemoTag /></button>}
                  <button type="button" className="font-medium text-ink-700 underline" onClick={() => run('udyam', () => api.verifyUdyam(orderId, { skip: true }))}>{tr('Skip this step', 'यह चरण छोड़ें')}</button>
                </div>
              </form>
              {stepError.udyam && <Alert tone="error" className="mt-3" title={stepError.udyam.message} details={stepError.udyam.details} />}
              {kyc.udyam && (
                <div className="mt-5 space-y-4 rounded-2xl bg-mist p-4">
                  <Details rows={[[tr('Udyam number', 'उद्यम नंबर'), kyc.udyam.masked], [tr('Enterprise name', 'उद्यम का नाम'), kyc.udyam.enterpriseName], [tr('Enterprise type', 'उद्यम का प्रकार'), kyc.udyam.enterpriseType], [tr('Major activity', 'मुख्य गतिविधि'), kyc.udyam.majorActivity], [tr('City', 'शहर'), kyc.udyam.city], [tr('State', 'राज्य'), kyc.udyam.state]]} />
                  <CheckList checks={kyc.udyam.checks} />
                </div>
              )}
            </>
          )}
        </Step>

        <Step n={4} title={tr('Documents', 'दस्तावेज़')} status={kyc.documentStatus} open={open === 'documents'} onToggle={() => toggle('documents')}>
          {!consentGiven ? <p className="text-ink-500">{tr('Give consent first.', 'पहले सहमति दें।')}</p> : (
            <div className="space-y-4">
              <p className="text-ink-700">{tr('Clear photos in PNG or JPG, up to 5 MB each. We read the details and discard the photo; it is not stored.', 'PNG या JPG में साफ़ फ़ोटो, हर एक 5 MB तक। हम जानकारी पढ़कर फ़ोटो हटा देते हैं; इसे सेव नहीं किया जाता।')}</p>
              {status.requiredDocuments.map((d) => (
                <div key={d.type}>
                  <DocSlot type={d.type} label={d.label} doc={docs[d.type]} busy={busy[d.type]} sample={sample?.documents.includes(d.type)} onFile={(f) => uploadDoc(d.type, f)} onSample={() => uploadSample(d.type)} />
                  {stepError[d.type] && <Alert tone="error" className="mt-2" title={stepError[d.type].message} details={stepError[d.type].details} />}
                </div>
              ))}
            </div>
          )}
        </Step>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <Link to={`/track/${orderId}`} className={approved ? 'btn-primary' : 'btn-ghost'}>{tr('Open order tracker', 'ऑर्डर ट्रैकर खोलें')}<ArrowRight className="h-5 w-5" aria-hidden="true" /></Link>
      </div>
    </div>
  );
}
