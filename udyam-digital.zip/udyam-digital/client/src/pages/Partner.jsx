import { useCallback, useEffect, useState } from 'react';
import { Search, UserRoundCog, Zap, ChevronLeft, ChevronRight, LockKeyhole } from 'lucide-react';
import { api } from '../lib/api.js';
import { inr, inrShort, pct, dateTime } from '../lib/format.js';
import { Alert, DemoTag, Modal, PageLoader, Spinner } from '../components/ui.jsx';

const PRIORITY_CLS = { High: 'bg-brand text-white', Medium: 'bg-wait-soft text-wait', Low: 'bg-mist text-ink-500', Customer: 'bg-ok-soft text-ok' };
const Priority = ({ p, score }) => <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-sm font-semibold ${PRIORITY_CLS[p]}`}>{score !== undefined && <span className="tabular-nums">{score}</span>}{p}</span>;

function Gate({ onDone }) {
  const [code, setCode] = useState('');
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setError(null);
    try { await api.partnerLogin(code); sessionStorage.setItem('ud_partner_code', code); onDone(); } catch (err) { setError(err.message); } finally { setBusy(false); }
  };
  return (
    <div className="mx-auto max-w-md px-4 py-14">
      <div className="card p-6">
        <LockKeyhole className="h-8 w-8 text-brand" aria-hidden="true" />
        <h1 className="mt-3 text-2xl">Partner dashboard</h1>
        <p className="mt-1 text-ink-700">For sales executives and channel partners. It shows lead contact names, so it needs an access code.</p>
        <form onSubmit={submit} className="mt-5 space-y-3">
          <label className="label" htmlFor="code">Access code</label>
          <input id="code" type="password" className="field" value={code} onChange={(e) => setCode(e.target.value)} autoComplete="off" />
          {error && <Alert tone="error" title={error} />}
          <button className="btn-primary w-full" disabled={!code || busy}>{busy ? <Spinner label="" /> : null}Open dashboard</button>
        </form>
        <p className="mt-4 text-sm text-ink-500"><DemoTag /> The demo code is <code className="rounded bg-mist px-1.5 py-0.5 font-semibold text-ink">partner-demo</code> (change it in server/.env).</p>
      </div>
    </div>
  );
}

function Bar({ label, value, max, right, tone = 'bg-ink', sub }) {
  return (
    <div>
      <div className="flex items-baseline justify-between gap-3 text-[15px]"><span className="min-w-0 truncate">{label}{sub}</span><span className="shrink-0 font-semibold tabular-nums">{right}</span></div>
      <div className="mt-1 h-2.5 overflow-hidden rounded-full bg-mist"><div className={`h-full rounded-full ${tone}`} style={{ width: `${Math.max(1.5, (value / max) * 100)}%` }} /></div>
    </div>
  );
}

function Metrics({ s }) {
  const b = s.baseline;
  const [recover, setRecover] = useState(10);
  const extra = Math.round(b.digitalFixableDrops * (recover / 100));
  const newConv = (b.activatedCustomers + extra) / b.totalLeads;
  const kpis = [
    ['Total leads', b.totalLeads.toLocaleString('en-IN')],
    ['Activated customers', b.activatedCustomers.toLocaleString('en-IN')],
    ['Lead-to-activation conversion', pct(b.conversionRate, 2)],
    ['Average activation time', `${b.avgActivationDays.toFixed(1)} days`],
    ['Acquisition cost per customer', inr(b.acquisitionCostPerCustomer)],
  ];
  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-xl">Baseline from the case study <span className="text-base font-normal text-ink-500">({b.period})</span></h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {kpis.map(([k, v]) => <div key={k} className="card p-4"><p className="text-sm text-ink-500">{k}</p><p className="mt-1 text-2xl font-bold tabular-nums">{v}</p></div>)}
        </div>
        <p className="mt-2 text-sm text-ink-500">Computed live from smb_leads.csv. Acquisition cost is total sales and partner spend divided by activated customers. Activated customers also made {b.avgFollowUpCalls.toFixed(1)} follow-up calls on average.</p>
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-5">
          <h2 className="text-xl">Where leads drop out</h2>
          <div className="mt-4 space-y-3">
            {b.funnel.map((f, i) => <Bar key={f.stage} label={f.stage} value={f.count} max={b.totalLeads} right={`${f.count.toLocaleString('en-IN')}${i ? ` (${Math.round((f.count / b.funnel[i - 1].count) * 100)}% of previous)` : ''}`} tone={i === b.funnel.length - 1 ? 'bg-ok' : 'bg-ink'} />)}
          </div>
        </section>
        <section className="card p-5">
          <h2 className="text-xl">Why leads were lost</h2>
          <p className="text-[15px] text-ink-500"><span className="mr-1 inline-block h-2.5 w-2.5 rounded-full bg-brand" /> Red: reasons a self-serve digital journey directly removes ({b.digitalFixableDrops.toLocaleString('en-IN')} leads)</p>
          <div className="mt-4 max-h-[340px] space-y-3 overflow-y-auto pr-1">
            {b.dropReasons.map((d) => <Bar key={d.reason} label={d.reason} value={d.count} max={b.dropReasons[0].count} right={d.count} tone={d.digitalFixable ? 'bg-brand' : 'bg-ink-300'} />)}
          </div>
        </section>
      </div>

      <section className="card p-5">
        <h2 className="text-xl">What-if calculator <DemoTag>Illustration, not a forecast</DemoTag></h2>
        <p className="mt-1 max-w-3xl text-ink-700">Last quarter {b.digitalFixableDrops.toLocaleString('en-IN')} leads were lost for reasons the digital journey addresses (no visit needed, instant quote, shorter paperwork, self-booked installation). Move the slider to see what recovering a share of them would mean. The share itself is your assumption.</p>
        <label className="label mt-4" htmlFor="recover">Share of those leads recovered: <strong>{recover}%</strong></label>
        <input id="recover" type="range" min="0" max="50" step="1" value={recover} onChange={(e) => setRecover(Number(e.target.value))} className="w-full max-w-xl accent-[#D81F2A]" />
        <dl className="mt-4 grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl bg-mist p-4"><dt className="text-sm text-ink-500">Extra activations</dt><dd className="text-2xl font-bold tabular-nums">+{extra.toLocaleString('en-IN')}</dd></div>
          <div className="rounded-xl bg-mist p-4"><dt className="text-sm text-ink-500">Conversion rate</dt><dd className="text-2xl font-bold tabular-nums">{pct(b.conversionRate, 2)} to {pct(newConv, 2)}</dd></div>
          <div className="rounded-xl bg-mist p-4"><dt className="text-sm text-ink-500">Extra monthly revenue (at last quarter's average bundle of {inr(b.avgMonthlyBundleValue)})</dt><dd className="text-2xl font-bold tabular-nums">{inrShort(extra * b.avgMonthlyBundleValue)}</dd></div>
        </dl>
      </section>

      <section className="card p-5">
        <h2 className="text-xl">Activation rate by segment</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">{b.bySegment.map((x) => <Bar key={x.segment} label={x.segment} sub={<span className="text-ink-500"> ({x.leads.toLocaleString('en-IN')} leads)</span>} value={x.activationRate} max={Math.max(...b.bySegment.map((y) => y.activationRate))} right={pct(x.activationRate)} />)}</div>
      </section>
    </div>
  );
}

function LeadDetail({ id, options, onClose, onSaved }) {
  const [lead, setLead] = useState(null);
  const [error, setError] = useState(null);
  const [status, setStatus] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  useEffect(() => { api.lead(id).then((l) => { setLead(l); setStatus(l.followUpStatus); setNote(l.followUpNote || ''); }).catch(setError); }, [id]);
  const save = async () => { setSaving(true); setError(null); try { const l = await api.updateLead(id, { followUpStatus: status, followUpNote: note }); setLead(l); setSaved(true); onSaved(); } catch (e) { setError(e); } finally { setSaving(false); } };

  return (
    <Modal title={lead ? lead.businessName : 'Lead'} onClose={onClose} wide>
      {error && <Alert tone="error" title={error.message} details={error.details} className="mb-4" />}
      {!lead ? <Spinner /> : (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-2"><Priority p={lead.priority} score={lead.propensityScore} /><span className="text-ink-500">{lead.leadId}, {lead.businessType}, {lead.city} (tier {lead.cityTier})</span></div>
          <dl className="grid gap-x-6 gap-y-3 sm:grid-cols-3">
            {[['Contact', `${lead.contactName} (${lead.contactRole})`], ['Preferred language', lead.preferredLanguage], ['Lead source', lead.leadSource], ['Size', `${lead.employeeCount} employees, ${lead.numSites} location(s)`], ['Internet today', lead.currentInternet], ['Telecom spend', lead.monthlyTelecomSpend ? `${inr(lead.monthlyTelecomSpend)}/month` : 'Not recorded'], ['Stage reached', lead.leadStage], ['Drop-off reason', lead.dropReason || 'None'], ['GSTIN', lead.gstinAvailable ? `${lead.gstinMasked} (${lead.gstinRegistryStatus})` : 'Not available'], ['Udyam', lead.udyamAvailable ? 'Available' : 'Not available'], ['Asked about', lead.productsOfInterest.join(', ') || 'Nothing recorded']].map(([k, v]) => <div key={k}><dt className="text-sm text-ink-500">{k}</dt><dd className="font-medium">{v}</dd></div>)}
          </dl>

          <section>
            <h3 className="text-lg font-semibold">Why this score: {lead.propensityScore} / 100</h3>
            <p className="text-sm text-ink-500">Rule-based demo score. Hand-set points, not a trained machine-learning model.</p>
            <div className="mt-3 space-y-3">
              {lead.scoreBreakdown.map((f) => <div key={f.factor}><Bar label={f.factor} value={f.points} max={f.max} right={`${f.points} / ${f.max}`} tone="bg-brand" /><p className="mt-0.5 text-sm text-ink-500">{f.note}</p></div>)}
            </div>
          </section>

          {lead.needsHumanAssist && <Alert tone="warn" title="Needs a person, not just a link" details={lead.humanAssistReasons} />}
          {lead.digitalFixable && <Alert tone="ok" title="Good fit for the self-serve journey">The reason this lead dropped is one the digital journey removes. Send the self-serve link in {lead.preferredLanguage}.</Alert>}

          <section className="rounded-2xl bg-mist p-4">
            <h3 className="text-lg font-semibold">Recommended bundle: {lead.recommendedBundle.name}</h3>
            <p className="mt-1 text-ink-700">{lead.recommendedBundle.products.map((p) => `${p.name} × ${p.qty}`).join(', ')}</p>
            <p className="mt-2"><span className="text-2xl font-bold">{inr(lead.potentialMonthlyRevenue)}</span> <span className="text-ink-500">potential monthly revenue, plus {inr(lead.recommendedBundle.setup)} one-time setup</span></p>
          </section>

          <section className="space-y-3">
            <h3 className="text-lg font-semibold">Follow-up</h3>
            <div className="grid gap-3 sm:grid-cols-[220px_1fr]">
              <div><label className="label" htmlFor="fu">Status</label><select id="fu" className="field" value={status} onChange={(e) => { setStatus(e.target.value); setSaved(false); }}>{options.map((o) => <option key={o}>{o}</option>)}</select></div>
              <div><label className="label" htmlFor="note">Note</label><input id="note" className="field" maxLength={500} value={note} onChange={(e) => { setNote(e.target.value); setSaved(false); }} placeholder="For example: sent link on WhatsApp, call back Friday" /></div>
            </div>
            <div className="flex flex-wrap items-center gap-3"><button onClick={save} disabled={saving} className="btn-primary btn-sm">{saving ? <Spinner label="" /> : null}Save follow-up</button>{saved && <span className="font-medium text-ok" role="status">Follow-up saved</span>}{lead.followUpUpdatedAt && <span className="text-sm text-ink-500">Last updated {dateTime(lead.followUpUpdatedAt)}</span>}</div>
          </section>
        </div>
      )}
    </Modal>
  );
}

const EMPTY = { q: '', priority: '', stage: '', segment: '', gstin: '', needsHuman: '', digital: '', followUp: '', sort: 'score' };

function Leads({ summary, onChanged }) {
  const [filters, setFilters] = useState(EMPTY);
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [openId, setOpenId] = useState(null);

  const fetchLeads = useCallback(() => {
    setLoading(true);
    const params = Object.fromEntries(Object.entries({ ...filters, page, limit: 15 }).filter(([, v]) => v !== ''));
    return api.leads(params).then((d) => { setData(d); setError(null); }).catch(setError).finally(() => setLoading(false));
  }, [filters, page]);
  useEffect(() => { const t = setTimeout(fetchLeads, filters.q ? 300 : 0); return () => clearTimeout(t); }, [fetchLeads, filters.q]);

  const set = (k) => (e) => { setFilters((f) => ({ ...f, [k]: e.target.value })); setPage(1); };
  const quick = (patch) => { setFilters({ ...EMPTY, ...patch }); setPage(1); };
  const sel = (k, label, children) => <div key={k}><label className="sr-only" htmlFor={`f-${k}`}>{label}</label><select id={`f-${k}`} className="field !min-h-[44px] !py-2 text-[15px]" value={filters[k]} onChange={set(k)}><option value="">{label}: all</option>{children}</select></div>;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <button className={`chip ${filters.priority === 'High' && !filters.needsHuman ? 'chip-on' : ''}`} onClick={() => quick({ priority: 'High' })}><Zap className="h-4 w-4" aria-hidden="true" />High priority ({summary.leads.highPriority.toLocaleString('en-IN')})</button>
        <button className={`chip ${filters.needsHuman === 'true' ? 'chip-on' : ''}`} onClick={() => quick({ needsHuman: 'true' })}><UserRoundCog className="h-4 w-4" aria-hidden="true" />Needs human assistance ({summary.leads.needingHumanAssistance.toLocaleString('en-IN')})</button>
        <button className={`chip ${filters.digital === 'true' ? 'chip-on' : ''}`} onClick={() => quick({ digital: 'true', needsHuman: 'false' })}>Ready for self-serve link</button>
        <button className="chip" onClick={() => quick({})}>Clear filters</button>
      </div>
      <div className="card grid gap-2 p-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="relative sm:col-span-2 lg:col-span-1"><label className="sr-only" htmlFor="f-q">Search business name</label><Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-300" aria-hidden="true" /><input id="f-q" className="field !min-h-[44px] !py-2 !pl-10 text-[15px]" placeholder="Search business name" value={filters.q} onChange={set('q')} /></div>
        {sel('priority', 'Priority', <>{['High', 'Medium', 'Low'].map((x) => <option key={x}>{x}</option>)}</>)}
        {sel('stage', 'Stage', <>{Object.keys(summary.leads.byStage).map((x) => <option key={x}>{x}</option>)}</>)}
        {sel('segment', 'Segment', <>{summary.baseline.bySegment.map((x) => <option key={x.segment}>{x.segment}</option>)}</>)}
        {sel('gstin', 'GSTIN', <><option value="true">Has GSTIN</option><option value="false">No GSTIN</option></>)}
        {sel('followUp', 'Follow-up', <>{(data?.followUpOptions || []).map((x) => <option key={x}>{x}</option>)}</>)}
        <div><label className="sr-only" htmlFor="f-sort">Sort</label><select id="f-sort" className="field !min-h-[44px] !py-2 text-[15px]" value={filters.sort} onChange={set('sort')}><option value="score">Sort: priority score</option><option value="revenue">Sort: potential revenue</option><option value="name">Sort: name</option></select></div>
      </div>

      {error && <Alert tone="error" title={error.message} />}
      {!data ? <PageLoader label="Loading leads" /> : data.items.length === 0 ? <div className="card p-8 text-center"><p className="text-lg font-semibold">No leads match these filters</p><button className="btn-ghost btn-sm mt-3" onClick={() => quick({})}>Clear filters</button></div> : (
        <>
          <p className="text-[15px] text-ink-500" role="status">{data.total.toLocaleString('en-IN')} leads {loading && <Spinner label="" />}</p>
          <div className="card hidden overflow-x-auto md:block">
            <table className="w-full text-left text-[15px]">
              <thead className="border-b border-mist-line text-sm text-ink-500"><tr>{['Score', 'Business', 'Stage reached', 'Drop-off reason', 'Recommended bundle', 'Potential / month', 'Follow-up'].map((h) => <th key={h} scope="col" className="px-4 py-3 font-medium">{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-mist-line">
                {data.items.map((l) => (
                  <tr key={l.leadId} className="cursor-pointer hover:bg-mist" onClick={() => setOpenId(l.leadId)}>
                    <td className="px-4 py-3"><Priority p={l.priority} score={l.propensityScore} /></td>
                    <td className="px-4 py-3"><button className="text-left font-semibold underline-offset-2 hover:underline" onClick={(e) => { e.stopPropagation(); setOpenId(l.leadId); }}>{l.businessName}</button><span className="block text-sm text-ink-500">{l.businessType}, {l.city}{l.gstinAvailable ? '' : ', no GSTIN'}</span></td>
                    <td className="px-4 py-3">{l.leadStage}</td>
                    <td className="px-4 py-3">{l.dropReason}{l.needsHumanAssist && <span className="mt-0.5 flex items-center gap-1 text-sm font-medium text-wait"><UserRoundCog className="h-3.5 w-3.5" aria-hidden="true" />Needs a person</span>}</td>
                    <td className="px-4 py-3">{l.recommendedBundle?.name}</td>
                    <td className="px-4 py-3 font-semibold tabular-nums">{inr(l.potentialMonthlyRevenue)}</td>
                    <td className="px-4 py-3">{l.followUpStatus}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <ul className="space-y-3 md:hidden">
            {data.items.map((l) => (
              <li key={l.leadId}><button className="card w-full p-4 text-left" onClick={() => setOpenId(l.leadId)}>
                <span className="flex items-start justify-between gap-3"><span className="font-semibold">{l.businessName}<span className="block text-sm font-normal text-ink-500">{l.businessType}, {l.city}</span></span><Priority p={l.priority} score={l.propensityScore} /></span>
                <span className="mt-2 block text-[15px] text-ink-700">{l.leadStage}: {l.dropReason}</span>
                <span className="mt-2 flex items-center justify-between gap-3 text-[15px]"><span className="font-semibold tabular-nums">{inr(l.potentialMonthlyRevenue)}/mo</span><span className="text-ink-500">{l.followUpStatus}</span></span>
                {l.needsHumanAssist && <span className="mt-1 flex items-center gap-1 text-sm font-medium text-wait"><UserRoundCog className="h-3.5 w-3.5" aria-hidden="true" />Needs a person</span>}
              </button></li>
            ))}
          </ul>
          <div className="flex items-center justify-between gap-3">
            <button className="btn-ghost btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft className="h-4 w-4" aria-hidden="true" />Previous</button>
            <span className="text-[15px] text-ink-500">Page {data.page} of {data.pages.toLocaleString('en-IN')}</span>
            <button className="btn-ghost btn-sm" disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)}>Next<ChevronRight className="h-4 w-4" aria-hidden="true" /></button>
          </div>
        </>
      )}
      {openId && <LeadDetail id={openId} options={data?.followUpOptions || []} onClose={() => setOpenId(null)} onSaved={() => { fetchLeads(); onChanged(); }} />}
    </div>
  );
}

export default function Partner() {
  const [authed, setAuthed] = useState(() => Boolean(sessionStorage.getItem('ud_partner_code')));
  const [summary, setSummary] = useState(null);
  const [error, setError] = useState(null);
  const [tab, setTab] = useState('leads');

  const loadSummary = useCallback(() => api.summary().then(setSummary).catch((e) => { if (e.status === 401) { sessionStorage.removeItem('ud_partner_code'); setAuthed(false); } else setError(e); }), []);
  useEffect(() => { if (authed) loadSummary(); }, [authed, loadSummary]);

  if (!authed) return <Gate onDone={() => setAuthed(true)} />;
  if (error) return <div className="mx-auto max-w-3xl px-4 py-10"><Alert tone="error" title={error.message} /></div>;
  if (!summary) return <PageLoader label="Loading dashboard" />;
  const L = summary.leads;

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div><h1 className="text-3xl sm:text-4xl">Partner dashboard</h1><p className="mt-1 text-ink-700">Who to call first, who just needs a link, and what each lead is worth.</p></div>
        <button className="font-medium text-ink-500 underline" onClick={() => { sessionStorage.removeItem('ud_partner_code'); setAuthed(false); }}>Lock dashboard</button>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-5">
        {[['Total leads', L.total.toLocaleString('en-IN')], ['Not converted', L.notConverted.toLocaleString('en-IN')], ['Need human assistance', L.needingHumanAssistance.toLocaleString('en-IN')], ['High priority', L.highPriority.toLocaleString('en-IN')], ['Potential monthly revenue, high priority', inrShort(summary.pipeline.potentialMonthlyRevenueHigh)]].map(([k, v], i) => (
          <div key={k} className={`card p-4 ${i === 4 ? 'col-span-2 lg:col-span-1' : ''}`}><p className="text-sm text-ink-500">{k}</p><p className="mt-1 text-2xl font-bold tabular-nums sm:text-3xl">{v}</p></div>
        ))}
      </div>
      <p className="mt-2 text-sm text-ink-500">{summary.scoring.type}: {summary.scoring.note}</p>

      <div className="mt-6 inline-flex rounded-full border border-mist-line bg-white p-1" role="tablist">
        {[['leads', 'Leads to work'], ['metrics', 'Business metrics']].map(([k, label]) => <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`rounded-full px-5 py-2 font-semibold transition-colors ${tab === k ? 'bg-ink text-white' : 'text-ink-500 hover:text-ink'}`}>{label}</button>)}
      </div>
      <div className="mt-5">{tab === 'leads' ? <Leads summary={summary} onChanged={loadSummary} /> : <Metrics s={summary} />}</div>
    </div>
  );
}
