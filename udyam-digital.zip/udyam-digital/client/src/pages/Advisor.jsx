import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, Mic, Pencil, RotateCcw, Send, Volume2, VolumeX, Sparkles, Check } from 'lucide-react';
import { api } from '../lib/api.js';
import { inr } from '../lib/format.js';
import { useApp } from '../lib/store.jsx';
import { Alert, Modal, DemoTag } from '../components/ui.jsx';

const DEMO_SCRIPT = { businessType: 'pharmacy', employees: 5, sites: 1, city: 'Lucknow', currentInternet: 'Home broadband', needs: ['internet', 'pos', 'cctv'], hasGstin: true };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const SpeechRecognition = typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition);

function RecommendationCard({ rec }) {
  const { tr, lang } = useApp();
  const opt = rec.options.find((o) => o.key === rec.recommendedKey) || rec.options[0];
  const t = opt.quote.totals;
  const skipped = opt.skipped.filter((s) => s.need !== 'dependency');
  return (
    <div className="card w-full max-w-xl animate-rise overflow-hidden">
      <div className="bg-ink px-5 py-4 text-white">
        <p className="text-sm font-medium text-ink-300">{tr('Recommended bundle', 'सुझाया गया बंडल')}</p>
        <p className="text-2xl font-bold">{tr(opt.name.en, opt.name.hi)}</p>
      </div>
      <div className="space-y-4 p-5">
        <ul className="space-y-2.5">
          {opt.items.map((it) => {
            const line = opt.quote.lines.find((l) => l.productId === it.productId);
            return (
              <li key={it.productId} className="flex gap-3">
                <Check className="mt-1 h-4 w-4 shrink-0 text-ok" aria-hidden="true" />
                <div><p className="font-semibold">{line.name} × {it.qty} <span className="font-normal text-ink-500">({inr(line.monthly)}{tr('/mo', '/माह')})</span></p><p className="text-[15px] text-ink-700">{it.reason[lang] || it.reason.en}</p></div>
              </li>
            );
          })}
        </ul>
        <dl className="grid grid-cols-3 gap-2 rounded-xl bg-mist p-3 text-center">
          <div><dt className="text-sm text-ink-500">{tr('Monthly', 'मासिक')}</dt><dd className="text-xl font-bold">{inr(t.monthly)}</dd></div>
          <div><dt className="text-sm text-ink-500">{tr('Setup (once)', 'सेटअप (एक बार)')}</dt><dd className="text-xl font-bold">{inr(t.setup)}</dd></div>
          <div><dt className="text-sm text-ink-500">{tr('Contract', 'कॉन्ट्रैक्ट')}</dt><dd className="text-xl font-bold">{t.contractMonths} {tr('mo', 'माह')}</dd></div>
        </dl>
        <div>
          <p className="font-semibold">{tr('Why this suits you', 'यह आपके लिए सही क्यों है')}</p>
          <p className="mt-1 text-[15px] text-ink-700">{opt.explanation[lang] || opt.explanation.en}</p>
        </div>
        {opt.addOns.length > 0 && <p className="text-[15px] text-ink-700"><span className="font-semibold text-ink">{tr('Optional add-ons:', 'वैकल्पिक ऐड-ऑन:')}</span> {opt.addOns.map((a) => a.name).join(', ')}</p>}
        {skipped.length > 0 && (
          <div className="text-[15px] text-ink-700">
            <p className="font-semibold text-ink">{tr('Not offered, and why', 'ये नहीं दिए गए, कारण')}</p>
            <ul className="mt-1 list-disc pl-5">{skipped.map((s) => <li key={s.productId}>{s.name}: {s.reasons.map((r) => r[lang] || r.en).join('; ')}</li>)}</ul>
          </div>
        )}
        {rec.notes.map((n, i) => <p key={i} className="text-sm text-ink-500">{n[lang] || n.en}</p>)}
        <Link to="/bundle" className="btn-primary w-full">{tr('See bundle and full price', 'बंडल और पूरा दाम देखें')}<ArrowRight className="h-5 w-5" aria-hidden="true" /></Link>
        <p className="text-center text-xs text-ink-500">{tr('Products and prices come from the catalogue rules engine', 'प्रोडक्ट और दाम कैटलॉग के नियमों से आते हैं')}{rec.engine !== 'rules' ? tr('; wording by AI', '; भाषा AI द्वारा') : ''}.</p>
      </div>
    </div>
  );
}

// Chips + text box for one question. Used in the chat composer and in the "change answer" pop-up.
function AnswerInput({ question, disabled, onAnswer, autoFocus = false, initial }) {
  const { tr, lang } = useApp();
  const [text, setText] = useState('');
  const [picked, setPicked] = useState(() => new Set(initial || question.suggested || []));
  const [listening, setListening] = useState(false);
  useEffect(() => { setPicked(new Set(initial || question.suggested || [])); setText(''); }, [question.field]); // eslint-disable-line react-hooks/exhaustive-deps

  const submitText = (e) => { e?.preventDefault(); const v = text.trim(); if (!v || disabled) return; setText(''); onAnswer({ message: v }, v); };
  const toggle = (v) => setPicked((s) => { const n = new Set(s); n.has(v) ? n.delete(v) : n.add(v); return n; });
  const listen = () => {
    const r = new SpeechRecognition();
    r.lang = lang === 'hi' ? 'hi-IN' : 'en-IN';
    r.onresult = (ev) => setText(ev.results[0][0].transcript);
    r.onend = () => setListening(false);
    r.onerror = () => setListening(false);
    setListening(true); r.start();
  };
  const multi = question.type === 'multi';
  const cityList = question.field === 'city';

  return (
    <div className="space-y-3">
      <div className={`flex gap-2 ${cityList ? 'flex-nowrap overflow-x-auto pb-1' : 'flex-wrap'}`} role="group" aria-label={question.text}>
        {question.chips?.map((c) => (
          multi
            ? <button key={String(c.value)} type="button" disabled={disabled} aria-pressed={picked.has(c.value)} onClick={() => toggle(c.value)} className={`chip shrink-0 ${picked.has(c.value) ? 'chip-on' : ''}`}>{picked.has(c.value) && <Check className="h-4 w-4" aria-hidden="true" />}{c.label}</button>
            : <button key={String(c.value)} type="button" disabled={disabled} onClick={() => onAnswer({ value: c.value }, c.label)} className="chip shrink-0">{c.label}</button>
        ))}
      </div>
      {multi ? (
        <button type="button" disabled={disabled || picked.size === 0} onClick={() => onAnswer({ value: [...picked] }, question.chips.filter((c) => picked.has(c.value)).map((c) => c.label).join(', '))} className="btn-primary w-full sm:w-auto">{question.doneLabel} ({picked.size})</button>
      ) : (
        <form onSubmit={submitText} className="flex gap-2">
          <label className="sr-only" htmlFor={`answer-${question.field}`}>{question.text}</label>
          <input id={`answer-${question.field}`} autoFocus={autoFocus} className="field" inputMode={question.type === 'number' ? 'numeric' : 'text'} value={text} onChange={(e) => setText(e.target.value)} placeholder={question.placeholder || tr('Or type your answer', 'या अपना जवाब लिखें')} disabled={disabled} maxLength={200} />
          {SpeechRecognition && <button type="button" onClick={listen} disabled={disabled || listening} className={`btn-ghost shrink-0 !px-3.5 ${listening ? '!border-brand !text-brand' : ''}`} aria-label={tr('Speak your answer', 'बोलकर जवाब दें')}><Mic className="h-5 w-5" /></button>}
          <button type="submit" disabled={disabled || !text.trim()} className="btn-dark shrink-0 !px-3.5" aria-label={tr('Send', 'भेजें')}><Send className="h-5 w-5" /></button>
        </form>
      )}
    </div>
  );
}

export default function Advisor() {
  const { tr, lang, acceptRecommendation, recommendation } = useApp();
  const [params, setParams] = useSearchParams();
  const demo = params.get('demo') === 'pharmacy';
  const [sessionId, setSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [question, setQuestion] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [progress, setProgress] = useState({ answered: 0, total: 7 });
  const [typing, setTyping] = useState(false);
  const [error, setError] = useState(null);
  const [edit, setEdit] = useState(null);
  const [speak, setSpeak] = useState(false);
  const [hadPlan] = useState(() => Boolean(recommendation));
  const endRef = useRef(null);
  const started = useRef(false);
  const session = useRef(null);
  const langRef = useRef(lang);

  const say = useCallback((text) => {
    if (!speak || !window.speechSynthesis) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = langRef.current === 'hi' ? 'hi-IN' : 'en-IN';
    window.speechSynthesis.speak(u);
  }, [speak]);

  const apply = useCallback((data, { userText } = {}) => {
    session.current = data.sessionId; setSessionId(data.sessionId);
    setMessages((m) => [...m, ...(userText ? [{ role: 'user', text: userText }] : []), ...data.messages, ...(data.recommendation ? [{ role: 'rec', rec: data.recommendation }] : [])]);
    setQuestion(data.question); setAnswers(data.answers); setProgress(data.progress);
    if (data.recommendation) acceptRecommendation(data.recommendation);
    data.messages.forEach((m) => say(m.text));
  }, [acceptRecommendation, say]);

  const call = useCallback(async (body, userText) => {
    setError(null);
    if (userText) setMessages((m) => [...m, { role: 'user', text: userText }]);
    setTyping(true);
    try {
      const [data] = await Promise.all([api.chat({ sessionId: session.current, lang: langRef.current, ...body }), wait(550)]);
      apply(data);
    } catch (e) { setError(e); } finally { setTyping(false); }
  }, [apply]);

  useEffect(() => { if (started.current) return; started.current = true; call({ action: 'restart' }); }, [call]);
  useEffect(() => { if (langRef.current === lang) return; langRef.current = lang; if (session.current) call({ action: 'lang' }); }, [lang, call]);
  useEffect(() => { const box = endRef.current?.parentElement; if (box) box.scrollTo({ top: box.scrollHeight, behavior: 'smooth' }); }, [messages, typing]);
  useEffect(() => () => window.speechSynthesis?.cancel(), []);

  // Demo autoplay: answers each question for the medical-store scenario, with a short pause so judges can follow.
  useEffect(() => {
    if (!demo || !question || typing) return undefined;
    const value = DEMO_SCRIPT[question.field];
    const labelFor = Array.isArray(value) ? question.chips.filter((c) => value.includes(c.value)).map((c) => c.label).join(', ') : (question.chips?.find((c) => c.value === value)?.label || String(value));
    const timer = setTimeout(() => call({ action: 'answer', value }, labelFor), 1100);
    return () => clearTimeout(timer);
  }, [demo, question, typing, call]);

  const restart = () => { setParams({}); setMessages([]); setAnswers([]); setQuestion(null); call({ action: 'restart' }); };
  const openEdit = async (field) => {
    try { const data = await api.chat({ sessionId: session.current, lang, action: 'question', field }); setEdit(data.editQuestion); } catch (e) { setError(e); }
  };
  const submitEdit = (payload, label) => { const field = edit.field; setEdit(null); call({ action: 'edit', field, ...payload }, `${tr('Change', 'बदलें')}: ${label}`); };

  const done = !question && answers.length > 0;
  return (
    <div className="mx-auto grid max-w-6xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[1fr_320px]">
      <section className="card flex h-[calc(100dvh-13.5rem)] min-h-[460px] flex-col overflow-hidden lg:h-[calc(100dvh-12rem)]" aria-label={tr('Advisor chat', 'सलाहकार चैट')}>
        <header className="flex items-center justify-between gap-3 border-b border-mist-line px-4 py-3 sm:px-5">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand text-white"><Sparkles className="h-5 w-5" aria-hidden="true" /></span>
            <div>
              <h1 className="text-lg leading-tight">{tr('Business advisor', 'बिज़नेस सलाहकार')} {demo && <DemoTag>{tr('Auto demo', 'ऑटो डेमो')}</DemoTag>}</h1>
              <p className="text-sm text-ink-500">{tr('Question', 'सवाल')} {Math.min(progress.answered + 1, progress.total)} / {progress.total}</p>
            </div>
          </div>
          <div className="flex gap-1">
            {window.speechSynthesis && <button onClick={() => { setSpeak((s) => !s); window.speechSynthesis.cancel(); }} className="rounded-full p-2.5 text-ink-500 hover:bg-mist" aria-pressed={speak} aria-label={tr('Read replies aloud', 'जवाब बोलकर सुनाएँ')}>{speak ? <Volume2 className="h-5 w-5 text-brand" /> : <VolumeX className="h-5 w-5" />}</button>}
            <button onClick={restart} className="rounded-full p-2.5 text-ink-500 hover:bg-mist" aria-label={tr('Start again', 'फिर से शुरू करें')}><RotateCcw className="h-5 w-5" /></button>
          </div>
        </header>
        <div className="h-1 bg-mist"><div className="h-full bg-brand transition-all duration-500" style={{ width: `${(progress.answered / progress.total) * 100}%` }} /></div>

        <div className="flex-1 space-y-3 overflow-y-auto bg-mist/60 px-3 py-4 sm:px-5" aria-live="polite">
          {hadPlan && messages.length <= 2 && <Alert tone="info">{tr('You already have a saved plan.', 'आपका एक प्लान सेव है।')} <Link className="font-semibold underline" to="/bundle">{tr('Open it', 'खोलें')}</Link></Alert>}
          {messages.map((m, i) => (
            m.role === 'rec' ? <RecommendationCard key={i} rec={m.rec} />
              : m.role === 'user' ? <div key={i} className="ml-auto w-fit max-w-[85%] animate-rise rounded-2xl rounded-br-md bg-ink px-4 py-2.5 text-white">{m.text}</div>
                : <div key={i} className="w-fit max-w-[85%] animate-rise rounded-2xl rounded-bl-md bg-white px-4 py-2.5 shadow-sm">{m.text}</div>
          ))}
          {typing && <div className="flex w-fit gap-1.5 rounded-2xl rounded-bl-md bg-white px-4 py-3.5 shadow-sm" role="status" aria-label={tr('Advisor is typing', 'सलाहकार लिख रहा है')}>{[0, 1, 2].map((d) => <span key={d} className="h-2 w-2 animate-blip rounded-full bg-ink-500" style={{ animationDelay: `${d * 0.15}s` }} />)}</div>}
          {error && <Alert tone="error" title={error.message} details={error.details}><button className="font-semibold underline" onClick={() => call({ action: 'start' })}>{tr('Try again', 'फिर कोशिश करें')}</button></Alert>}
          <div ref={endRef} />
        </div>

        <footer className="border-t border-mist-line bg-white px-3 py-3 sm:px-5 sm:py-4">
          {question ? <AnswerInput question={question} disabled={typing || demo} onAnswer={(payload, label) => call({ action: 'answer', ...payload }, label)} />
            : done ? <div className="flex flex-wrap gap-2"><Link to="/bundle" className="btn-primary flex-1">{tr('Continue to bundle', 'बंडल पर जाएँ')}<ArrowRight className="h-5 w-5" aria-hidden="true" /></Link><button onClick={restart} className="btn-ghost">{tr('Start again', 'फिर से शुरू करें')}</button></div>
              : <p className="text-ink-500">{tr('Connecting to the advisor…', 'सलाहकार से जुड़ रहे हैं…')}</p>}
        </footer>
      </section>

      <aside className="card h-fit p-5 lg:sticky lg:top-36" aria-label={tr('Your answers', 'आपके जवाब')}>
        <h2 className="text-lg">{tr('Your answers', 'आपके जवाब')}</h2>
        {answers.length === 0 ? <p className="mt-2 text-ink-500">{tr('Your answers will appear here. You can change any of them later.', 'आपके जवाब यहाँ दिखेंगे। आप इन्हें बाद में बदल सकते हैं।')}</p> : (
          <dl className="mt-3 divide-y divide-mist-line">
            {answers.map((a) => (
              <div key={a.field} className="flex items-start justify-between gap-3 py-2.5">
                <div className="min-w-0"><dt className="text-sm text-ink-500">{a.label}</dt><dd className="font-medium">{a.valueLabel}</dd></div>
                <button onClick={() => openEdit(a.field)} disabled={typing || demo} className="shrink-0 rounded-full p-2 text-ink-500 hover:bg-mist hover:text-ink disabled:opacity-40" aria-label={`${tr('Change', 'बदलें')} ${a.label}`}><Pencil className="h-4 w-4" /></button>
              </div>
            ))}
          </dl>
        )}
        {done && <p className="mt-3 text-sm text-ink-500">{tr('Change any answer and the plan is rebuilt instantly.', 'कोई भी जवाब बदलें, प्लान तुरंत दोबारा बन जाएगा।')}</p>}
      </aside>

      {edit && <Modal title={edit.text} onClose={() => setEdit(null)}><AnswerInput question={edit} onAnswer={submitEdit} initial={Array.isArray(answers.find((a) => a.field === edit.field)?.value) ? answers.find((a) => a.field === edit.field).value : undefined} /></Modal>}
    </div>
  );
}
