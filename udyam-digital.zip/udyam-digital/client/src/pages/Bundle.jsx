import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Minus, Plus, Printer, Trash2, Clock, FileText, Wrench, SlidersHorizontal } from 'lucide-react';
import { api } from '../lib/api.js';
import { inr } from '../lib/format.js';
import { useApp } from '../lib/store.jsx';
import { Alert, Spinner } from '../components/ui.jsx';
import PriceSummary from '../components/PriceSummary.jsx';

const DEFAULT_PROFILE = { city: '', cityTier: 2, employees: 1, sites: 1, hasGstin: false };

function Toggle({ checked, onChange, label }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)} className={`relative h-8 w-14 shrink-0 rounded-full transition-colors ${checked ? 'bg-brand' : 'bg-ink-300'}`}>
      <span className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow transition-all ${checked ? 'left-7' : 'left-1'}`} />
    </button>
  );
}

function Stepper({ qty, onChange, label }) {
  return (
    <div className="inline-flex items-center rounded-full border border-mist-line bg-white" role="group" aria-label={label}>
      <button type="button" onClick={() => onChange(qty - 1)} disabled={qty <= 1} className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-mist disabled:opacity-30" aria-label="Decrease"><Minus className="h-4 w-4" /></button>
      <span className="w-8 text-center font-semibold tabular-nums" aria-live="polite">{qty}</span>
      <button type="button" onClick={() => onChange(qty + 1)} disabled={qty >= 200} className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-mist disabled:opacity-30" aria-label="Increase"><Plus className="h-4 w-4" /></button>
    </div>
  );
}

export default function Bundle() {
  const { tr, lang, recommendation, optionKey, chooseOption, cart, setCart, profile, setProfile, bundleName, setBundleName } = useApp();
  const navigate = useNavigate();
  const [quote, setQuote] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [cities, setCities] = useState([]);
  const [showProfile, setShowProfile] = useState(false);
  const seq = useRef(0);
  const p = profile || DEFAULT_PROFILE;
  const option = recommendation?.options.find((o) => o.key === optionKey);
  const reasons = useMemo(() => Object.fromEntries((option?.items || []).map((i) => [i.productId, i.reason])), [option]);
  const inCart = (id) => cart.some((c) => c.productId === id);

  useEffect(() => { api.meta().then((m) => setCities(m.cities)).catch(() => {}); }, []);
  useEffect(() => {
    if (!cart.length) { setQuote(null); return undefined; }
    const my = ++seq.current;
    setLoading(true);
    const timer = setTimeout(() => {
      api.quote(cart, p).then((q) => { if (my === seq.current) { setQuote(q); setError(null); } }).catch((e) => my === seq.current && setError(e)).finally(() => my === seq.current && setLoading(false));
    }, 180);
    return () => clearTimeout(timer);
  }, [cart, profile]); // eslint-disable-line react-hooks/exhaustive-deps

  const setQty = (id, qty) => setCart((c) => c.map((x) => (x.productId === id ? { ...x, qty: Math.min(200, Math.max(1, qty)) } : x)));
  const remove = (id) => { setCart((c) => c.filter((x) => x.productId !== id)); setBundleName((n) => (n && !n.includes('(customised)') ? `${n} (customised)` : n)); };
  const toggleAddOn = (a, on) => { setCart((c) => (on ? [...c, { productId: a.productId, qty: a.qty }] : c.filter((x) => x.productId !== a.productId))); };
  const updateProfile = (patch) => setProfile({ ...p, ...patch });

  if (!cart.length) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <h1 className="text-3xl">{tr('Your bundle is empty', 'आपका बंडल खाली है')}</h1>
        <p className="mt-3 text-ink-700">{tr('Let the advisor build one for you in about a minute, or pick services yourself from the plans.', 'सलाहकार से एक मिनट में बंडल बनवाएँ, या प्लान में से ख़ुद सेवाएँ चुनें।')}</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3"><Link to="/advisor" className="btn-primary">{tr('Ask the advisor', 'सलाहकार से पूछें')}</Link><Link to="/catalogue" className="btn-ghost">{tr('Browse plans', 'प्लान देखें')}</Link></div>
      </div>
    );
  }

  const t = quote?.totals;
  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[15px] font-medium text-brand">{recommendation ? tr('Recommended for your business', 'आपके कारोबार के लिए सुझाव') : tr('Your own selection', 'आपका अपना चुनाव')}</p>
          <h1 className="text-3xl sm:text-4xl">{option && lang === 'hi' && !bundleName.includes('customised') ? option.name.hi : bundleName || tr('Custom bundle', 'कस्टम बंडल')}</h1>
        </div>
        <button onClick={() => window.print()} className="btn-ghost btn-sm no-print"><Printer className="h-4 w-4" aria-hidden="true" />{tr('Print quotation', 'कोटेशन प्रिंट करें')}</button>
      </div>

      {recommendation && recommendation.options.length > 1 && (
        <div className="no-print mt-5 grid gap-3 sm:grid-cols-3" role="radiogroup" aria-label={tr('Bundle options', 'बंडल विकल्प')}>
          {recommendation.options.map((o) => {
            const active = o.key === optionKey && !bundleName.includes('customised');
            return (
              <button key={o.key} role="radio" aria-checked={active} onClick={() => chooseOption(recommendation, o.key)} className={`rounded-2xl border-2 bg-white p-4 text-left transition-colors ${active ? 'border-brand shadow-card' : 'border-mist-line hover:border-ink-300'}`}>
                <span className="flex items-center justify-between gap-2"><span className="font-semibold">{tr(o.name.en, o.name.hi)}</span>{o.key === recommendation.recommendedKey && <span className="rounded-full bg-brand px-2 py-0.5 text-xs font-semibold text-white">{tr('Best fit', 'सबसे सही')}</span>}</span>
                <span className="mt-1 block text-2xl font-bold">{inr(o.quote.totals.monthly)}<span className="text-sm font-medium text-ink-500">{tr(' / month', ' / माह')}</span></span>
                <span className="mt-0.5 block text-sm text-ink-500">{tr(o.tagline.en, o.tagline.hi)}</span>
              </button>
            );
          })}
        </div>
      )}

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_380px]">
        <div className="space-y-6">
          <section className="card divide-y divide-mist-line" aria-label={tr('Services in your bundle', 'आपके बंडल की सेवाएँ')}>
            {(quote?.lines || []).map((l) => (
              <article key={l.productId} className="p-4 sm:p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-ink-500">{l.category}</p>
                    <h2 className="text-lg">{l.name}</h2>
                    <p className="mt-0.5 text-[15px] text-ink-700">{reasons[l.productId] ? reasons[l.productId][lang] || reasons[l.productId].en : l.description}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-lg font-bold tabular-nums">{inr(l.monthly)}</p>
                    <p className="text-sm text-ink-500">{tr('per month', 'प्रति माह')}</p>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                  <ul className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-ink-700">
                    <li>{inr(l.unitPrice)} {l.unit}{l.unitPrice < l.listUnitPrice && <s className="ml-1.5 text-ink-300">{inr(l.listUnitPrice)}</s>}</li>
                    <li className="inline-flex items-center gap-1"><Wrench className="h-3.5 w-3.5" aria-hidden="true" />{l.setup ? `${inr(l.setup)} ${tr('setup', 'सेटअप')}` : tr('No setup fee', 'सेटअप फ़ीस नहीं')}</li>
                    <li className="inline-flex items-center gap-1"><FileText className="h-3.5 w-3.5" aria-hidden="true" />{l.minContractMonths} {tr('month contract', 'माह कॉन्ट्रैक्ट')}</li>
                    <li className="inline-flex items-center gap-1"><Clock className="h-3.5 w-3.5" aria-hidden="true" />{l.installDays} {tr('days to install', 'दिन में इंस्टॉल')}</li>
                  </ul>
                  <div className="no-print flex items-center gap-2">
                    <Stepper qty={l.qty} onChange={(q) => setQty(l.productId, q)} label={`${tr('Quantity of', 'मात्रा')} ${l.name}`} />
                    <button onClick={() => remove(l.productId)} className="rounded-full p-2.5 text-ink-500 hover:bg-brand-soft hover:text-brand" aria-label={`${tr('Remove', 'हटाएँ')} ${l.name}`}><Trash2 className="h-4 w-4" /></button>
                  </div>
                </div>
              </article>
            ))}
            {!quote && <div className="p-6"><Spinner label={tr('Calculating price', 'दाम निकाला जा रहा है')} /></div>}
          </section>

          {option?.addOns.length > 0 && (
            <section className="no-print" aria-label={tr('Optional add-ons', 'वैकल्पिक ऐड-ऑन')}>
              <h2 className="text-xl">{tr('Useful add-ons', 'काम के ऐड-ऑन')}</h2>
              <p className="text-ink-500">{tr('Switch any of these on. The price updates straight away.', 'इनमें से कोई भी चालू करें। दाम तुरंत बदल जाएगा।')}</p>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {option.addOns.map((a) => {
                  const on = inCart(a.productId);
                  return (
                    <div key={a.productId} className={`rounded-2xl border-2 bg-white p-4 transition-colors ${on ? 'border-brand' : 'border-mist-line'}`}>
                      <div className="flex items-start justify-between gap-3">
                        <div><h3 className="font-semibold">{a.name}</h3><p className="text-sm text-ink-500">{inr(a.priceMin)}{a.priceMax > a.priceMin ? `–${inr(a.priceMax).slice(1)}` : ''} {a.unit}{a.setupFeePerUnit ? `, ${inr(a.setupFeePerUnit)} ${tr('setup', 'सेटअप')}` : ''}</p></div>
                        <Toggle checked={on} onChange={(v) => toggleAddOn(a, v)} label={`${tr('Add', 'जोड़ें')} ${a.name}`} />
                      </div>
                      <p className="mt-2 text-[15px] text-ink-700">{a.reason[lang] || a.reason.en}</p>
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {option && (
            <section className="card p-5">
              <h2 className="text-xl">{tr('Why this bundle', 'यह बंडल क्यों')}</h2>
              <p className="mt-2 text-ink-700">{option.explanation[lang] || option.explanation.en}</p>
              {option.skipped.filter((s) => s.need !== 'dependency').length > 0 && (
                <div className="mt-3"><p className="font-semibold">{tr('Considered but not offered', 'देखे गए पर नहीं दिए गए')}</p>
                  <ul className="mt-1 list-disc pl-5 text-[15px] text-ink-700">{option.skipped.filter((s) => s.need !== 'dependency').map((s) => <li key={s.productId}>{s.name}: {s.reasons.map((r) => r[lang] || r.en).join('; ')}</li>)}</ul></div>
              )}
            </section>
          )}

          <section className="card no-print p-5">
            <button className="flex w-full items-center justify-between gap-3 text-left" onClick={() => setShowProfile((s) => !s)} aria-expanded={showProfile}>
              <span><span className="block text-lg font-semibold">{tr('Eligibility details', 'पात्रता की जानकारी')}</span><span className="text-[15px] text-ink-500">{p.city || `Tier ${p.cityTier}`}, {p.employees} {tr('employees', 'कर्मचारी')}, {p.sites} {tr('location(s)', 'लोकेशन')}, GSTIN: {p.hasGstin ? tr('yes', 'हाँ') : tr('no', 'नहीं')}</span></span>
              <SlidersHorizontal className="h-5 w-5 shrink-0 text-ink-500" aria-hidden="true" />
            </button>
            {showProfile && (
              <div className="mt-4 grid gap-4 sm:grid-cols-4">
                <div><label className="label" htmlFor="p-city">{tr('City', 'शहर')}</label><select id="p-city" className="field" value={p.city} onChange={(e) => updateProfile({ city: e.target.value, cityTier: cities.find((c) => c.city === e.target.value)?.tier || 2 })}><option value="">{tr('Other (tier 2)', 'अन्य (टियर 2)')}</option>{cities.map((c) => <option key={c.city} value={c.city}>{c.city} (tier {c.tier})</option>)}</select></div>
                <div><label className="label" htmlFor="p-emp">{tr('Employees', 'कर्मचारी')}</label><input id="p-emp" type="number" min="1" max="5000" className="field" value={p.employees} onChange={(e) => updateProfile({ employees: Math.max(1, Number(e.target.value) || 1) })} /></div>
                <div><label className="label" htmlFor="p-sites">{tr('Locations', 'लोकेशन')}</label><input id="p-sites" type="number" min="1" max="500" className="field" value={p.sites} onChange={(e) => updateProfile({ sites: Math.max(1, Number(e.target.value) || 1) })} /></div>
                <div><span className="label">{tr('Have a GSTIN?', 'GSTIN है?')}</span><div className="flex h-12 items-center gap-3"><Toggle checked={p.hasGstin} onChange={(v) => updateProfile({ hasGstin: v })} label="GSTIN" /><span>{p.hasGstin ? tr('Yes', 'हाँ') : tr('No', 'नहीं')}</span></div></div>
              </div>
            )}
          </section>
        </div>

        <aside className="h-fit lg:sticky lg:top-36">
          <div className="card p-5">
            <h2 className="text-xl">{tr('Price breakdown', 'दाम का ब्योरा')} {loading && <Spinner label="" />}</h2>
            <div className="mt-4"><PriceSummary quote={quote} /></div>
            {error && <Alert tone="error" className="mt-4" title={error.message} details={error.details} />}
            {quote && !quote.valid && <Alert tone="warn" className="mt-4" title={tr('Please fix this before checkout', 'चेकआउट से पहले इसे ठीक करें')} details={quote.issues.map((i) => i[lang] || i.en)} />}
            <button disabled={!quote?.valid || loading} onClick={() => navigate('/checkout')} className="btn-primary no-print mt-5 hidden w-full lg:inline-flex">{tr('Proceed to checkout', 'चेकआउट पर जाएँ')}<ArrowRight className="h-5 w-5" aria-hidden="true" /></button>
            <Link to="/catalogue" className="no-print mt-3 block text-center font-medium text-ink-700 underline">{tr('Add more services from plans', 'प्लान से और सेवाएँ जोड़ें')}</Link>
          </div>
        </aside>
      </div>

      <div className="no-print fixed inset-x-0 bottom-[57px] z-30 border-t border-mist-line bg-white px-4 py-3 shadow-lift md:bottom-0 lg:hidden">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3">
          <div><p className="text-sm text-ink-500">{tr('Monthly', 'मासिक')}</p><p className="text-xl font-bold tabular-nums">{t ? inr(t.monthly) : '…'}</p></div>
          <button disabled={!quote?.valid || loading} onClick={() => navigate('/checkout')} className="btn-primary">{tr('Proceed to checkout', 'चेकआउट पर जाएँ')}<ArrowRight className="h-5 w-5" aria-hidden="true" /></button>
        </div>
      </div>
      <div className="h-20 lg:hidden" />
    </div>
  );
}
