"""
Drives the whole judge-demo journey in a headless browser and saves screenshots.
Used to test the UI on laptop and phone sizes and to produce the images in docs/screenshots.

Needs: the server running with the site built (see README "one URL" mode), plus
       pip install playwright && playwright install chromium
Run:   python3 tools/ui_walkthrough.py desktop      (or: mobile)
"""
import os, re, sys
from playwright.sync_api import sync_playwright

BASE = os.environ.get('SITE', 'http://localhost:4000')
OUT = os.environ.get('SHOTS', os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'docs', 'screenshots'))
mode = sys.argv[1] if len(sys.argv) > 1 else 'desktop'
vp = {'desktop': {'width': 1366, 'height': 850}, 'mobile': {'width': 390, 'height': 844}}[mode]
os.makedirs(OUT, exist_ok=True)
errors = []

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport=vp, device_scale_factor=2 if mode == 'mobile' else 1, is_mobile=(mode == 'mobile'), has_touch=(mode == 'mobile'))
    pg = ctx.new_page()
    pg.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    pg.on('pageerror', lambda e: errors.append('PAGEERROR ' + str(e)))
    def shot(n, full=False):
        pg.screenshot(path=f'{OUT}/{mode}-{n}.png', full_page=full)

    pg.goto(BASE); pg.wait_for_selector('text=Recommended for you'); pg.wait_for_timeout(500); shot('01-landing', True)
    pg.goto(BASE + '/advisor?demo=pharmacy')
    pg.wait_for_selector('text=See bundle and full price', timeout=40000); pg.wait_for_timeout(600); shot('02-advisor')
    pg.click('text=See bundle and full price'); pg.wait_for_selector('text=Pay today'); pg.wait_for_timeout(400); shot('03-bundle', True)
    pg.locator('[role=switch]').first.click(); pg.wait_for_timeout(900); shot('03b-bundle-addon', True)
    pg.locator('button:has-text("Proceed to checkout"):visible').first.click(); pg.wait_for_selector('text=Quotation and checkout')
    pg.select_option('#sample', 'D01'); pg.wait_for_timeout(300)
    pg.locator('input[type=checkbox]').check(); shot('04-checkout', True)
    pg.click('button[type=submit]'); pg.wait_for_selector('text=Order placed'); pg.click('text=Stay on this page'); shot('05-confirmation', True)
    oid = re.search(r'UD-\d{6}-[A-Z0-9]{6}', pg.content()).group(0); print('order', oid)
    pg.click('text=Continue to KYC'); pg.wait_for_selector('text=What we collect'); shot('06-kyc-consent', True)
    pg.locator('input[type=checkbox]').check(); pg.click('text=I agree, start KYC'); pg.wait_for_selector('text=Fill sample GSTIN')
    pg.click('text=Fill sample GSTIN'); pg.click('button:has-text("Check GSTIN")'); pg.wait_for_selector('text=Fill sample Udyam number')
    pg.click('text=Fill sample Udyam number'); pg.click('button:has-text("Check Udyam")'); pg.wait_for_selector('text=Use sample document')
    pg.locator('button[aria-expanded]:has-text("GSTIN check")').click(); pg.wait_for_timeout(300); shot('07-kyc-gstin', True)
    pg.locator('button[aria-expanded]:has-text("Documents")').click(); pg.wait_for_selector('text=Use sample document')
    for i in range(4):
        pg.locator('button:has-text("Use sample document")').nth(i).click()
        pg.wait_for_selector('text=Reading the document', timeout=5000)
        pg.wait_for_selector('text=Reading the document', state='detached', timeout=60000)
    pg.wait_for_selector('text=KYC approved'); pg.wait_for_timeout(300); shot('08-kyc-documents', True)
    pg.click('text=Choose installation date'); pg.wait_for_selector('text=Choose your installation date'); shot('09-tracker-slot', True)
    pg.locator('fieldset').nth(0).locator('button').first.click(); pg.locator('fieldset').nth(1).locator('button').first.click(); pg.click('text=Book installation')
    pg.wait_for_selector('text=Simulate next stage'); pg.click('text=Simulate next stage'); pg.wait_for_timeout(800); shot('10-tracker-progress', True)
    pg.click('text=Simulate next stage'); pg.wait_for_selector('text=Your services are active'); pg.wait_for_timeout(800); shot('11-tracker-activated', True)
    pg.goto(BASE + '/catalogue'); pg.wait_for_selector('text=All plans and services'); pg.wait_for_timeout(400); shot('12-catalogue')
    pg.goto(BASE + '/partner'); pg.fill('#code', 'partner-demo'); pg.click('text=Open dashboard')
    pg.wait_for_selector('tbody tr:visible, ul.space-y-3 li:visible', timeout=20000); pg.wait_for_timeout(500); shot('13-partner-leads', True)
    pg.locator('tbody tr:visible, ul.space-y-3 li button:visible').first.click(); pg.wait_for_selector('text=Why this score'); pg.wait_for_timeout(400); shot('14-partner-lead-detail')
    pg.locator('[aria-label=Close]').click(); pg.click('text=Business metrics'); pg.wait_for_selector('text=What-if calculator'); pg.wait_for_timeout(300); shot('15-partner-metrics', True)
    for path in ['/', '/advisor', '/catalogue', '/track', f'/track/{oid}', f'/kyc/{oid}', '/partner']:
        pg.goto(BASE + path); pg.wait_for_timeout(900)
        ov = pg.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth')
        if ov > 1: print('SIDEWAYS SCROLL on', path, ov, 'px')
    b.close()
print('browser console errors:', errors[:10] or 'none')
