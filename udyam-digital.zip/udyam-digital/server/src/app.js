const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const config = require('./config');
const { notFoundHandler, errorHandler } = require('./middleware/errors');

function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: 'cross-origin' } }));
  app.use(cors({ origin: [config.clientOrigin, 'http://localhost:5173', 'http://127.0.0.1:5173'], allowedHeaders: ['Content-Type', 'x-partner-code'] }));
  app.use(express.json({ limit: '100kb' }));
  app.use('/api', rateLimit({ windowMs: 60 * 1000, limit: 600, standardHeaders: true, legacyHeaders: false, message: { ok: false, error: { message: 'Too many requests. Please slow down.' } } }));

  app.get('/api/health', (req, res) => res.json({ ok: true, data: { status: 'up', time: new Date().toISOString() } }));
  app.use('/api/advisor', require('./routes/advisor'));
  app.use('/api/products', require('./routes/products'));
  app.use('/api/kyc', require('./routes/kyc'));
  app.use('/api/orders', require('./routes/orders'));
  app.use('/api/dashboard', require('./routes/dashboard'));
  app.use('/api', require('./routes/meta'));
  app.use('/api', notFoundHandler);

  // If the React app has been built (npm run build), serve it from the same server so one URL runs everything.
  const dist = path.join(__dirname, '..', '..', 'client', 'dist');
  if (fs.existsSync(path.join(dist, 'index.html'))) {
    app.use(express.static(dist));
    app.get('*', (req, res) => res.sendFile(path.join(dist, 'index.html')));
  }

  app.use(errorHandler);
  return app;
}

module.exports = { createApp };
