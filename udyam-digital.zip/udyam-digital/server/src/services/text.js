// Small text helpers shared by KYC matching, masking and search.

const STOP = new Set(['prop', 'the', 'and', 'of', 'shop', 'unit', 'm', 's']);

function normalise(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/\bpvt\b\.?/g, 'private')
    .replace(/\bltd\b\.?/g, 'limited')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function tokens(s) {
  return normalise(s).split(' ').filter((t) => t && !STOP.has(t));
}

function levenshtein(a, b) {
  if (a === b) return 0;
  const m = a.length, n = b.length;
  if (!m) return n;
  if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, i) => i);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    prev = cur;
  }
  return prev[n];
}

// 0..1 similarity that tolerates OCR noise and word order.
function similarity(a, b) {
  const ta = tokens(a), tb = tokens(b);
  if (!ta.length || !tb.length) return 0;
  const sa = ta.join(' '), sb = tb.join(' ');
  const charSim = 1 - levenshtein(sa, sb) / Math.max(sa.length, sb.length);
  const setB = new Set(tb);
  const overlap = ta.filter((t) => setB.has(t)).length / Math.max(ta.length, tb.length);
  return Math.max(charSim, overlap);
}

// Similarity for addresses: ignores spacing completely because OCR wraps long lines mid-word.
function addressSimilarity(a, b) {
  const sa = normalise(a).replace(/\s/g, ''), sb = normalise(b).replace(/\s/g, '');
  if (!sa || !sb) return 0;
  return 1 - levenshtein(sa, sb) / Math.max(sa.length, sb.length);
}

const maskMiddle = (s, head, tail) => {
  const v = String(s || '');
  if (v.length <= head + tail) return v ? '•'.repeat(v.length) : '';
  return v.slice(0, head) + '•'.repeat(v.length - head - tail) + v.slice(-tail);
};
const maskGstin = (g) => maskMiddle(g, 2, 3);
const maskUdyam = (u) => { const v = String(u || ''); return v.length > 4 ? v.slice(0, -7) + '•••' + v.slice(-4) : v; };
const maskMobile = (m) => maskMiddle(String(m || '').replace(/\D/g, ''), 2, 2);
const maskEmail = (e) => {
  const [u, d] = String(e || '').split('@');
  if (!d) return '';
  return (u.length <= 2 ? u[0] + '•' : u[0] + '•'.repeat(Math.min(u.length - 2, 6)) + u.slice(-1)) + '@' + d;
};

module.exports = { normalise, tokens, similarity, addressSimilarity, levenshtein, maskGstin, maskUdyam, maskMobile, maskEmail };
