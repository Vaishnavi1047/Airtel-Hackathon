// Loads the hackathon CSV files once at start-up, validates their columns and builds fast look-up indexes.
// Column names are taken from the dataset README and checked against the real file headers,
// so a renamed or missing column fails loudly instead of silently producing wrong numbers.

const fs = require('fs');
const path = require('path');
const csv = require('csv-parser');
const config = require('../config');

const REQUIRED = {
  'product_catalogue.csv': ['product_id', 'category', 'product_name', 'description', 'unit', 'price_min_inr_per_month', 'price_max_inr_per_month', 'one_time_setup_inr', 'min_contract_months', 'available_city_tiers', 'min_employees', 'min_sites', 'requires_gstin', 'requires_one_of', 'typical_install_days', 'target_segments'],
  'mock_gstin_registry.csv': ['gstin', 'legal_name', 'trade_name', 'constitution', 'principal_place_of_business', 'state', 'registration_date', 'status'],
  'mock_udyam_registry.csv': ['udyam_number', 'enterprise_name', 'enterprise_type', 'major_activity', 'nic_description', 'state', 'city', 'date_of_registration'],
  'smb_leads.csv': ['lead_id', 'created_date', 'lead_source', 'business_name', 'business_type', 'segment', 'city', 'city_tier', 'state', 'preferred_language', 'employee_count', 'num_sites', 'has_gstin', 'gstin', 'has_udyam', 'udyam_number', 'current_internet', 'products_of_interest', 'contact_name', 'contact_role', 'stage_reached', 'outcome', 'drop_reason', 'days_lead_to_activation', 'customer_follow_up_calls', 'acquisition_cost_inr'],
};

const str = (v) => (v === undefined || v === null ? '' : String(v).trim());
const num = (v, fallback = null) => { const s = str(v); if (s === '') return fallback; const n = Number(s); return Number.isFinite(n) ? n : fallback; };
const yes = (v) => str(v).toUpperCase() === 'Y';
const list = (v, sep) => str(v).split(sep).map((x) => x.trim()).filter(Boolean);

function readCsv(file) {
  const full = path.join(config.dataDir, file);
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(full)) return reject(new Error(`Data file not found: ${full}. Put the hackathon CSV files in the "data" folder.`));
    const rows = [];
    let headers = [];
    fs.createReadStream(full)
      .pipe(csv({ mapHeaders: ({ header }) => header.replace(/^\uFEFF/, '').trim() }))
      .on('headers', (h) => { headers = h; })
      .on('data', (r) => rows.push(r))
      .on('error', reject)
      .on('end', () => {
        const missing = REQUIRED[file].filter((c) => !headers.includes(c));
        if (missing.length) return reject(new Error(`${file} is missing expected column(s): ${missing.join(', ')}. Found: ${headers.join(', ')}`));
        resolve(rows);
      });
  });
}

const store = {
  loaded: false,
  products: [], productById: new Map(),
  gstin: new Map(), udyam: new Map(),
  leads: [], cityTier: new Map(), cityState: new Map(),
  demoApplicants: [],
  warnings: [],
};

async function load() {
  if (store.loaded) return store;
  const [products, gst, udyam, leads] = await Promise.all(Object.keys(REQUIRED).map(readCsv));

  store.products = products.map((r) => ({
    id: str(r.product_id),
    category: str(r.category),
    name: str(r.product_name),
    description: str(r.description),
    unit: str(r.unit),
    priceMin: num(r.price_min_inr_per_month, 0),
    priceMax: num(r.price_max_inr_per_month, 0),
    setupFee: num(r.one_time_setup_inr, 0),
    minContractMonths: num(r.min_contract_months, 1),
    cityTiers: list(r.available_city_tiers, ';').map(Number),
    minEmployees: num(r.min_employees, 1),
    minSites: num(r.min_sites, 1),
    requiresGstin: yes(r.requires_gstin),
    requiresOneOf: list(r.requires_one_of, '|'),
    installDays: num(r.typical_install_days, 0),
    targetSegments: list(r.target_segments, ';'),
  })).filter((p) => {
    const ok = p.id && p.name && p.priceMin > 0 && p.priceMax >= p.priceMin;
    if (!ok) store.warnings.push(`Skipped catalogue row with missing id/name/price: ${JSON.stringify(p)}`);
    return ok;
  });
  store.productById = new Map(store.products.map((p) => [p.id, p]));

  for (const r of gst) {
    const id = str(r.gstin).toUpperCase();
    if (!id) continue;
    store.gstin.set(id, {
      gstin: id, legalName: str(r.legal_name), tradeName: str(r.trade_name), constitution: str(r.constitution),
      address: str(r.principal_place_of_business), state: str(r.state), registrationDate: str(r.registration_date), status: str(r.status) || 'Unknown',
    });
  }
  for (const r of udyam) {
    const id = str(r.udyam_number).toUpperCase();
    if (!id) continue;
    store.udyam.set(id, {
      udyamNumber: id, enterpriseName: str(r.enterprise_name), enterpriseType: str(r.enterprise_type), majorActivity: str(r.major_activity),
      nicDescription: str(r.nic_description), state: str(r.state), city: str(r.city), registrationDate: str(r.date_of_registration),
    });
  }

  store.leads = leads.map((r) => ({
    leadId: str(r.lead_id), createdDate: str(r.created_date), leadSource: str(r.lead_source),
    businessName: str(r.business_name), businessType: str(r.business_type), segment: str(r.segment),
    city: str(r.city), cityTier: num(r.city_tier, 2), state: str(r.state), preferredLanguage: str(r.preferred_language),
    employeeCount: num(r.employee_count, 1), numSites: num(r.num_sites, 1), turnoverBand: str(r.annual_turnover_band),
    hasGstin: yes(r.has_gstin), gstin: str(r.gstin).toUpperCase(), hasUdyam: yes(r.has_udyam), udyamNumber: str(r.udyam_number).toUpperCase(),
    currentInternet: str(r.current_internet) || 'Not recorded', currentProvider: str(r.current_provider) || 'Not recorded',
    monthlyTelecomSpend: num(r.monthly_telecom_spend_inr, null),
    productsOfInterest: list(r.products_of_interest, ';'),
    contactName: str(r.contact_name), contactRole: str(r.contact_role),
    stageReached: str(r.stage_reached), outcome: str(r.outcome), dropReason: str(r.drop_reason),
    daysToActivation: num(r.days_lead_to_activation, null), followUpCalls: num(r.customer_follow_up_calls, 0),
    bundleProducts: str(r.bundle_products), monthlyBundleValue: num(r.monthly_bundle_value_inr, null),
    acquisitionCost: num(r.acquisition_cost_inr, 0),
  })).filter((l) => l.leadId);

  for (const l of store.leads) {
    if (l.city && !store.cityTier.has(l.city)) { store.cityTier.set(l.city, l.cityTier); store.cityState.set(l.city, l.state); }
  }

  const demoFile = path.join(config.dataDir, 'demo_applicants.json');
  if (fs.existsSync(demoFile)) store.demoApplicants = JSON.parse(fs.readFileSync(demoFile, 'utf8'));

  store.loaded = true;
  return store;
}

const cities = () => [...store.cityTier.entries()].map(([city, tier]) => ({ city, tier, state: store.cityState.get(city) })).sort((a, b) => a.city.localeCompare(b.city));
// Cities outside the dataset are treated as tier 2 (the more restrictive tier), and the UI says so.
const tierForCity = (city) => store.cityTier.get(str(city)) || [...store.cityTier.entries()].find(([c]) => c.toLowerCase() === str(city).toLowerCase())?.[1] || 2;

module.exports = { load, store, cities, tierForCity };
