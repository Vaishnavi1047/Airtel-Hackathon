// All customer-facing advisor wording (English + Hindi) and the option lists the advisor offers.

const CATEGORIES = [
  { id: 'kirana', en: 'Kirana / Retail', hi: 'किराना / रिटेल', segment: 'micro', keywords: ['kirana', 'retail', 'shop', 'store', 'dukan', 'दुकान', 'किराना', 'general', 'boutique', 'stationery', 'hardware', 'salon'], addOns: ['P19', 'P23', 'P22', 'P09', 'P15', 'P18', 'P07'] },
  { id: 'pharmacy', en: 'Pharmacy', hi: 'फार्मेसी / मेडिकल स्टोर', segment: 'micro', keywords: ['pharmacy', 'medical', 'chemist', 'medicine', 'दवा की दुकान', 'मेडिकल स्टोर', 'दवाई', 'दवा', 'मेडिकल', 'फार्मेसी', 'केमिस्ट'], addOns: ['P09', 'P19', 'P23', 'P22', 'P15', 'P07', 'P14', 'P11'] },
  { id: 'clinic', en: 'Clinic', hi: 'क्लिनिक', segment: 'prof', keywords: ['clinic', 'doctor', 'dental', 'physio', 'lab', 'hospital', 'क्लिनिक', 'डॉक्टर'], addOns: ['P09', 'P12', 'P15', 'P22', 'P17', 'P23', 'P16', 'P20'] },
  { id: 'coaching', en: 'Coaching Centre', hi: 'कोचिंग सेंटर', segment: 'prof', keywords: ['coaching', 'tuition', 'school', 'institute', 'classes', 'कोचिंग', 'ट्यूशन'], addOns: ['P22', 'P15', 'P14', 'P23', 'P18', 'P09', 'P16'] },
  { id: 'restaurant', en: 'Restaurant', hi: 'रेस्टोरेंट', segment: 'micro', keywords: ['restaurant', 'cafe', 'hotel', 'dhaba', 'bakery', 'sweet', 'food', 'रेस्टोरेंट', 'ढाबा', 'होटल'], addOns: ['P19', 'P22', 'P23', 'P09', 'P15', 'P13', 'P18'] },
  { id: 'professional', en: 'CA / Professional Office', hi: 'सीए / प्रोफेशनल ऑफिस', segment: 'prof', keywords: ['ca', 'chartered', 'law', 'lawyer', 'office', 'consult', 'architect', 'insurance', 'agency', 'सीए', 'ऑफिस', 'वकील'], addOns: ['P16', 'P17', 'P20', 'P09', 'P12', 'P11', 'P08'] },
  { id: 'manufacturing', en: 'Manufacturing', hi: 'मैन्युफैक्चरिंग', segment: 'mfg', keywords: ['manufactur', 'factory', 'unit', 'workshop', 'plant', 'press', 'फैक्ट्री', 'कारखाना', 'उद्योग'], addOns: ['P24', 'P21', 'P23', 'P09', 'P25', 'P20', 'P17', 'P11'] },
  { id: 'other', en: 'Other', hi: 'अन्य', segment: 'micro', keywords: ['other', 'अन्य'], addOns: ['P09', 'P22', 'P23', 'P15', 'P18', 'P16'] },
];

const INTERNET = [
  { id: 'Mobile hotspot', en: 'Mobile hotspot', hi: 'मोबाइल हॉटस्पॉट', keywords: ['hotspot', 'mobile', 'phone', 'sim', 'हॉटस्पॉट', 'मोबाइल'] },
  { id: 'Home broadband', en: 'Home broadband', hi: 'घरेलू ब्रॉडबैंड', keywords: ['home', 'घर'] },
  { id: 'Business broadband', en: 'Business broadband', hi: 'बिज़नेस ब्रॉडबैंड', keywords: ['business', 'fibre', 'fiber', 'broadband', 'wifi', 'ब्रॉडबैंड', 'फाइबर'] },
  { id: 'Leased line', en: 'Leased line', hi: 'लीज़्ड लाइन', keywords: ['leased', 'ill', 'लीज़'] },
  { id: 'No internet yet', en: 'No internet yet', hi: 'अभी इंटरनेट नहीं है', keywords: ['no', 'none', 'nothing', 'नहीं', 'कुछ नहीं'] },
];

// What the owner can ask for, in their words. Each need maps to catalogue products inside recommender.js.
const NEEDS = [
  { id: 'internet', en: 'Reliable internet', hi: 'भरोसेमंद इंटरनेट', keywords: ['internet', 'broadband', 'fibre', 'fiber', 'wifi', 'इंटरनेट', 'नेट'] },
  { id: 'pos', en: 'UPI / POS billing', hi: 'UPI / POS बिलिंग', keywords: ['upi', 'pos', 'billing', 'payment', 'card', 'बिलिंग', 'पेमेंट', 'यूपीआई'] },
  { id: 'cctv', en: 'CCTV', hi: 'सीसीटीवी', keywords: ['cctv', 'camera', 'security camera', 'कैमरा', 'सीसीटीवी'] },
  { id: 'backup', en: 'Backup internet', hi: 'बैकअप इंटरनेट', keywords: ['backup internet', 'failover', 'always on', 'बैकअप'] },
  { id: 'mobile', en: 'Mobile lines for staff', hi: 'स्टाफ़ के लिए मोबाइल कनेक्शन', keywords: ['postpaid', 'mobile line', 'sim', 'staff phone', 'मोबाइल कनेक्शन', 'पोस्टपेड'] },
  { id: 'wifi', en: 'Customer Wi-Fi', hi: 'ग्राहकों के लिए Wi-Fi', keywords: ['guest', 'customer wifi', 'wi-fi', 'वाई-फाई', 'वाईफाई'] },
  { id: 'telephony', en: 'Office phone / IVR', hi: 'ऑफिस फ़ोन / IVR', keywords: ['ivr', 'telephony', 'landline', 'toll', 'call recording', 'phone line', 'आईवीआर', 'फ़ोन लाइन'] },
  { id: 'marketing', en: 'WhatsApp / SMS to customers', hi: 'ग्राहकों को WhatsApp / SMS', keywords: ['whatsapp', 'sms', 'marketing', 'promotion', 'व्हाट्सएप', 'एसएमएस'] },
  { id: 'email', en: 'Business email & office apps', hi: 'बिज़नेस ईमेल और ऑफिस ऐप', keywords: ['email', 'mail', 'office suite', 'documents', 'ईमेल'] },
  { id: 'website', en: 'Website', hi: 'वेबसाइट', keywords: ['website', 'domain', 'online presence', 'वेबसाइट'] },
  { id: 'security', en: 'Device & network security', hi: 'डिवाइस और नेटवर्क सुरक्षा', keywords: ['antivirus', 'firewall', 'ransomware', 'virus', 'cyber', 'सुरक्षा', 'एंटीवायरस'] },
  { id: 'databackup', en: 'Data backup', hi: 'डेटा बैकअप', keywords: ['data backup', 'cloud backup', 'डेटा बैकअप'] },
  { id: 'iot', en: 'Machine monitoring', hi: 'मशीन मॉनिटरिंग', keywords: ['machine', 'iot', 'sensor', 'मशीन'] },
  { id: 'fleet', en: 'Vehicle tracking', hi: 'वाहन ट्रैकिंग', keywords: ['fleet', 'vehicle', 'gps', 'delivery van', 'गाड़ी', 'वाहन'] },
];

const NEED_DEFAULTS = {
  kirana: ['internet', 'pos', 'cctv'], pharmacy: ['internet', 'pos', 'cctv'], clinic: ['internet', 'telephony', 'wifi'],
  coaching: ['internet', 'wifi', 'marketing'], restaurant: ['internet', 'pos', 'wifi'], professional: ['internet', 'email', 'databackup'],
  manufacturing: ['internet', 'security', 'iot'], other: ['internet', 'mobile'],
};

const T = {
  welcome: {
    en: 'Namaste! I am your Udyam Digital advisor. Answer 7 quick questions and I will build a ready-to-buy plan for your business, with clear prices.',
    hi: 'नमस्ते! मैं आपका उद्यम डिजिटल सलाहकार हूँ। 7 छोटे सवालों के जवाब दीजिए और मैं आपके कारोबार के लिए साफ़ दामों वाला तैयार प्लान बना दूँगा।',
  },
  q: {
    businessType: { en: 'What type of business do you operate?', hi: 'आप किस तरह का कारोबार चलाते हैं?' },
    employees: { en: 'How many employees do you have (including you)?', hi: 'आपके यहाँ कितने लोग काम करते हैं (आपको मिलाकर)?' },
    sites: { en: 'How many business locations do you operate?', hi: 'आपकी कितनी दुकानें / लोकेशन हैं?' },
    city: { en: 'Which city is your business in? Some services depend on the city.', hi: 'आपका कारोबार किस शहर में है? कुछ सेवाएँ शहर पर निर्भर करती हैं।' },
    currentInternet: { en: 'What is your current internet setup?', hi: 'अभी आप कौन-सा इंटरनेट इस्तेमाल करते हैं?' },
    needs: { en: 'Which digital services do you need? Pick all that apply, then tap Done.', hi: 'आपको कौन-सी डिजिटल सेवाएँ चाहिए? जो भी चाहिए चुनें, फिर "हो गया" दबाएँ।' },
    hasGstin: { en: 'Do you have a valid GSTIN? A few services can only be sold with an active GSTIN.', hi: 'क्या आपके पास वैध GSTIN है? कुछ सेवाएँ केवल सक्रिय GSTIN पर ही मिलती हैं।' },
  },
  retry: {
    businessType: { en: 'I did not catch that. Please tap one of the options below.', hi: 'मैं समझ नहीं पाया। कृपया नीचे दिए विकल्पों में से एक चुनें।' },
    employees: { en: 'Please tell me a number, for example 5.', hi: 'कृपया एक संख्या बताइए, जैसे 5।' },
    sites: { en: 'Please tell me a number, for example 1.', hi: 'कृपया एक संख्या बताइए, जैसे 1।' },
    city: { en: 'Please type your city name or pick one below.', hi: 'कृपया अपने शहर का नाम लिखें या नीचे से चुनें।' },
    currentInternet: { en: 'Please pick the option closest to your current setup.', hi: 'कृपया अपने मौजूदा इंटरनेट से मिलता-जुलता विकल्प चुनें।' },
    needs: { en: 'Please pick at least one service.', hi: 'कृपया कम से कम एक सेवा चुनें।' },
    hasGstin: { en: 'Please answer Yes or No.', hi: 'कृपया हाँ या नहीं में जवाब दें।' },
  },
  ack: {
    en: ['Got it.', 'Thanks.', 'Noted.', 'Great.'],
    hi: ['ठीक है।', 'धन्यवाद।', 'नोट कर लिया।', 'बढ़िया।'],
  },
  cityOther: { en: 'This city is not in our list yet, so I will use tier-2 availability for it.', hi: 'यह शहर अभी हमारी सूची में नहीं है, इसलिए मैं टियर-2 की उपलब्धता मानकर चलूँगा।' },
  done: { en: 'Your plan is ready. Here is what I recommend and why:', hi: 'आपका प्लान तैयार है। मेरी सलाह और उसका कारण यह है:' },
  updated: { en: 'Updated. I have rebuilt your plan with the new answer:', hi: 'बदल दिया। नए जवाब के साथ आपका प्लान दोबारा बना दिया है:' },
  yes: { en: 'Yes, I have a GSTIN', hi: 'हाँ, GSTIN है' },
  no: { en: 'No GSTIN yet', hi: 'नहीं, अभी GSTIN नहीं है' },
  doneChip: { en: 'Done', hi: 'हो गया' },
  otherCity: { en: 'Other city', hi: 'दूसरा शहर' },
};

const byId = (arr, id) => arr.find((x) => x.id === id);
const label = (arr, id, lang) => (byId(arr, id) || {})[lang] || (byId(arr, id) || {}).en || id;

module.exports = { CATEGORIES, INTERNET, NEEDS, NEED_DEFAULTS, T, byId, label };
