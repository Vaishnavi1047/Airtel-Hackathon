// Turns raw OCR text into a few named fields and checks them against the mock registries and the order.
// Returns one of four statuses: Verified, Pending (needs a human look), Mismatch, Rejected.

const { similarity, addressSimilarity, maskGstin, maskUdyam } = require('./text');
const { repairGstinFromOcr, cleanGstin, cleanUdyam, validateUdyam } = require('./gstin');

const DOC_TYPES = {
  gst_certificate: { label: 'GST certificate', header: /gst\s+registration\s+certificate/i },
  udyam_certificate: { label: 'Udyam certificate', header: /udyam\s+registration\s+certificate/i },
  signatory_id: { label: 'Signatory ID', header: /authori[sz]ed\s+signatory/i },
  address_proof: { label: 'Utility bill / address proof', header: /(electricity|water|gas|telephone|utility)\s+bill/i },
};

const NAME_MATCH = 0.88;
const ADDRESS_MATCH = 0.85;
const MIN_CONFIDENCE = 55;
const ADDRESS_PROOF_MAX_AGE_DAYS = 90;

const lines = (text) => String(text || '').split(/\r?\n/).map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean);

// "Label value" on one line.
function inline(ls, labelRe) {
  for (const l of ls) { const m = l.match(labelRe); if (m) return (m[1] || '').trim(); }
  return '';
}
// Label on one line, value on the next (the signatory ID card layout).
function below(ls, labelRe) {
  const i = ls.findIndex((l) => labelRe.test(l));
  return i >= 0 && ls[i + 1] ? ls[i + 1].trim() : '';
}
// OCR wraps long addresses mid-word ("West Be" / "ngal"), so join without a space when a word was split.
const joinWrapped = (a, b) => (!b ? a : /[a-z]$/.test(a) && /^[a-z]/.test(b) ? a + b : `${a} ${b}`);
const isoDate = (s) => { const m = String(s || '').match(/(\d{4})-(\d{2})-(\d{2})/); return m ? m[0] : ''; };

function detectType(text) {
  return Object.keys(DOC_TYPES).find((t) => DOC_TYPES[t].header.test(text)) || null;
}

function extract(type, text) {
  const ls = lines(text);
  if (type === 'gst_certificate') {
    const raw = inline(ls, /^GSTIN\s+(.+)$/i);
    const a1 = inline(ls, /^Address of principal\s+(.+)$/i);
    const a2 = inline(ls, /^place of business\s+(.+)$/i);
    return {
      gstinRaw: cleanGstin(raw), legalName: inline(ls, /^Legal name\s+(.+)$/i), tradeName: inline(ls, /^Trade name\s+(.+)$/i),
      constitution: inline(ls, /^Constitution\s+(.+)$/i), address: joinWrapped(a1, a2), documentDate: isoDate(inline(ls, /^Date of liability\s+(.+)$/i)),
    };
  }
  if (type === 'udyam_certificate') {
    const raw = inline(ls, /^Udyam reg\.?\s*number\s*(.*)$/i);
    return {
      udyamNumber: cleanUdyam(raw), enterpriseName: inline(ls, /^Enterprise name\s+(.+)$/i), majorActivity: inline(ls, /^Major activity\s+(.+)$/i),
      city: inline(ls, /^City\s+(.+)$/i), state: inline(ls, /^State\s+(.+)$/i), documentDate: isoDate(inline(ls, /^Date of registration\s+(.+)$/i)),
    };
  }
  if (type === 'signatory_id') {
    return {
      name: below(ls, /^Name$/i) || inline(ls, /^Name\s+(.+)$/i), designation: below(ls, /^Designation$/i), forBusiness: below(ls, /^For business$/i),
      idNumber: below(ls, /^ID no\.?$/i), validTill: isoDate(below(ls, /^Valid till$/i)),
    };
  }
  if (type === 'address_proof') {
    const i = ls.findIndex((l) => /^Supply address\s+/i.test(l));
    let address = i >= 0 ? ls[i].replace(/^Supply address\s+/i, '') : '';
    if (i >= 0 && ls[i + 1] && !/^Bill date/i.test(ls[i + 1])) address = joinWrapped(address, ls[i + 1]);
    return { billedTo: inline(ls, /^Billed to\s+(.+)$/i), address, documentDate: isoDate(inline(ls, /^Bill date\s+(.+)$/i)), consumerNumber: inline(ls, /^Consumer no\.?\s+(.+)$/i) };
  }
  return {};
}

// Compare a GSTIN read by OCR with the GSTIN the customer entered, forgiving only look-alike characters.
const CLASSES = ['0OQD', '1ILJ', '5S', '8B', '2Z7', '6G'];
const cls = (c) => { const k = CLASSES.find((g) => g.includes(c)); return k || c; };
function gstinMatches(ocrValue, entered) {
  if (!ocrValue || ocrValue.length !== entered.length) return { match: false, exact: false };
  let exact = true;
  for (let i = 0; i < entered.length; i++) {
    if (ocrValue[i] === entered[i]) continue;
    exact = false;
    if (cls(ocrValue[i]) !== cls(entered[i])) return { match: false, exact: false };
  }
  return { match: true, exact };
}

const pct = (x) => `${Math.round(x * 100)}%`;
const proprietorOf = (legalName) => { const m = String(legalName || '').match(/^(.+?)\s*\(Prop\./i); return m ? m[1].trim() : null; };

/**
 * @param {string} type      one of DOC_TYPES
 * @param {{text:string, confidence:number}} ocr
 * @param {object} ctx       { gstin, gstinRecord, udyam, udyamRecord, businessName, ownerName, address, referenceDate }
 */
function evaluate(type, ocr, ctx) {
  const checks = [];
  const add = (label, result, detail) => checks.push({ label, result, detail });
  const done = (status, message, fields = {}) => ({ status, message, fields, checks, ocrConfidence: ocr.confidence });

  if (ocr.confidence < MIN_CONFIDENCE || ocr.text.replace(/\s/g, '').length < 40) {
    add('Image quality', 'fail', `Text could not be read reliably (OCR confidence ${ocr.confidence}%).`);
    return done('Rejected', 'We could not read this image. Please retake the photo in good light, keep the page flat and make sure all four corners are visible.');
  }
  add('Image quality', 'pass', `Readable (OCR confidence ${ocr.confidence}%).`);

  const detected = detectType(ocr.text);
  if (detected && detected !== type) {
    add('Document type', 'fail', `This looks like a ${DOC_TYPES[detected].label}, not a ${DOC_TYPES[type].label}.`);
    return done('Rejected', `This looks like a ${DOC_TYPES[detected].label}. Please upload it in the right slot, or upload your ${DOC_TYPES[type].label} here.`);
  }
  if (!detected) {
    add('Document type', 'fail', `We could not recognise this as a ${DOC_TYPES[type].label}.`);
    return done('Rejected', `We could not recognise this as a ${DOC_TYPES[type].label}. Please upload a clear photo of the right document.`);
  }
  add('Document type', 'pass', DOC_TYPES[type].label);

  const f = extract(type, ocr.text);
  const businessName = ctx.gstinRecord?.tradeName || ctx.udyamRecord?.enterpriseName || ctx.businessName;
  const nameSource = ctx.gstinRecord ? 'GST registry' : ctx.udyamRecord ? 'Udyam registry' : 'your order';
  let fails = 0, warns = 0;
  const cmp = (label, got, expected, threshold, sim = similarity) => {
    if (!got) { add(label, 'fail', 'Not found on the document.'); fails++; return; }
    const s = sim(got, expected);
    if (s >= threshold) add(label, 'pass', `Matches ${nameSource === 'your order' && label.includes('ddress') ? 'your order' : 'our records'} (${pct(s)} similar).`);
    else { add(label, 'fail', `Document says "${got}" but ${label.includes('ddress') && !ctx.gstinRecord ? 'your order' : nameSource} has "${expected}".`); fails++; }
  };

  if (type === 'gst_certificate') {
    const repaired = repairGstinFromOcr(f.gstinRaw);
    const m = gstinMatches(repaired.gstin, ctx.gstin);
    const fields = { gstin: maskGstin(repaired.gstin), legalName: f.legalName, tradeName: f.tradeName, constitution: f.constitution, address: f.address, documentDate: f.documentDate };
    if (!f.gstinRaw) { add('GSTIN on document', 'fail', 'No GSTIN could be read from the document.'); fails++; }
    else if (m.match) add('GSTIN on document', 'pass', m.exact ? 'Same as the GSTIN you entered.' : 'Same as the GSTIN you entered (look-alike characters such as O/0 were corrected automatically).');
    else { add('GSTIN on document', 'fail', `The certificate shows ${maskGstin(repaired.gstin)}, which is different from the GSTIN you entered (${maskGstin(ctx.gstin)})${repaired.valid ? '' : ' and does not pass the GSTIN check-digit test'}.`); fails++; }
    cmp('Legal name', f.legalName, ctx.gstinRecord.legalName, NAME_MATCH);
    cmp('Trade name', f.tradeName, ctx.gstinRecord.tradeName, NAME_MATCH);
    cmp('Registered address', f.address, ctx.gstinRecord.address, ADDRESS_MATCH, addressSimilarity);
    return fails ? done('Mismatch', 'Some details on this certificate do not match the mock GST registry. Please upload the correct certificate or contact support.', fields)
      : done('Verified', 'GST certificate matches the mock GST registry.', fields);
  }

  if (type === 'udyam_certificate') {
    const fields = { udyamNumber: maskUdyam(f.udyamNumber), enterpriseName: f.enterpriseName, majorActivity: f.majorActivity, city: f.city, state: f.state, documentDate: f.documentDate };
    if (!f.udyamNumber || !validateUdyam(f.udyamNumber).valid) {
      add('Udyam number on document', 'fail', f.udyamNumber ? `"${f.udyamNumber}" is not a complete Udyam number.` : 'The Udyam registration number is missing or unreadable on this certificate.');
      return done('Rejected', 'The Udyam registration number is not visible on this certificate. Please upload a complete copy.', fields);
    }
    if (f.udyamNumber === ctx.udyam) add('Udyam number on document', 'pass', 'Same as the Udyam number you entered.');
    else { add('Udyam number on document', 'fail', `The certificate shows ${maskUdyam(f.udyamNumber)}, different from the number you entered.`); fails++; }
    cmp('Enterprise name', f.enterpriseName, ctx.udyamRecord.enterpriseName, NAME_MATCH);
    cmp('State', f.state, ctx.udyamRecord.state, 0.85);
    cmp('City', f.city, ctx.udyamRecord.city, 0.85);
    return fails ? done('Mismatch', 'Some details on this certificate do not match the mock Udyam registry.', fields) : done('Verified', 'Udyam certificate matches the mock Udyam registry.', fields);
  }

  if (type === 'signatory_id') {
    const fields = { name: f.name, designation: f.designation, forBusiness: f.forBusiness, idNumber: f.idNumber ? '•••' + f.idNumber.slice(-3) : '', validTill: f.validTill };
    if (!f.name) { add('Signatory name', 'fail', 'Name not found on the ID.'); return done('Rejected', 'We could not read the name on this ID. Please upload a clearer photo.', fields); }
    add('Signatory name', 'pass', f.name);
    if (!f.validTill) { add('Validity', 'warn', 'No validity date found.'); warns++; }
    else if (f.validTill < ctx.referenceDate) { add('Validity', 'fail', `This ID expired on ${f.validTill}.`); return done('Rejected', `This ID expired on ${f.validTill}. Please upload an ID that is currently valid.`, fields); }
    else add('Validity', 'pass', `Valid till ${f.validTill}.`);
    cmp('Business on ID', f.forBusiness, businessName, NAME_MATCH);
    const prop = proprietorOf(ctx.gstinRecord?.legalName);
    if (prop) {
      if (similarity(f.name, prop) >= NAME_MATCH) add('Authority to sign', 'pass', 'Signatory is the proprietor named in the GST registry.');
      else { add('Authority to sign', 'warn', `Signatory is not the proprietor in the GST registry (${prop}). An authorisation letter is needed.`); warns++; }
    } else if (ctx.gstinRecord) {
      add('Authority to sign', 'info', `${ctx.gstinRecord.constitution}: signing authority is confirmed by our team during the welcome call.`);
    }
    if (fails) return done('Mismatch', 'The business named on this ID does not match your order.', fields);
    if (warns) return done('Pending', 'ID accepted, but our team needs to confirm the signatory\'s authority. No action needed from you right now.', fields);
    return done('Verified', 'Signatory ID accepted.', fields);
  }

  // address_proof
  const expectedAddress = ctx.gstinRecord?.address || ctx.address;
  const fields = { billedTo: f.billedTo, address: f.address, documentDate: f.documentDate, consumerNumber: f.consumerNumber ? '•••' + f.consumerNumber.slice(-3) : '' };
  if (!f.documentDate) { add('Bill date', 'fail', 'Bill date not found.'); return done('Rejected', 'We could not find the bill date. Please upload a bill that shows its date clearly.', fields); }
  const ageDays = Math.round((new Date(ctx.referenceDate) - new Date(f.documentDate)) / 86400000);
  if (ageDays > ADDRESS_PROOF_MAX_AGE_DAYS) { add('Bill date', 'fail', `Dated ${f.documentDate}, which is ${ageDays} days old. Address proof must be no older than ${ADDRESS_PROOF_MAX_AGE_DAYS} days.`); return done('Rejected', `This bill is ${ageDays} days old. Please upload a bill from the last ${ADDRESS_PROOF_MAX_AGE_DAYS} days.`, fields); }
  if (ageDays < 0) { add('Bill date', 'fail', `Dated ${f.documentDate}, which is in the future.`); return done('Rejected', 'The bill date is in the future. Please upload a valid bill.', fields); }
  add('Bill date', 'pass', `Dated ${f.documentDate} (${ageDays} days old, limit ${ADDRESS_PROOF_MAX_AGE_DAYS}).`);
  cmp('Billed to', f.billedTo, businessName, NAME_MATCH);
  cmp('Service address', f.address, expectedAddress, ctx.gstinRecord ? ADDRESS_MATCH : 0.6, addressSimilarity);
  return fails ? done('Mismatch', 'The name or address on this bill does not match your business details.', fields) : done('Verified', 'Address proof accepted.', fields);
}

module.exports = { evaluate, extract, detectType, DOC_TYPES, gstinMatches };
