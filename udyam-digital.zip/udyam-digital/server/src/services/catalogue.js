// Deterministic eligibility, dependency and pricing rules. Every number shown to a customer comes from here
// (and therefore from product_catalogue.csv) - never from the LLM.

const { store } = require('./dataService');

// ---- Pricing policy -------------------------------------------------------------------------
// The catalogue gives a monthly price RANGE per product (price_min .. price_max) but no rule for
// where inside the range a customer lands. Our transparent, documented assumption:
//   1 product type in the cart  -> top of the range    (list price)
//   2 product types             -> middle of the range
//   3 or more product types     -> bottom of the range (best bundle price)
// "Savings" are therefore always backed by catalogue values: list price minus quoted price.
const PRICE_POLICY = [
  { minTypes: 3, position: 0, label: 'Bundle price (3+ services): lowest catalogue price' },
  { minTypes: 2, position: 0.5, label: 'Duo price (2 services): middle of the catalogue range' },
  { minTypes: 1, position: 1, label: 'Single service: catalogue list price' },
];
const policyFor = (types) => PRICE_POLICY.find((p) => types >= p.minTypes);
const unitPrice = (product, types) => Math.round(product.priceMin + (product.priceMax - product.priceMin) * policyFor(types).position);

const MAX_QTY = 200;

function eligibility(product, profile) {
  const reasons = [];
  const tier = Number(profile.cityTier) || 2;
  if (!product.cityTiers.includes(tier)) reasons.push({ code: 'CITY_TIER', en: `Not sold in tier-${tier} cities yet`, hi: `टियर-${tier} शहरों में अभी उपलब्ध नहीं` });
  if ((Number(profile.employees) || 1) < product.minEmployees) reasons.push({ code: 'MIN_EMPLOYEES', en: `Needs at least ${product.minEmployees} employees`, hi: `कम से कम ${product.minEmployees} कर्मचारी चाहिए` });
  if ((Number(profile.sites) || 1) < product.minSites) reasons.push({ code: 'MIN_SITES', en: `Needs at least ${product.minSites} locations`, hi: `कम से कम ${product.minSites} लोकेशन चाहिए` });
  if (product.requiresGstin && !profile.hasGstin) reasons.push({ code: 'GSTIN', en: 'Needs a valid, active GSTIN', hi: 'वैध और सक्रिय GSTIN ज़रूरी है' });
  return { eligible: reasons.length === 0, reasons };
}

function publicProduct(p, profile) {
  const out = {
    id: p.id, category: p.category, name: p.name, description: p.description, unit: p.unit,
    priceMin: p.priceMin, priceMax: p.priceMax, setupFee: p.setupFee, minContractMonths: p.minContractMonths,
    cityTiers: p.cityTiers, minEmployees: p.minEmployees, minSites: p.minSites, requiresGstin: p.requiresGstin,
    requiresOneOf: p.requiresOneOf.map((id) => ({ id, name: store.productById.get(id)?.name || id })),
    installDays: p.installDays, targetSegments: p.targetSegments,
  };
  if (profile) out.eligibility = eligibility(p, profile);
  return out;
}

// items: [{ productId, qty }]  profile: { cityTier, employees, sites, hasGstin }
function quote(items, profile = {}) {
  const issues = [];
  const merged = new Map();
  for (const it of Array.isArray(items) ? items : []) {
    const id = String(it.productId || '').toUpperCase();
    const p = store.productById.get(id);
    if (!p) { issues.push({ code: 'UNKNOWN_PRODUCT', productId: id, en: `Unknown product ${id}`, hi: `अज्ञात प्रोडक्ट ${id}` }); continue; }
    const qty = Math.floor(Number(it.qty));
    if (!Number.isFinite(qty) || qty < 1 || qty > MAX_QTY) { issues.push({ code: 'BAD_QTY', productId: id, en: `Quantity for ${p.name} must be between 1 and ${MAX_QTY}`, hi: `${p.name} की मात्रा 1 से ${MAX_QTY} के बीच होनी चाहिए` }); continue; }
    merged.set(id, (merged.get(id) || 0) + qty);
  }
  const ids = [...merged.keys()];
  const types = Math.max(ids.length, 1);
  const policy = policyFor(types);

  const lines = ids.map((id) => {
    const p = store.productById.get(id);
    const qty = merged.get(id);
    const elig = eligibility(p, profile);
    for (const r of elig.reasons) issues.push({ code: r.code, productId: id, en: `${p.name}: ${r.en}`, hi: `${p.name}: ${r.hi}` });
    if (p.requiresOneOf.length && !p.requiresOneOf.some((d) => merged.has(d))) {
      const names = p.requiresOneOf.map((d) => store.productById.get(d)?.name || d).join(', ');
      issues.push({ code: 'DEPENDENCY', productId: id, needsOneOf: p.requiresOneOf, en: `${p.name} works only with one of: ${names}`, hi: `${p.name} के लिए इनमें से एक ज़रूरी है: ${names}` });
    }
    const price = unitPrice(p, types);
    return {
      productId: id, name: p.name, category: p.category, description: p.description, unit: p.unit, qty,
      unitPrice: price, listUnitPrice: p.priceMax, priceMin: p.priceMin, priceMax: p.priceMax,
      monthly: price * qty, listMonthly: p.priceMax * qty,
      setupFeePerUnit: p.setupFee, setup: p.setupFee * qty,
      minContractMonths: p.minContractMonths, installDays: p.installDays, requiresGstin: p.requiresGstin,
      requiresOneOf: p.requiresOneOf,
    };
  });

  const monthlyTotal = lines.reduce((s, l) => s + l.monthly, 0);
  const listMonthlyTotal = lines.reduce((s, l) => s + l.listMonthly, 0);
  const setupTotal = lines.reduce((s, l) => s + l.setup, 0);
  const contractMonths = lines.reduce((m, l) => Math.max(m, l.minContractMonths), 0);
  const installDays = lines.reduce((m, l) => Math.max(m, l.installDays), 0);
  if (!lines.length) issues.push({ code: 'EMPTY', en: 'Add at least one service', hi: 'कम से कम एक सेवा चुनें' });

  return {
    valid: issues.length === 0,
    issues,
    lines,
    totals: {
      monthly: monthlyTotal,
      listMonthly: listMonthlyTotal,
      monthlySavings: listMonthlyTotal - monthlyTotal,
      setup: setupTotal,
      firstBill: monthlyTotal + setupTotal,
      contractMonths,
      contractValue: monthlyTotal * contractMonths + setupTotal,
      installDays,
    },
    pricePolicy: { label: policy.label, productTypes: ids.length, note: 'Prices come from product_catalogue.csv and exclude taxes. The position inside each catalogue price range is a documented demo assumption.' },
    requiresGstin: lines.some((l) => l.requiresGstin),
  };
}

module.exports = { quote, eligibility, publicProduct, unitPrice, PRICE_POLICY, MAX_QTY };
