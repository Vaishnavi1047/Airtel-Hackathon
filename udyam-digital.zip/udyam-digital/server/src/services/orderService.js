const crypto = require('crypto');
const config = require('../config');
const Order = require('../models/Order');
const Kyc = require('../models/Kyc');
const { STATUSES } = Order;

const STAGES = [
  { status: 'ORDER_PLACED', en: 'Order placed', hi: 'ऑर्डर हो गया' },
  { status: 'KYC_VERIFICATION', en: 'KYC verification', hi: 'KYC जाँच' },
  { status: 'KYC_APPROVED', en: 'KYC approved', hi: 'KYC मंज़ूर' },
  { status: 'INSTALLATION_SCHEDULED', en: 'Installation scheduled', hi: 'इंस्टॉलेशन तय' },
  { status: 'INSTALLATION_IN_PROGRESS', en: 'Installation in progress', hi: 'इंस्टॉलेशन जारी' },
  { status: 'SERVICE_ACTIVATED', en: 'Service activated', hi: 'सेवा चालू' },
];

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no look-alike characters
function newOrderId() {
  const d = new Date();
  const ymd = `${String(d.getFullYear()).slice(2)}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const rand = Array.from(crypto.randomBytes(6), (b) => ALPHABET[b % ALPHABET.length]).join('');
  return `UD-${ymd}-${rand}`;
}

const addDays = (date, n) => new Date(new Date(date).getTime() + n * 86400000);
const ymd = (d) => new Date(d).toISOString().slice(0, 10);

function moveTo(order, status, note) {
  if (order.orderStatus === status) return;
  order.orderStatus = status;
  order.timeline.push({ status, at: new Date(), note });
}

// Installation dates the customer can pick once KYC is approved.
// Earliest date = approval date + the catalogue's typical_install_days for the slowest product in the order.
function slotOptions(order) {
  const approved = order.timeline.find((t) => t.status === 'KYC_APPROVED');
  if (!approved) return [];
  const first = addDays(approved.at, Math.max(order.installDays || 1, 1));
  return Array.from({ length: 5 }, (_, i) => ymd(addDays(first, i)));
}
const SLOT_WINDOWS = ['9 am - 12 noon', '12 noon - 3 pm', '3 pm - 6 pm'];

function evaluateKyc(kyc, order) {
  const docs = kyc.verificationDetails?.documents || [];
  const required = ['signatory_id', 'address_proof'];
  if (kyc.gstinStatus === 'Verified') required.unshift('gst_certificate');
  if (kyc.udyamStatus === 'Verified') required.push('udyam_certificate');
  const byType = Object.fromEntries(docs.map((d) => [d.type, d]));
  const statuses = required.map((t) => byType[t]?.status || 'Not started');

  let documentStatus = 'Pending';
  if (!docs.length) documentStatus = 'Not started';
  else if (statuses.includes('Rejected')) documentStatus = 'Rejected';
  else if (statuses.includes('Mismatch')) documentStatus = 'Mismatch';
  else if (statuses.every((s) => s === 'Verified')) documentStatus = 'Verified';
  kyc.documentStatus = documentStatus;

  const idOk = (s) => s === 'Verified' || s === 'Skipped';
  const gstOk = order.requiresGstin ? kyc.gstinStatus === 'Verified' : idOk(kyc.gstinStatus);
  const bad = (s) => s === 'Mismatch' || s === 'Rejected';
  if (kyc.consentStatus === 'Given' && gstOk && idOk(kyc.udyamStatus) && documentStatus === 'Verified') kyc.overallStatus = 'Approved';
  else if (bad(kyc.gstinStatus) || bad(kyc.udyamStatus) || bad(documentStatus)) kyc.overallStatus = 'Action needed';
  else kyc.overallStatus = 'In progress';
  return { required, missing: required.filter((t) => !byType[t]) };
}

// Saves KYC, and moves the order forward automatically the moment KYC is fully approved.
async function syncKyc(kyc, order) {
  const info = evaluateKyc(kyc, order);
  await kyc.save();
  if (kyc.overallStatus === 'Approved' && order.orderStatus === 'KYC_VERIFICATION') {
    moveTo(order, 'KYC_APPROVED', 'All checks passed automatically');
    await order.save();
  }
  return info;
}

const DOC_LABEL = { gst_certificate: 'GST certificate', udyam_certificate: 'Udyam certificate', signatory_id: 'Signatory ID', address_proof: 'Utility bill / address proof' };

function pendingActions(order, kyc, info) {
  const out = [];
  if (order.orderStatus === 'KYC_VERIFICATION') {
    if (!kyc || kyc.consentStatus !== 'Given') out.push({ code: 'CONSENT', text: 'Give consent to start your KYC', link: 'kyc' });
    else {
      if (kyc.gstinStatus === 'Not started') out.push({ code: 'GSTIN', text: order.requiresGstin ? 'Verify your GSTIN (needed for services in your order)' : 'Verify your GSTIN, or skip it', link: 'kyc' });
      if (['Mismatch', 'Rejected'].includes(kyc.gstinStatus)) out.push({ code: 'GSTIN_FIX', text: 'There is a problem with your GSTIN check', link: 'kyc' });
      if (kyc.udyamStatus === 'Not started') out.push({ code: 'UDYAM', text: 'Verify your Udyam number, or skip it', link: 'kyc' });
      if (['Mismatch', 'Rejected'].includes(kyc.udyamStatus)) out.push({ code: 'UDYAM_FIX', text: 'There is a problem with your Udyam check', link: 'kyc' });
      for (const t of info.missing) out.push({ code: 'UPLOAD', text: `Upload your ${DOC_LABEL[t]}`, link: 'kyc' });
      for (const d of kyc.verificationDetails?.documents || []) {
        if (['Mismatch', 'Rejected'].includes(d.status)) out.push({ code: 'DOC_FIX', text: `Re-upload your ${DOC_LABEL[d.type]}: ${d.message}`, link: 'kyc' });
        if (d.status === 'Pending') out.push({ code: 'REVIEW', text: `${DOC_LABEL[d.type]} is with our team for a quick review`, link: null });
      }
    }
  } else if (order.orderStatus === 'KYC_APPROVED') out.push({ code: 'SLOT', text: 'Choose your installation date', link: 'slot' });
  return out;
}

function publicKyc(kyc) {
  if (!kyc) return null;
  const v = kyc.verificationDetails || {};
  return {
    orderId: kyc.orderId, consentStatus: kyc.consentStatus, consentGivenAt: kyc.consent?.givenAt || null,
    gstinStatus: kyc.gstinStatus, udyamStatus: kyc.udyamStatus, documentStatus: kyc.documentStatus, overallStatus: kyc.overallStatus,
    gstin: v.gstin?.masked ? v.gstin : null, udyam: v.udyam?.masked ? v.udyam : null,
    documents: (v.documents || []).map((d) => ({ type: d.type, label: DOC_LABEL[d.type], status: d.status, message: d.message, fields: d.fields, checks: d.checks, ocrConfidence: d.ocrConfidence, processedAt: d.processedAt })),
    retention: { deleteAfter: kyc.purgeAfter, documentImages: config.retention.documentImages },
  };
}

async function loadOrder(orderId) {
  const id = String(orderId || '').toUpperCase().trim();
  if (!/^UD-\d{6}-[A-Z0-9]{6}$/.test(id)) return null;
  return Order.findOne({ orderId: id });
}

module.exports = { STAGES, STATUSES, newOrderId, addDays, ymd, moveTo, slotOptions, SLOT_WINDOWS, evaluateKyc, syncKyc, pendingActions, publicKyc, loadOrder, DOC_LABEL };
