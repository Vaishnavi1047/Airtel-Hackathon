// GSTIN and Udyam number format checks.
// The GSTIN check digit is the standard base-36 "mod 36" algorithm used on real GSTINs.
// Per the dataset README, the 4th PAN character is "X" in this synthetic data, so any letter is accepted there.

const CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const GSTIN_RE = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;
const UDYAM_RE = /^UDYAM-[A-Z]{2}-\d{2}-\d{7}$/;

const STATE_CODES = {
  '01': 'Jammu and Kashmir', '02': 'Himachal Pradesh', '03': 'Punjab', '04': 'Chandigarh', '05': 'Uttarakhand',
  '06': 'Haryana', '07': 'Delhi', '08': 'Rajasthan', '09': 'Uttar Pradesh', '10': 'Bihar', '11': 'Sikkim',
  '12': 'Arunachal Pradesh', '13': 'Nagaland', '14': 'Manipur', '15': 'Mizoram', '16': 'Tripura', '17': 'Meghalaya',
  '18': 'Assam', '19': 'West Bengal', '20': 'Jharkhand', '21': 'Odisha', '22': 'Chhattisgarh', '23': 'Madhya Pradesh',
  '24': 'Gujarat', '27': 'Maharashtra', '29': 'Karnataka', '30': 'Goa', '32': 'Kerala', '33': 'Tamil Nadu',
  '34': 'Puducherry', '36': 'Telangana', '37': 'Andhra Pradesh',
};

function checkDigit(first14) {
  let sum = 0;
  for (let i = 0; i < 14; i++) {
    const v = CHARS.indexOf(first14[i]);
    if (v < 0) return null;
    const prod = v * (i % 2 === 0 ? 1 : 2);
    sum += Math.floor(prod / 36) + (prod % 36);
  }
  return CHARS[(36 - (sum % 36)) % 36];
}

const cleanGstin = (s) => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');

function validateGstin(input) {
  const gstin = cleanGstin(input);
  if (gstin.length !== 15) return { valid: false, gstin, reason: 'A GSTIN has exactly 15 characters.' };
  if (!GSTIN_RE.test(gstin)) return { valid: false, gstin, reason: 'This does not follow the GSTIN pattern (2-digit state code, 10-character PAN, entity number, Z, check character).' };
  if (checkDigit(gstin.slice(0, 14)) !== gstin[14]) return { valid: false, gstin, reason: 'The last character (check digit) does not match. Please re-check for a typing mistake.' };
  return { valid: true, gstin, stateCode: gstin.slice(0, 2), stateName: STATE_CODES[gstin.slice(0, 2)] || null };
}

// OCR often confuses look-alike characters (O/0, I/1, S/5, B/8, Z/2, G/6).
// Because each GSTIN position must be a letter or a digit, we can repair those safely
// and then confirm the repair with the check digit.
const TO_DIGIT = { O: '0', Q: '0', D: '0', I: '1', L: '1', S: '5', B: '8', Z: '2', G: '6' };
const TO_LETTER = { 0: 'O', 1: 'I', 5: 'S', 8: 'B', 2: 'Z', 6: 'G' };
function repairGstinFromOcr(raw) {
  const s = cleanGstin(raw);
  if (s.length !== 15) return { gstin: s, repaired: false, valid: false };
  if (validateGstin(s).valid) return { gstin: s, repaired: false, valid: true };
  const out = s.split('');
  const digitPos = [0, 1, 7, 8, 9, 10];
  const letterPos = [2, 3, 4, 5, 6, 11];
  digitPos.forEach((i) => { if (TO_DIGIT[out[i]]) out[i] = TO_DIGIT[out[i]]; });
  letterPos.forEach((i) => { if (TO_LETTER[out[i]]) out[i] = TO_LETTER[out[i]]; });
  if (out[13] === '2') out[13] = 'Z';
  const base = out.join('');
  if (validateGstin(base).valid) return { gstin: base, repaired: base !== s, valid: true };
  // Positions 12 and 14 can be a letter or digit: try the look-alike alternatives.
  const alts = (c) => [c, TO_DIGIT[c], TO_LETTER[c]].filter(Boolean);
  for (const a of alts(base[12])) for (const b of alts(base[14])) {
    const cand = base.slice(0, 12) + a + base[13] + b;
    if (validateGstin(cand).valid) return { gstin: cand, repaired: true, valid: true };
  }
  return { gstin: base, repaired: base !== s, valid: false };
}

// "Look-alike blind" key: two strings with the same key differ only by characters OCR commonly confuses.
const confusableKey = (s) => cleanGstin(s).replace(/[OQD]/g, '0').replace(/[IL]/g, '1').replace(/S/g, '5').replace(/B/g, '8').replace(/Z/g, '2').replace(/G/g, '6');

const cleanUdyam = (s) => String(s || '').toUpperCase().replace(/\s+/g, '').replace(/[–—_]/g, '-');
function validateUdyam(input) {
  const udyam = cleanUdyam(input);
  if (!UDYAM_RE.test(udyam)) return { valid: false, udyam, reason: 'Udyam numbers look like UDYAM-XX-00-0000000 (state code, district code, 7 digits).' };
  return { valid: true, udyam };
}

module.exports = { validateGstin, validateUdyam, repairGstinFromOcr, confusableKey, cleanGstin, cleanUdyam, checkDigit, STATE_CODES };
