// Optional LLM layer (any OpenAI-compatible chat API). It is used for two things only:
//   1. turning the deterministic recommendation into a friendlier explanation, and
//   2. understanding free-text answers the keyword parser could not.
// It never decides products or prices. If it mentions a number the pricing engine did not produce,
// its text is thrown away and the rule-based explanation is used instead.

const config = require('../config');

const enabled = () => Boolean(config.llm.apiKey);

async function chat(messages, { maxTokens = 350, timeoutMs = 9000, json = false } = {}) {
  if (!enabled()) return null;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${config.llm.baseUrl}/chat/completions`, {
      method: 'POST',
      signal: ctrl.signal,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${config.llm.apiKey}` },
      body: JSON.stringify({ model: config.llm.model, messages, temperature: 0.3, max_tokens: maxTokens, ...(json ? { response_format: { type: 'json_object' } } : {}) }),
    });
    if (!res.ok) throw new Error(`LLM API returned ${res.status}`);
    const data = await res.json();
    return data.choices?.[0]?.message?.content?.trim() || null;
  } catch (e) {
    console.warn(`[llm] falling back to rules: ${e.name === 'AbortError' ? 'timed out' : e.message}`);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// Numbers of 3+ digits found in the text (prices), with commas removed.
const bigNumbers = (text) => (String(text).replace(/(\d),(?=\d)/g, '$1').match(/\d{3,}/g) || []).map(Number);

async function explain(facts, lang) {
  const allowed = new Set(bigNumbers(JSON.stringify(facts)));
  const text = await chat([
    { role: 'system', content: `You are a friendly telecom advisor for small Indian businesses. Write in ${lang === 'hi' ? 'simple Hindi (Devanagari script)' : 'simple English'}, 4-6 short sentences, no markdown. Explain why the bundle in the JSON suits this business. Use ONLY the facts in the JSON. Never state a price, fee, discount or number that is not in the JSON. Do not promise anything not listed.` },
    { role: 'user', content: JSON.stringify(facts) },
  ]);
  if (!text) return null;
  const invented = bigNumbers(text).filter((n) => !allowed.has(n));
  if (invented.length) { console.warn(`[llm] explanation discarded: mentioned numbers not from the pricing engine (${invented.join(', ')})`); return null; }
  return text;
}

// Ask the LLM to map free text to one of the allowed option ids. Returns null if unsure.
async function extract(field, question, text, options) {
  const out = await chat([
    { role: 'system', content: 'Map the user answer to the allowed values. Reply with JSON only: {"value": <value or null>}. For a multi-choice question return an array of allowed ids. For numeric questions return an integer. Use null if the answer does not fit.' },
    { role: 'user', content: JSON.stringify({ field, question, answer: String(text).slice(0, 300), allowed: options }) },
  ], { maxTokens: 80, timeoutMs: 6000, json: true });
  if (!out) return null;
  try { return JSON.parse(out).value ?? null; } catch { return null; }
}

module.exports = { enabled, explain, extract };
