// The conversational advisor. It is a small state machine that works with no LLM at all:
// one question at a time, clickable chips, free-text understanding by keywords, Hindi + English.

const crypto = require('crypto');
const { CATEGORIES, INTERNET, NEEDS, NEED_DEFAULTS, T, byId, label } = require('./advisorContent');
const { recommend } = require('./recommender');
const { store, cities } = require('./dataService');
const llm = require('./llm');

const FIELDS = ['businessType', 'employees', 'sites', 'city', 'currentInternet', 'needs', 'hasGstin'];
const sessions = new Map();
const TTL_MS = 2 * 60 * 60 * 1000;
const MAX_SESSIONS = 5000;

function prune() {
  const now = Date.now();
  for (const [id, s] of sessions) if (now - s.touched > TTL_MS) sessions.delete(id);
  while (sessions.size > MAX_SESSIONS) sessions.delete(sessions.keys().next().value);
}

function getSession(id, lang) {
  prune();
  let s = id && sessions.get(id);
  if (!s) { s = { id: crypto.randomUUID(), lang: lang === 'hi' ? 'hi' : 'en', profile: {}, touched: Date.now(), ackIndex: 0 }; sessions.set(s.id, s); }
  s.touched = Date.now();
  if (lang === 'hi' || lang === 'en') s.lang = lang;
  return s;
}

const HINDI_DIGITS = { '०': 0, '१': 1, '२': 2, '३': 3, '४': 4, '५': 5, '६': 6, '७': 7, '८': 8, '९': 9 };
const WORD_NUM = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, ek: 1, do: 2, teen: 3, char: 4, chaar: 4, paanch: 5, panch: 5, chhe: 6, saat: 7, aath: 8, nau: 9, das: 10, 'एक': 1, 'दो': 2, 'तीन': 3, 'चार': 4, 'पांच': 5, 'पाँच': 5, 'छह': 6, 'सात': 7, 'आठ': 8, 'नौ': 9, 'दस': 10, only: 1, just: 1, 'अकेला': 1, 'सिर्फ': 1 };
function parseNumber(v) {
  if (typeof v === 'number') return v;
  const s = String(v || '').toLowerCase().replace(/[०-९]/g, (d) => HINDI_DIGITS[d]);
  const m = s.match(/\d{1,5}/);
  if (m) return Number(m[0]);
  for (const w of s.split(/[\s,.-]+/)) if (WORD_NUM[w] !== undefined) return WORD_NUM[w];
  return null;
}
const matchOption = (list, v) => {
  const s = String(v || '').toLowerCase().trim();
  if (!s) return null;
  const exact = list.find((o) => o.id.toLowerCase() === s || o.en.toLowerCase() === s || o.hi === String(v).trim());
  if (exact) return exact;
  // Otherwise the option whose longest keyword appears in the text wins ("medical store" -> pharmacy, not "store").
  let best = null, bestLen = 0;
  for (const o of list) for (const k of o.keywords) if (k.length > bestLen && (k.length <= 3 ? new RegExp(`(^|[^a-z])${k}([^a-z]|$)`).test(s) : s.includes(k))) { best = o; bestLen = k.length; }
  return best;
};

// Returns { ok, value, note? }. Never throws on odd input.
function parseAnswer(field, raw) {
  switch (field) {
    case 'businessType': { const o = matchOption(CATEGORIES, raw); return o ? { ok: true, value: o.id } : { ok: false }; }
    case 'employees': { const n = parseNumber(raw); return n && n >= 1 && n <= 5000 ? { ok: true, value: n } : { ok: false }; }
    case 'sites': { const n = parseNumber(raw); return n && n >= 1 && n <= 500 ? { ok: true, value: n } : { ok: false }; }
    case 'city': {
      const s = String(raw || '').trim().replace(/\s+/g, ' ');
      if (!/^[\p{L}\p{M} .'-]{2,60}$/u.test(s)) return { ok: false };
      const known = [...store.cityTier.keys()].find((c) => c.toLowerCase() === s.toLowerCase() || s.toLowerCase().includes(c.toLowerCase()));
      return known ? { ok: true, value: known } : { ok: true, value: s.replace(/\b\p{L}/gu, (c) => c.toUpperCase()), note: 'cityOther' };
    }
    case 'currentInternet': { const o = matchOption(INTERNET, raw); return o ? { ok: true, value: o.id } : { ok: false }; }
    case 'needs': {
      const arr = Array.isArray(raw) ? raw : String(raw || '').split(/[,;\n]|\band\b|और/);
      const ids = new Set();
      for (const part of arr) { const o = matchOption(NEEDS, part); if (o) ids.add(o.id); }
      if (!Array.isArray(raw)) for (const n of NEEDS) if (n.keywords.some((k) => String(raw).toLowerCase().includes(k))) ids.add(n.id);
      return ids.size ? { ok: true, value: [...ids] } : { ok: false };
    }
    case 'hasGstin': {
      if (raw === true || raw === false) return { ok: true, value: raw };
      const s = String(raw || '').toLowerCase().trim();
      if (/^[0-9]{2}[a-z0-9]{13}$/i.test(s.replace(/\s/g, ''))) return { ok: true, value: true };
      if (/^(no|n|nahi|nahin|नहीं|नही|false|not yet|don'?t)\b|no gstin|नहीं/.test(s)) return { ok: true, value: false };
      if (/^(yes|y|haan|han|ha|हाँ|हां|जी|true|available)\b|have|है/.test(s)) return { ok: true, value: true };
      return { ok: false };
    }
    default: return { ok: false };
  }
}

function questionFor(field, s) {
  const L = s.lang;
  const q = { field, text: T.q[field][L] };
  switch (field) {
    case 'businessType': return { ...q, type: 'single', chips: CATEGORIES.map((c) => ({ value: c.id, label: c[L] })) };
    case 'employees': return { ...q, type: 'number', placeholder: L === 'hi' ? 'संख्या लिखें' : 'Type a number', chips: [[1, L === 'hi' ? 'सिर्फ़ मैं' : 'Just me'], [3, '2–3'], [5, '4–5'], [10, '6–10'], [25, '11–25'], [60, '26+']].map(([value, lab]) => ({ value, label: lab })) };
    case 'sites': return { ...q, type: 'number', placeholder: L === 'hi' ? 'संख्या लिखें' : 'Type a number', chips: [[1, '1'], [2, '2'], [3, '3'], [5, '4–5'], [8, '6+']].map(([value, lab]) => ({ value, label: lab })) };
    case 'city': return { ...q, type: 'text', placeholder: L === 'hi' ? 'शहर का नाम लिखें' : 'Type your city', chips: cities().map((c) => ({ value: c.city, label: c.city })) };
    case 'currentInternet': return { ...q, type: 'single', chips: INTERNET.map((c) => ({ value: c.id, label: c[L] })) };
    case 'needs': return { ...q, type: 'multi', doneLabel: T.doneChip[L], suggested: NEED_DEFAULTS[s.profile.businessType] || [], chips: NEEDS.map((c) => ({ value: c.id, label: c[L] })) };
    case 'hasGstin': return { ...q, type: 'single', chips: [{ value: true, label: T.yes[L] }, { value: false, label: T.no[L] }] };
    default: return q;
  }
}

function valueLabel(field, value, L) {
  if (value === undefined) return '';
  switch (field) {
    case 'businessType': return label(CATEGORIES, value, L);
    case 'currentInternet': return label(INTERNET, value, L);
    case 'needs': return value.map((v) => label(NEEDS, v, L)).join(', ');
    case 'hasGstin': return value ? (L === 'hi' ? 'हाँ' : 'Yes') : (L === 'hi' ? 'नहीं' : 'No');
    default: return String(value);
  }
}
const FIELD_LABEL = {
  businessType: { en: 'Business', hi: 'कारोबार' }, employees: { en: 'Employees', hi: 'कर्मचारी' }, sites: { en: 'Locations', hi: 'लोकेशन' },
  city: { en: 'City', hi: 'शहर' }, currentInternet: { en: 'Internet today', hi: 'मौजूदा इंटरनेट' }, needs: { en: 'Needs', hi: 'ज़रूरतें' }, hasGstin: { en: 'GSTIN', hi: 'GSTIN' },
};

const nextField = (s) => FIELDS.find((f) => s.profile[f] === undefined) || null;

async function buildRecommendation(s) {
  const rec = recommend(s.profile);
  if (llm.enabled()) {
    const opt = rec.options.find((o) => o.key === rec.recommendedKey) || rec.options[0];
    const facts = {
      business: { type: label(CATEGORIES, rec.profile.businessType, 'en'), employees: rec.profile.employees, locations: rec.profile.sites, city: rec.profile.city, cityTier: rec.profile.cityTier, hasGstin: rec.profile.hasGstin, needs: rec.profile.needs },
      bundle: { name: opt.name.en, products: opt.quote.lines.map((l) => ({ name: l.name, qty: l.qty, unit: l.unit, monthlyInr: l.monthly, setupInr: l.setup, what: l.description })), totals: { monthlyInr: opt.quote.totals.monthly, setupInr: opt.quote.totals.setup, contractMonths: opt.quote.totals.contractMonths, typicalInstallDays: opt.quote.totals.installDays, monthlySavingsVsListInr: opt.quote.totals.monthlySavings } },
      notOffered: opt.skipped.map((k) => ({ name: k.name, why: k.reasons.map((r) => r.en).join('; ') })),
    };
    const text = await llm.explain(facts, s.lang);
    if (text) { opt.explanation[s.lang] = text; rec.engine = 'rules + LLM wording'; }
  }
  return rec;
}

function state(s, messages, extra = {}) {
  const field = nextField(s);
  const L = s.lang;
  return {
    sessionId: s.id, lang: L, messages,
    question: field ? questionFor(field, s) : null,
    answers: FIELDS.filter((f) => s.profile[f] !== undefined).map((f) => ({ field: f, label: FIELD_LABEL[f][L], value: s.profile[f], valueLabel: valueLabel(f, s.profile[f], L) })),
    progress: { answered: FIELDS.filter((f) => s.profile[f] !== undefined).length, total: FIELDS.length },
    done: !field,
    llmEnabled: llm.enabled(),
    ...extra,
  };
}

async function handle(body = {}) {
  const s = getSession(body.sessionId, body.lang);
  const L = s.lang;
  const action = body.action || (body.sessionId ? 'answer' : 'start');
  const say = (text) => ({ role: 'bot', text });

  if (action === 'restart') { s.profile = {}; return state(s, [say(T.welcome[L]), say(T.q.businessType[L])]); }
  if (action === 'start') {
    const field = nextField(s);
    if (!field) return state(s, [say(T.done[L])], { recommendation: await buildRecommendation(s) });
    return state(s, Object.keys(s.profile).length ? [say(T.q[field][L])] : [say(T.welcome[L]), say(T.q[field][L])]);
  }
  if (action === 'lang') {
    const field = nextField(s);
    return state(s, field ? [say(T.q[field][L])] : [say(T.done[L])], field ? {} : { recommendation: await buildRecommendation(s) });
  }
  if (action === 'question') { // ask for the chip list of one field (used by the "change answer" editor)
    if (!FIELDS.includes(body.field)) return state(s, []);
    return { ...state(s, []), editQuestion: questionFor(body.field, s) };
  }

  const editing = action === 'edit';
  const field = editing ? body.field : nextField(s);
  if (!field || !FIELDS.includes(field)) return state(s, [say(T.done[L])], { recommendation: await buildRecommendation(s) });

  const raw = body.value !== undefined ? body.value : body.message;
  let parsed = parseAnswer(field, raw);
  if (!parsed.ok && llm.enabled() && typeof raw === 'string' && raw.trim()) {
    const q = questionFor(field, s);
    const v = await llm.extract(field, T.q[field].en, raw, q.chips ? q.chips.map((c) => c.value) : 'integer');
    if (v !== null) parsed = parseAnswer(field, v);
  }
  if (!parsed.ok) return state(s, [say(T.retry[field][L])], { retry: true });

  s.profile[field] = parsed.value;
  const msgs = [];
  if (parsed.note) msgs.push(say(T[parsed.note][L]));
  const next = nextField(s);
  if (next) {
    const ack = T.ack[L][s.ackIndex++ % T.ack[L].length];
    msgs.push(say(`${ack} ${T.q[next][L]}`));
    return state(s, msgs);
  }
  msgs.push(say(editing ? T.updated[L] : T.done[L]));
  return state(s, msgs, { recommendation: await buildRecommendation(s) });
}

module.exports = { handle, parseAnswer, FIELDS };
