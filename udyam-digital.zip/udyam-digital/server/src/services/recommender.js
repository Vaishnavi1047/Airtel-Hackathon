// Rule-based, deterministic recommendation engine.
// Input: a business profile. Output: up to three ready-to-buy bundle options, add-ons and an explanation.
// Every option is re-checked through catalogue.quote(), so an ineligible product can never be recommended.

const { store, tierForCity } = require('./dataService');
const { quote, eligibility } = require('./catalogue');
const { CATEGORIES, NEEDS, byId, label, INTERNET } = require('./advisorContent');

const LINK_PRODUCTS = ['P01', 'P02', 'P03', 'P04', 'P05', 'P06'];
const EXCLUSIVE_GROUPS = [LINK_PRODUCTS, ['P07', 'P08']];
const SEGMENT_FROM_LEAD = { 'Micro retail & services': 'micro', 'Professional offices': 'prof', 'Small multi-site businesses': 'multi', 'Small manufacturers': 'mfg' };

function normaliseProfile(input = {}) {
  const employees = Math.min(Math.max(Math.floor(Number(input.employees)) || 1, 1), 5000);
  const sites = Math.min(Math.max(Math.floor(Number(input.sites)) || 1, 1), 500);
  const cat = byId(CATEGORIES, input.businessType) || byId(CATEGORIES, 'other');
  const city = String(input.city || '').trim().slice(0, 60);
  const cityKnown = store.cityTier.has(city);
  const cityTier = [1, 2].includes(Number(input.cityTier)) && !city ? Number(input.cityTier) : (city ? tierForCity(city) : (Number(input.cityTier) || 2));
  let segment = ['micro', 'prof', 'multi', 'mfg'].includes(input.segment) ? input.segment : cat.segment;
  if (!input.segment && segment !== 'mfg' && sites >= 3) segment = 'multi';
  const validNeeds = new Set(NEEDS.map((n) => n.id));
  const needs = [...new Set((Array.isArray(input.needs) ? input.needs : []).filter((n) => validNeeds.has(n)))];
  return {
    businessType: cat.id, businessLabel: input.businessLabel ? String(input.businessLabel).slice(0, 60) : null,
    employees, sites, city, cityKnown, cityTier, segment,
    currentInternet: byId(INTERNET, input.currentInternet) ? input.currentInternet : (input.currentInternet ? String(input.currentInternet).slice(0, 40) : 'Not recorded'),
    needs: needs.length ? needs : ['internet'],
    hasGstin: input.hasGstin === true || input.hasGstin === 'true' || input.hasGstin === 'Y',
  };
}

function qtyFor(id, p) {
  const e = p.employees, s = p.sites, small = p.segment === 'micro';
  const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);
  switch (id) {
    case 'P07': case 'P08': return e === 1 ? 1 : e <= 5 ? 2 : e <= 20 ? 3 : e <= 60 ? 4 : 5;
    case 'P11': case 'P13': case 'P14': case 'P15': case 'P17': case 'P18': return 1;
    case 'P12': return clamp(Math.ceil(e / 6), 2, 6);
    case 'P16': return small ? clamp(e, 1, 2) : clamp(e, 1, 50);
    case 'P20': return small ? clamp(e, 1, 3) : clamp(e, 1, 50);
    case 'P23': return clamp(2 * s, 1, 100);
    case 'P24': return clamp(Math.ceil(e / 10), 1, 10);
    case 'P25': return 2;
    default: return s; // per-site and per-counter products
  }
}

// Ordered preference for the main internet link, by business size. First eligible one wins.
function linkLadder(p, mode) {
  const e = p.employees;
  let ladder;
  if (mode === 'essential') ladder = e >= 15 ? ['P02', 'P01'] : ['P01'];
  else if (mode === 'growth') ladder = e >= 25 && p.segment === 'mfg' ? ['P05', 'P03', 'P02'] : e >= 6 ? ['P03', 'P02'] : ['P02', 'P01'];
  else ladder = e >= 25 && p.segment === 'mfg' ? ['P05', 'P03', 'P02'] : e >= 15 ? ['P03', 'P02'] : (e >= 6 || p.segment === 'prof' || p.segment === 'multi') ? ['P02', 'P01'] : ['P01'];
  if (p.currentInternet === 'No internet yet' && mode === 'essential') ladder = ['P04', ...ladder];
  return [...new Set([...ladder, 'P01', 'P04'])];
}

// Which products answer which need (in order of preference).
function candidatesForNeed(need, p, mode) {
  const big = p.segment !== 'micro' || p.employees > 5;
  switch (need) {
    case 'internet': return [linkLadder(p, mode)];
    case 'backup': return [['P09']];
    case 'mobile': return [mode === 'essential' ? ['P07'] : big ? ['P08', 'P07'] : ['P07']];
    case 'pos': return [['P19']];
    case 'cctv': return [['P23']];
    case 'wifi': return [['P22']];
    case 'telephony': return mode === 'growth' ? [['P12'], ['P13']] : [['P12', 'P13']];
    case 'marketing': return mode === 'growth' ? [['P15'], ['P14']] : [['P15', 'P14']];
    case 'email': return [['P16']];
    case 'website': return [['P18']];
    case 'security': return mode === 'essential' ? [['P20']] : [['P20'], ['P21']];
    case 'databackup': return [['P17']];
    case 'iot': return [['P24']];
    case 'fleet': return [['P25']];
    default: return [];
  }
}

const REASONS = {
  P01: (p) => ({ en: `100 Mbps unlimited fibre is the right size for about ${p.employees} people billing, paying and browsing at once.`, hi: `लगभग ${p.employees} लोगों की बिलिंग, पेमेंट और ब्राउज़िंग के लिए 100 Mbps अनलिमिटेड फाइबर सही है।` }),
  P02: (p) => ({ en: `300 Mbps keeps video calls, cloud apps and ${p.employees} people working smoothly at the same time.`, hi: `300 Mbps से वीडियो कॉल, क्लाउड ऐप और ${p.employees} लोगों का काम एक साथ आराम से चलता है।` }),
  P03: (p) => ({ en: `1 Gbps with priority support suits a team of ${p.employees} that depends on the internet all day.`, hi: `${p.employees} लोगों की टीम के लिए, जो पूरे दिन इंटरनेट पर निर्भर है, प्रायोरिटी सपोर्ट वाला 1 Gbps सही है।` }),
  P04: () => ({ en: 'Wireless 5G broadband is plug-and-play and typically live in 2 days, with no fibre laying needed.', hi: '5G वायरलेस ब्रॉडबैंड लगाना आसान है और आम तौर पर 2 दिन में चालू हो जाता है, फाइबर बिछाने की ज़रूरत नहीं।' }),
  P05: () => ({ en: 'A dedicated 1:1 line with a 99.5% uptime commitment keeps production systems always connected.', hi: '99.5% अपटाइम वाली डेडिकेटेड 1:1 लाइन आपके प्रोडक्शन सिस्टम को हमेशा जोड़े रखती है।' }),
  P06: () => ({ en: 'A dedicated 100 Mbps line with 99.9% uptime for heavy, business-critical workloads.', hi: 'भारी और ज़रूरी काम के लिए 99.9% अपटाइम वाली डेडिकेटेड 100 Mbps लाइन।' }),
  P07: (p, q) => ({ en: `${q} business mobile line(s) with unlimited calls so you and your staff stay reachable.`, hi: `${q} बिज़नेस मोबाइल कनेक्शन, अनलिमिटेड कॉल के साथ, ताकि आप और स्टाफ़ हमेशा संपर्क में रहें।` }),
  P08: (p, q) => ({ en: `${q} premium mobile line(s) with more data, roaming and priority care for people on the move.`, hi: `${q} प्रीमियम मोबाइल कनेक्शन, ज़्यादा डेटा, रोमिंग और प्रायोरिटी केयर के साथ।` }),
  P09: () => ({ en: 'If the main line goes down, this switches to mobile data automatically, so UPI and billing keep working.', hi: 'मुख्य लाइन बंद होने पर यह अपने-आप मोबाइल डेटा पर चला जाता है, जिससे UPI और बिलिंग चलती रहती है।' }),
  P10: (p) => ({ en: `Manages the links at all ${p.sites} locations from one place and gives priority to important apps.`, hi: `सभी ${p.sites} लोकेशन के कनेक्शन एक जगह से संभालता है और ज़रूरी ऐप को प्राथमिकता देता है।` }),
  P11: () => ({ en: 'A fixed IP lets you view CCTV or reach your office computer reliably from outside.', hi: 'फिक्स्ड IP से आप बाहर से भी CCTV या ऑफिस कंप्यूटर भरोसे के साथ देख सकते हैं।' }),
  P12: (p, q) => ({ en: `${q} office phone channels with IVR and call recording, so no customer call is missed.`, hi: `IVR और कॉल रिकॉर्डिंग वाले ${q} ऑफिस फ़ोन चैनल, ताकि कोई ग्राहक कॉल न छूटे।` }),
  P13: () => ({ en: 'A free-to-call 1800 number that rings on your mobile makes it easy for customers to reach you.', hi: 'मुफ़्त 1800 नंबर, जो आपके मोबाइल पर बजता है, ग्राहकों के लिए आप तक पहुँचना आसान बनाता है।' }),
  P14: () => ({ en: '10,000 SMS a month for reminders, offers and alerts, with DLT registration help.', hi: 'रिमाइंडर, ऑफ़र और अलर्ट के लिए हर महीने 10,000 SMS, DLT रजिस्ट्रेशन में मदद के साथ।' }),
  P15: () => ({ en: 'A verified WhatsApp business channel to share your catalogue, take orders and send reminders.', hi: 'वेरिफ़ाइड WhatsApp बिज़नेस चैनल, जिससे कैटलॉग दिखाएँ, ऑर्डर लें और रिमाइंडर भेजें।' }),
  P16: (p, q) => ({ en: `Professional email on your own domain plus documents and video meetings for ${q} user(s).`, hi: `${q} यूज़र के लिए अपने डोमेन पर प्रोफेशनल ईमेल, साथ में डॉक्यूमेंट और वीडियो मीटिंग।` }),
  P17: () => ({ en: 'Automatic 1 TB backup protects bills, records and client files if a device fails or is lost.', hi: '1 TB ऑटोमैटिक बैकअप, डिवाइस खराब या गुम होने पर भी बिल, रिकॉर्ड और फ़ाइलें सुरक्षित रखता है।' }),
  P18: () => ({ en: 'A simple 5-page website with your own domain so new customers can find you online.', hi: 'अपने डोमेन के साथ 5 पेज की आसान वेबसाइट, ताकि नए ग्राहक आपको ऑनलाइन ढूँढ सकें।' }),
  P19: (p, q) => ({ en: `GST-ready billing with stock tracking and UPI/card acceptance on a tablet for ${q} counter(s).`, hi: `${q} काउंटर के लिए टैबलेट पर GST बिलिंग, स्टॉक और UPI/कार्ड पेमेंट।` }),
  P20: (p, q) => ({ en: `Antivirus and ransomware protection for ${q} device(s) that hold your business data.`, hi: `आपके कारोबारी डेटा वाले ${q} डिवाइस के लिए एंटीवायरस और रैनसमवेयर सुरक्षा।` }),
  P21: () => ({ en: 'A managed firewall watched by a security team blocks attacks before they reach your network.', hi: 'सुरक्षा टीम की निगरानी वाला मैनेज्ड फ़ायरवॉल, हमलों को आपके नेटवर्क तक पहुँचने से पहले रोकता है।' }),
  P22: () => ({ en: 'Separate Wi-Fi for customers keeps your billing and payment devices on a safer private network.', hi: 'ग्राहकों के लिए अलग Wi-Fi, जिससे आपकी बिलिंग और पेमेंट मशीनें सुरक्षित निजी नेटवर्क पर रहती हैं।' }),
  P23: (p, q) => ({ en: `${q} HD camera(s) with 30 days of cloud recording you can watch on your phone.`, hi: `${q} HD कैमरा, 30 दिन की क्लाउड रिकॉर्डिंग के साथ, जिसे आप फ़ोन पर देख सकते हैं।` }),
  P24: (p, q) => ({ en: `${q} sensor kit(s) to track machine uptime and energy use.`, hi: `मशीन के चालू रहने और बिजली खपत पर नज़र रखने के लिए ${q} सेंसर किट।` }),
  P25: (p, q) => ({ en: `Live GPS tracking for ${q} delivery vehicle(s).`, hi: `${q} डिलीवरी वाहनों की लाइव GPS ट्रैकिंग।` }),
};
const reasonFor = (id, p, q) => (REASONS[id] ? REASONS[id](p, q) : { en: store.productById.get(id)?.description || '', hi: store.productById.get(id)?.description || '' });

const MODES = {
  essential: { en: 'Essential', hi: 'एसेंशियल', tag: { en: 'Covers what you asked for at the lowest monthly cost', hi: 'आपकी ज़रूरतें, सबसे कम मासिक खर्च में' } },
  recommended: { en: 'Smart Connect', hi: 'स्मार्ट कनेक्ट', tag: { en: 'Right-sized for your team and needs', hi: 'आपकी टीम और ज़रूरतों के हिसाब से सही' } },
  growth: { en: 'Growth Plus', hi: 'ग्रोथ प्लस', tag: { en: 'Adds always-on backup and protection as you grow', hi: 'बढ़ते कारोबार के लिए बैकअप और सुरक्षा भी' } },
};

function buildOption(profile, mode) {
  const items = new Map(); // productId -> { qty, need }
  const skipped = [];
  const add = (id, need) => { if (!items.has(id)) items.set(id, { qty: qtyFor(id, profile), need }); };
  const pick = (cands, need) => {
    for (const id of cands) {
      const prod = store.productById.get(id);
      if (!prod) continue;
      const el = eligibility(prod, profile);
      if (el.eligible) { add(id, need); return id; }
      if (!skipped.some((s) => s.productId === id)) skipped.push({ productId: id, name: prod.name, need, reasons: el.reasons });
    }
    return null;
  };

  const needs = [...profile.needs];
  if (mode === 'growth') {
    for (const extra of ['backup', profile.segment === 'micro' ? 'wifi' : 'security']) if (!needs.includes(extra)) needs.push(extra);
  }
  for (const need of needs) for (const group of candidatesForNeed(need, profile, mode)) pick(group, need);

  // Multi-site businesses on the recommended/growth plan get central link management when eligible.
  if (mode !== 'essential' && profile.sites >= 3 && [...items.keys()].some((i) => LINK_PRODUCTS.includes(i))) pick(['P10'], 'internet');

  // Dependency resolution: if something needs a link (or another product) that is not in the bundle, add the best eligible one.
  let guard = 0;
  while (guard++ < 5) {
    const missing = [...items.keys()].map((id) => store.productById.get(id)).filter((p) => p.requiresOneOf.length && !p.requiresOneOf.some((d) => items.has(d)));
    if (!missing.length) break;
    for (const prod of missing) {
      const ladder = linkLadder(profile, mode).filter((id) => prod.requiresOneOf.includes(id));
      const chosen = pick(ladder.length ? ladder : prod.requiresOneOf, 'dependency');
      if (!chosen) { items.delete(prod.id); skipped.push({ productId: prod.id, name: prod.name, need: 'dependency', reasons: [{ code: 'DEPENDENCY', en: 'No eligible internet link to run it on', hi: 'इसे चलाने के लिए कोई पात्र इंटरनेट कनेक्शन नहीं' }] }); }
    }
  }

  // Final safety net: drop anything the deterministic quote still rejects.
  let q = quote([...items].map(([productId, v]) => ({ productId, qty: v.qty })), profile);
  guard = 0;
  while (!q.valid && guard++ < 10 && items.size) {
    const bad = q.issues.find((i) => i.productId && items.has(i.productId));
    if (!bad) break;
    items.delete(bad.productId);
    q = quote([...items].map(([productId, v]) => ({ productId, qty: v.qty })), profile);
  }

  const cat = byId(CATEGORIES, profile.businessType);
  return {
    key: mode,
    name: { en: `${cat.en.split(' / ')[0]} ${MODES[mode].en}`, hi: `${cat.hi.split(' / ')[0]} ${MODES[mode].hi}` },
    tagline: MODES[mode].tag,
    items: [...items].map(([productId, v]) => ({ productId, qty: v.qty, need: v.need, reason: reasonFor(productId, profile, v.qty) })),
    quote: q,
    skipped,
  };
}

function addOnsFor(profile, option) {
  const inBundle = new Set(option.items.map((i) => i.productId));
  const cat = byId(CATEGORIES, profile.businessType);
  const blocked = new Set();
  for (const g of EXCLUSIVE_GROUPS) if (g.some((id) => inBundle.has(id))) g.forEach((id) => blocked.add(id));
  const ordered = [...new Set([...cat.addOns, ...store.products.filter((p) => p.targetSegments.includes(profile.segment)).map((p) => p.id)])];
  const out = [];
  for (const id of ordered) {
    if (inBundle.has(id) || blocked.has(id)) continue;
    const prod = store.productById.get(id);
    if (!prod || !eligibility(prod, profile).eligible) continue;
    if (prod.requiresOneOf.length && !prod.requiresOneOf.some((d) => inBundle.has(d))) continue;
    const qty = qtyFor(id, profile);
    out.push({ productId: id, name: prod.name, category: prod.category, unit: prod.unit, qty, priceMin: prod.priceMin, priceMax: prod.priceMax, setupFeePerUnit: prod.setupFee, minContractMonths: prod.minContractMonths, reason: reasonFor(id, profile, qty) });
    if (out.length >= 6) break;
  }
  return out;
}

const inr = (n) => '₹' + Number(n).toLocaleString('en-IN');

function explain(profile, option, lang) {
  const cat = byId(CATEGORIES, profile.businessType);
  const t = option.quote.totals;
  const names = option.items.map((i) => `${store.productById.get(i.productId).name} × ${i.qty}`).join(', ');
  const needLabels = profile.needs.map((n) => label(NEEDS, n, lang)).join(', ');
  const where = profile.city ? `${profile.city} (tier ${profile.cityTier})` : `tier ${profile.cityTier}`;
  if (lang === 'hi') {
    const parts = [
      `आप ${profile.city ? profile.city + ' में ' : ''}${cat.hi} चलाते हैं, ${profile.employees} लोग और ${profile.sites} लोकेशन के साथ, और आपको चाहिए: ${needLabels}।`,
      `इसलिए मेरी सलाह है "${option.name.hi}": ${names}।`,
      `कुल खर्च ${inr(t.monthly)} प्रति माह, एक बार का सेटअप ${inr(t.setup)}, कम से कम ${t.contractMonths} महीने का कॉन्ट्रैक्ट।`,
      t.monthlySavings > 0 ? `अलग-अलग लेने की लिस्ट कीमत से यह ${inr(t.monthlySavings)} प्रति माह कम है।` : '',
      `KYC मंज़ूर होने के बाद आम तौर पर ${t.installDays} दिन में सेवा चालू हो जाती है।`,
      profile.hasGstin ? '' : 'GSTIN न होने के कारण मैंने केवल वही सेवाएँ चुनी हैं जो बिना GSTIN के मिल सकती हैं।',
    ];
    return parts.filter(Boolean).join(' ');
  }
  const parts = [
    `You run a ${cat.en.toLowerCase()} business in ${where} with ${profile.employees} ${profile.employees === 1 ? 'person' : 'people'} at ${profile.sites} location${profile.sites > 1 ? 's' : ''}, and you asked for: ${needLabels}.`,
    `So I recommend "${option.name.en}": ${names}.`,
    `It costs ${inr(t.monthly)} per month plus a one-time setup of ${inr(t.setup)}, on a minimum ${t.contractMonths}-month contract.`,
    t.monthlySavings > 0 ? `That is ${inr(t.monthlySavings)} a month less than the list price of buying each service separately.` : '',
    `Services are typically live within ${t.installDays} days of KYC approval.`,
    profile.hasGstin ? '' : 'Because you do not have a GSTIN yet, I only picked services that can be sold without one.',
  ];
  return parts.filter(Boolean).join(' ');
}

function sameItems(a, b) {
  const k = (o) => o.items.map((i) => `${i.productId}x${i.qty}`).sort().join(';');
  return k(a) === k(b);
}

function recommend(input) {
  const profile = normaliseProfile(input);
  const recommended = buildOption(profile, 'recommended');
  const options = [recommended];
  const essential = buildOption(profile, 'essential');
  if (essential.items.length && !sameItems(essential, recommended) && essential.quote.totals.monthly < recommended.quote.totals.monthly) options.unshift(essential);
  const growth = buildOption(profile, 'growth');
  if (growth.items.length && !sameItems(growth, recommended) && growth.quote.totals.monthly > recommended.quote.totals.monthly) options.push(growth);

  for (const o of options) {
    o.addOns = addOnsFor(profile, o);
    o.explanation = { en: explain(profile, o, 'en'), hi: explain(profile, o, 'hi') };
  }
  return {
    profile,
    recommendedKey: 'recommended',
    options,
    notes: [
      ...(profile.city && !profile.cityKnown ? [{ en: `${profile.city} is not in the demo city list, so tier-2 availability was applied.`, hi: `${profile.city} डेमो सूची में नहीं है, इसलिए टियर-2 की उपलब्धता लागू की गई।` }] : []),
    ],
    engine: 'rules',
  };
}

// Used by the partner dashboard: turn a lead row into an advisor profile.
const PRODUCT_TO_NEED = { P01: 'internet', P02: 'internet', P03: 'internet', P04: 'internet', P05: 'internet', P06: 'internet', P07: 'mobile', P08: 'mobile', P09: 'backup', P10: 'internet', P11: 'internet', P12: 'telephony', P13: 'telephony', P14: 'marketing', P15: 'marketing', P16: 'email', P17: 'databackup', P18: 'website', P19: 'pos', P20: 'security', P21: 'security', P22: 'wifi', P23: 'cctv', P24: 'iot', P25: 'fleet' };
function profileFromLead(lead) {
  const needs = [...new Set(lead.productsOfInterest.map((p) => PRODUCT_TO_NEED[p]).filter(Boolean))];
  if (!needs.includes('internet') && lead.currentInternet !== 'Leased line') needs.unshift('internet');
  const type = lead.businessType.toLowerCase();
  const cat = CATEGORIES.find((c) => c.id !== 'other' && c.keywords.some((k) => type.includes(k))) || byId(CATEGORIES, 'other');
  return { businessType: cat.id, segment: SEGMENT_FROM_LEAD[lead.segment] || cat.segment, employees: lead.employeeCount, sites: lead.numSites, city: lead.city, cityTier: lead.cityTier, currentInternet: lead.currentInternet, needs, hasGstin: lead.hasGstin };
}

module.exports = { recommend, normaliseProfile, profileFromLead, qtyFor, LINK_PRODUCTS };
