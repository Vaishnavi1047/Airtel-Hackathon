// Explainable, RULE-BASED lead priority score (0-100). This is NOT a trained machine-learning model:
// the points below are hand-set business rules, plus one descriptive statistic (activation rate per segment)
// computed from smb_leads.csv. Every lead carries its own point-by-point breakdown.

const { store } = require('./dataService');
const { recommend, profileFromLead } = require('./recommender');
const { maskGstin } = require('./text');

const STAGE_POINTS = { Lead: 4, Contacted: 10, 'Needs assessed': 18, 'Quote accepted': 26, 'KYC complete': 30, Activated: 30 };

// How recoverable each drop reason is, and whether a self-serve digital journey directly removes it.
const DROP = {
  'Quote too complex to understand': { pts: 30, digital: true, why: 'instant, plain-language quote fixes this' },
  'Quote took too long to arrive': { pts: 30, digital: true, why: 'quote is instant online' },
  'Found paperwork too long': { pts: 28, digital: true, why: 'Smart KYC replaces paper forms' },
  'Owner had no time for a visit': { pts: 28, digital: true, why: 'no visit needed in the digital journey' },
  'Visit not scheduled by sales': { pts: 28, digital: true, why: 'no visit needed in the digital journey' },
  'Missing GST or Udyam document': { pts: 24, digital: true, why: 'registry lookup can replace the missing paper' },
  'Installation delayed beyond 21 days': { pts: 22, digital: true, why: 'self-booked slot and live tracker reduce delay' },
  'Document details did not match': { pts: 20, digital: true, why: 'instant mismatch feedback lets the customer correct it' },
  'Authorised signatory not available': { pts: 18, digital: true, why: 'signatory can finish KYC on their own phone' },
  'First payment failed': { pts: 22, digital: false, why: 'customer was ready to pay; retry with assistance' },
  'Customer cancelled before install': { pts: 14, digital: false, why: 'had bought once; needs a conversation' },
  'Decided to wait': { pts: 16, digital: false, why: 'timing issue, worth a later nudge' },
  'Price too high': { pts: 14, digital: false, why: 'may respond to a smaller Essential bundle' },
  'Competitor offered cheaper plan': { pts: 10, digital: false, why: 'price-led; harder to win back' },
  'Only wanted a mobile plan': { pts: 12, digital: false, why: 'cross-sell later' },
  'Site not feasible for fibre': { pts: 16, digital: false, why: '5G AirFiber may be an alternative' },
  'Locked in with current provider': { pts: 6, digital: false, why: 'revisit when contract ends' },
  'Unreachable after 3 attempts': { pts: 10, digital: true, why: 'a WhatsApp self-serve link does not need a call' },
  'Not interested on first call': { pts: 3, digital: false, why: 'low intent' },
  'Wrong or invalid number': { pts: 0, digital: false, why: 'cannot be contacted' },
};
const HUMAN_REASONS = {
  'Site not feasible for fibre': 'Site feasibility check needed',
  'First payment failed': 'Payment help needed',
  'Authorised signatory not available': 'Signatory coordination needed',
  'Document details did not match': 'Document mismatch to resolve',
  'Customer cancelled before install': 'Win-back conversation needed',
  'Price too high': 'Pricing conversation needed',
};
const SELF_INITIATED = new Set(['Referral', 'Inbound call', 'Website form', 'WhatsApp campaign']);

let segmentRate = null;
function segmentRates() {
  if (segmentRate) return segmentRate;
  const agg = {};
  for (const l of store.leads) { (agg[l.segment] ||= { n: 0, a: 0 }).n++; if (l.outcome === 'Activated') agg[l.segment].a++; }
  const rates = Object.fromEntries(Object.entries(agg).map(([k, v]) => [k, v.a / v.n]));
  const max = Math.max(...Object.values(rates), 0.0001);
  segmentRate = { rates, max };
  return segmentRate;
}

function scoreLead(lead) {
  const breakdown = [];
  const push = (factor, points, max, note) => breakdown.push({ factor, points: Math.round(points), max, note });
  const activated = lead.outcome === 'Activated';

  push('Funnel stage reached', STAGE_POINTS[lead.stageReached] ?? 0, 30, `Reached "${lead.stageReached}"`);

  const d = DROP[lead.dropReason];
  if (activated) push('Drop-off reason', 30, 30, 'Already a customer');
  else push('Drop-off reason', d ? d.pts : 10, 30, d ? `${lead.dropReason}: ${d.why}` : (lead.dropReason || 'No reason recorded'));

  const reg = lead.hasGstin ? store.gstin.get(lead.gstin) : null;
  const gstPts = !lead.hasGstin ? 0 : reg && reg.status !== 'Active' ? 2 : 10;
  const gstNote = !lead.hasGstin ? 'No GSTIN (limits the catalogue)' : reg && reg.status !== 'Active' ? `GSTIN is ${reg.status} in the mock registry` : 'GSTIN available';
  push('Registration readiness', gstPts + (lead.hasUdyam ? 5 : 0), 15, `${gstNote}; Udyam ${lead.hasUdyam ? 'available' : 'not available'}`);

  const { rates, max } = segmentRates();
  const r = rates[lead.segment] || 0;
  push('Business segment fit', (r / max) * 10, 10, `${lead.segment}: ${(r * 100).toFixed(1)}% of such leads activated last quarter`);

  const interest = Math.min(lead.productsOfInterest.length, 3) * 3;
  const chased = lead.followUpCalls > 0 ? 3 : 0;
  const self = SELF_INITIATED.has(lead.leadSource) ? 3 : 0;
  push('Engagement', interest + chased + self, 15, `${lead.productsOfInterest.length} product(s) asked about; ${lead.followUpCalls} follow-up call(s) from customer; source: ${lead.leadSource}`);

  const score = Math.min(100, breakdown.reduce((s, b) => s + b.points, 0));

  const rec = recommend(profileFromLead(lead));
  const opt = rec.options.find((o) => o.key === 'recommended') || rec.options[0];

  const human = [];
  if (!activated) {
    if (HUMAN_REASONS[lead.dropReason]) human.push(HUMAN_REASONS[lead.dropReason]);
    if (lead.numSites >= 5) human.push(`Multi-site rollout (${lead.numSites} locations)`);
    if (reg && reg.status !== 'Active') human.push(`GSTIN ${reg.status.toLowerCase()} in registry`);
    if (opt.items.some((i) => ['P05', 'P06', 'P10', 'P21'].includes(i.productId))) human.push('Managed / leased-line solution needs a site survey');
  }

  return {
    leadId: lead.leadId, businessName: lead.businessName, businessType: lead.businessType, segment: lead.segment,
    city: lead.city, cityTier: lead.cityTier, state: lead.state, preferredLanguage: lead.preferredLanguage,
    employeeCount: lead.employeeCount, numSites: lead.numSites, leadSource: lead.leadSource,
    leadStage: lead.stageReached, outcome: lead.outcome, dropReason: lead.dropReason,
    gstinAvailable: lead.hasGstin, gstinMasked: lead.hasGstin ? maskGstin(lead.gstin) : '', gstinRegistryStatus: reg ? reg.status : (lead.hasGstin ? 'Not found' : ''),
    udyamAvailable: lead.hasUdyam, currentInternet: lead.currentInternet, monthlyTelecomSpend: lead.monthlyTelecomSpend,
    productsOfInterest: lead.productsOfInterest, contactName: lead.contactName, contactRole: lead.contactRole, followUpCalls: lead.followUpCalls,
    propensityScore: score,
    priority: activated ? 'Customer' : score >= 65 ? 'High' : score >= 45 ? 'Medium' : 'Low',
    scoreBreakdown: breakdown,
    needsHumanAssist: human.length > 0, humanAssistReasons: human,
    digitalFixable: !activated && !!(d && d.digital),
    recommendedBundle: { name: `Smart Connect for ${lead.businessType.toLowerCase()}`, products: opt.items.map((i) => ({ productId: i.productId, name: store.productById.get(i.productId).name, qty: i.qty })), monthly: opt.quote.totals.monthly, setup: opt.quote.totals.setup },
    potentialMonthlyRevenue: activated ? (lead.monthlyBundleValue || opt.quote.totals.monthly) : opt.quote.totals.monthly,
    followUpStatus: activated ? 'Converted' : 'New',
  };
}

// Baseline numbers for the business-metrics panel, computed from the CSV (not hardcoded).
function baseline() {
  const leads = store.leads;
  const activated = leads.filter((l) => l.outcome === 'Activated');
  const order = ['Lead', 'Contacted', 'Needs assessed', 'Quote accepted', 'KYC complete', 'Activated'];
  const funnel = order.map((stage, i) => ({ stage, count: leads.filter((l) => order.indexOf(l.stageReached) >= i).length }));
  const dropCounts = {};
  for (const l of leads) if (l.outcome !== 'Activated') dropCounts[l.dropReason || 'Not recorded'] = (dropCounts[l.dropReason || 'Not recorded'] || 0) + 1;
  const dropReasons = Object.entries(dropCounts).map(([reason, count]) => ({ reason, count, digitalFixable: !!DROP[reason]?.digital })).sort((a, b) => b.count - a.count);
  const totalCost = leads.reduce((s, l) => s + (l.acquisitionCost || 0), 0);
  const days = activated.map((l) => l.daysToActivation).filter((x) => x !== null);
  const bySegment = Object.entries(segmentRates().rates).map(([segment, rate]) => ({ segment, leads: leads.filter((l) => l.segment === segment).length, activationRate: rate }));
  return {
    totalLeads: leads.length,
    activatedCustomers: activated.length,
    conversionRate: activated.length / leads.length,
    avgActivationDays: days.reduce((s, x) => s + x, 0) / (days.length || 1),
    acquisitionCostPerCustomer: totalCost / (activated.length || 1),
    avgFollowUpCalls: activated.reduce((s, l) => s + (l.followUpCalls || 0), 0) / (activated.length || 1),
    avgMonthlyBundleValue: activated.reduce((s, l) => s + (l.monthlyBundleValue || 0), 0) / (activated.length || 1),
    funnel, dropReasons, bySegment,
    digitalFixableDrops: dropReasons.filter((d) => d.digitalFixable).reduce((s, d) => s + d.count, 0),
    period: 'Apr-Jun 2026 (smb_leads.csv)',
  };
}

module.exports = { scoreLead, baseline, DROP };
