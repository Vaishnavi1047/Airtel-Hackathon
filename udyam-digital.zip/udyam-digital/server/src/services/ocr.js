// OCR with Tesseract.js. The English language data ships inside node_modules (@tesseract.js-data/eng),
// so OCR works offline - handy on hackathon Wi-Fi.
// Images are processed from memory and never written to disk by us.

const path = require('path');
const os = require('os');
const { createWorker } = require('tesseract.js');

let workerPromise = null;
let queue = Promise.resolve();

function getWorker() {
  if (!workerPromise) {
    const langPath = path.join(path.dirname(require.resolve('@tesseract.js-data/eng/package.json')), '4.0.0_best_int');
    workerPromise = createWorker('eng', 1, { langPath, gzip: true, cachePath: os.tmpdir() }).catch((e) => { workerPromise = null; throw e; });
  }
  return workerPromise;
}

async function recognise(buffer) {
  // One document at a time: a single worker is plenty for a demo and keeps memory low.
  const run = queue.then(async () => {
    const worker = await getWorker();
    const { data } = await worker.recognize(buffer, { rotateAuto: true });
    return { text: data.text || '', confidence: Math.round(data.confidence || 0) };
  });
  queue = run.catch(() => {});
  return run;
}

async function shutdown() {
  if (workerPromise) { const w = await workerPromise.catch(() => null); workerPromise = null; if (w) await w.terminate(); }
}

module.exports = { recognise, shutdown, warmUp: () => getWorker().then(() => true) };
