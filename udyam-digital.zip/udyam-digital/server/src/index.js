const config = require('./config');
const db = require('./db');
const data = require('./services/dataService');
const { createApp } = require('./app');
const { seedLeads } = require('./seed');
const ocr = require('./services/ocr');
const llm = require('./services/llm');

async function main() {
  console.log('\nUdyam Digital - starting up');
  const store = await data.load();
  console.log(`  Data loaded: ${store.products.length} products, ${store.leads.length} leads, ${store.gstin.size} GST records, ${store.udyam.size} Udyam records`);
  store.warnings.forEach((w) => console.warn('  Data warning:', w));

  const { mode } = await db.connect();
  console.log(`  Database: ${mode}`);
  const seeded = await seedLeads();
  console.log(`  Leads in database: ${seeded.count}${seeded.seeded ? ' (scored and loaded just now)' : ''}`);
  console.log(`  AI advisor: ${llm.enabled() ? `LLM wording ON (${config.llm.model}) + rule engine` : 'rule-based engine (no LLM key set - this is fine)'}`);

  const app = createApp();
  const server = app.listen(config.port, () => {
    console.log(`\n  API ready at http://localhost:${config.port}/api/health`);
    console.log('  Now start the website in a second terminal:  cd client && npm run dev\n');
  });
  server.on('error', (e) => {
    console.error(e.code === 'EADDRINUSE' ? `\nPort ${config.port} is already in use. Close the other server window, or set PORT=4001 in server/.env.` : e.message);
    process.exit(1);
  });
  ocr.warmUp().catch((e) => console.warn('  OCR warm-up failed (it will retry on first upload):', e.message));

  const stop = async () => { server.close(); await ocr.shutdown().catch(() => {}); await db.disconnect(); process.exit(0); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}

main().catch((e) => {
  console.error('\nCould not start the server:\n ', e.message);
  if (/ECONNREFUSED|ENOTFOUND|Server selection|download/i.test(e.message)) console.error('  Tip: check MONGODB_URI in server/.env, or your internet connection (needed once to download the built-in MongoDB).');
  process.exit(1);
});
