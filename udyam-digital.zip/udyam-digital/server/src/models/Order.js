const mongoose = require('mongoose');

const STATUSES = ['ORDER_PLACED', 'KYC_VERIFICATION', 'KYC_APPROVED', 'INSTALLATION_SCHEDULED', 'INSTALLATION_IN_PROGRESS', 'SERVICE_ACTIVATED'];

const productLine = new mongoose.Schema({
  productId: { type: String, required: true },
  name: String, category: String, unit: String,
  qty: { type: Number, min: 1, required: true },
  unitPrice: Number, monthly: Number, setup: Number, minContractMonths: Number, installDays: Number,
}, { _id: false });

const orderSchema = new mongoose.Schema({
  orderId: { type: String, required: true, unique: true, index: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  bundleName: { type: String, trim: true, maxlength: 80 },
  selectedProducts: { type: [productLine], validate: (v) => v.length > 0 },
  monthlyPrice: { type: Number, required: true, min: 0 },
  listMonthlyPrice: { type: Number, min: 0 },
  setupFee: { type: Number, required: true, min: 0 },
  contractDuration: { type: Number, required: true, min: 1 }, // months
  installDays: { type: Number, min: 0 },
  requiresGstin: { type: Boolean, default: false },
  profile: { type: mongoose.Schema.Types.Mixed }, // advisor answers used for eligibility (city tier, size, GSTIN yes/no)
  customer: { businessName: String, ownerName: String, city: String },
  payment: { mode: { type: String, default: 'DEMO' }, reference: String, amount: Number, paidAt: Date },
  orderStatus: { type: String, enum: STATUSES, default: 'ORDER_PLACED', index: true },
  timeline: [{ status: { type: String, enum: STATUSES }, at: Date, note: String, _id: false }],
  installationSlot: { date: String, window: String },
  expectedActivationDate: { type: Date, required: true },
  supportRequests: [{ topic: String, message: String, ticketId: String, at: Date, _id: false }],
}, { timestamps: true });

orderSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Order', orderSchema);
module.exports.STATUSES = STATUSES;
