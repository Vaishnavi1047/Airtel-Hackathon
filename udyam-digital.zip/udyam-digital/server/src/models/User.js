const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  mobile: { type: String, required: true, match: /^[6-9]\d{9}$/, unique: true, index: true },
  email: { type: String, required: true, trim: true, lowercase: true, maxlength: 120, match: /^[^\s@]+@[^\s@]+\.[^\s@]+$/ },
  businessName: { type: String, required: true, trim: true, maxlength: 120 },
  businessType: { type: String, trim: true, maxlength: 60 },
  address: { type: String, required: true, trim: true, maxlength: 300 },
  city: { type: String, trim: true, maxlength: 60 },
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
