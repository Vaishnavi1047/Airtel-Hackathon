const mongoose = require('mongoose');

const STATUS = ['Not started', 'Pending', 'Verified', 'Mismatch', 'Rejected', 'Skipped'];
const check = new mongoose.Schema({ label: String, result: { type: String, enum: ['pass', 'fail', 'warn', 'info'] }, detail: String }, { _id: false });

const kycSchema = new mongoose.Schema({
  orderId: { type: String, required: true, unique: true, index: true },
  consentStatus: { type: String, enum: ['Not given', 'Given', 'Withdrawn'], default: 'Not given' },
  consent: { version: String, givenAt: Date, purposes: [String] },
  gstinStatus: { type: String, enum: STATUS, default: 'Not started' },
  udyamStatus: { type: String, enum: STATUS, default: 'Not started' },
  documentStatus: { type: String, enum: STATUS, default: 'Not started' },
  overallStatus: { type: String, enum: ['In progress', 'Action needed', 'Approved'], default: 'In progress' },
  // Identifiers are kept in full here because verification needs them; API responses and logs only show masked values.
  identifiers: { gstin: { type: String, select: false }, udyam: { type: String, select: false } },
  verificationDetails: {
    gstin: { masked: String, legalName: String, tradeName: String, constitution: String, address: String, state: String, registrationStatus: String, checks: [check], checkedAt: Date },
    udyam: { masked: String, enterpriseName: String, enterpriseType: String, majorActivity: String, city: String, state: String, checks: [check], checkedAt: Date },
    documents: [{
      type: { type: String, enum: ['gst_certificate', 'udyam_certificate', 'signatory_id', 'address_proof'] },
      status: { type: String, enum: STATUS },
      message: String,
      fields: mongoose.Schema.Types.Mixed, // only the few extracted fields needed for matching; the image itself is never stored
      checks: [check],
      ocrConfidence: Number,
      fileHash: String, // SHA-256 fingerprint so a re-upload of the same file can be recognised without keeping the file
      processedAt: Date,
      _id: false,
    }],
  },
  purgeAfter: { type: Date }, // retention: KYC record is deleted after this date
}, { timestamps: true });

// MongoDB removes the KYC record automatically once purgeAfter passes (TTL index).
kycSchema.index({ purgeAfter: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model('Kyc', kycSchema);
