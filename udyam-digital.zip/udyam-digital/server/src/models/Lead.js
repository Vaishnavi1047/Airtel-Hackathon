const mongoose = require('mongoose');

const FOLLOW_UP = ['New', 'Contacted', 'Callback scheduled', 'Sent self-serve link', 'Converted', 'Not interested'];

const leadSchema = new mongoose.Schema({
  leadId: { type: String, required: true, unique: true, index: true },
  businessName: { type: String, required: true, index: true },
  businessType: { type: String, index: true },
  segment: { type: String, index: true },
  city: String, cityTier: Number, state: String, preferredLanguage: String,
  employeeCount: Number, numSites: Number,
  leadSource: String,
  leadStage: { type: String, index: true },
  outcome: { type: String, index: true },
  dropReason: String,
  gstinAvailable: { type: Boolean, index: true },
  gstinMasked: String, gstinRegistryStatus: String,
  udyamAvailable: Boolean,
  currentInternet: String, monthlyTelecomSpend: Number,
  productsOfInterest: [String],
  contactName: String, contactRole: String,
  followUpCalls: Number,
  propensityScore: { type: Number, min: 0, max: 100, index: true },
  priority: { type: String, enum: ['High', 'Medium', 'Low', 'Customer'], index: true },
  scoreBreakdown: [{ factor: String, points: Number, max: Number, note: String, _id: false }],
  needsHumanAssist: { type: Boolean, index: true },
  humanAssistReasons: [String],
  digitalFixable: { type: Boolean, index: true },
  recommendedBundle: { name: String, products: [{ productId: String, name: String, qty: Number, _id: false }], monthly: Number, setup: Number },
  potentialMonthlyRevenue: { type: Number, index: true },
  followUpStatus: { type: String, enum: FOLLOW_UP, default: 'New', index: true },
  followUpNote: { type: String, maxlength: 500 },
  followUpUpdatedAt: Date,
}, { timestamps: true });

module.exports = mongoose.model('Lead', leadSchema);
module.exports.FOLLOW_UP = FOLLOW_UP;
