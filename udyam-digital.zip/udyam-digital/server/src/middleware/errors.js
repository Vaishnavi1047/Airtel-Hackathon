// One place that turns any error into a clean JSON response.

class ApiError extends Error {
  constructor(status, message, details) { super(message); this.status = status; this.details = details; }
}
const badRequest = (msg, details) => new ApiError(400, msg, details);
const notFound = (msg = 'Not found') => new ApiError(404, msg);

// Wrap async route handlers so thrown errors reach the error handler.
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function notFoundHandler(req, res) {
  res.status(404).json({ ok: false, error: { message: `No such API route: ${req.method} ${req.originalUrl}` } });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  let status = err.status || 500;
  let message = err.message || 'Something went wrong';
  let details = err.details;
  if (err.name === 'ValidationError') { status = 400; message = 'Some details are not valid.'; details = Object.values(err.errors || {}).map((e) => e.message); }
  if (err.name === 'MulterError') { status = 400; message = err.code === 'LIMIT_FILE_SIZE' ? 'File is too large. The limit is 5 MB.' : `Upload problem: ${err.message}`; }
  if (err.code === 11000) { status = 409; message = 'This record already exists.'; }
  if (err.type === 'entity.parse.failed') { status = 400; message = 'Request body is not valid JSON.'; }
  if (status >= 500) { console.error('[error]', err); message = 'Something went wrong on our side. Please try again.'; details = undefined; }
  res.status(status).json({ ok: false, error: { message, ...(details ? { details } : {}) } });
}

module.exports = { ApiError, badRequest, notFound, wrap, notFoundHandler, errorHandler };
