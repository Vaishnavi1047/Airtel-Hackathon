// Secure upload handling with Multer.
//  - files stay in memory only (never written to disk), one file per request, max 5 MB
//  - only PNG / JPEG are accepted, checked by BOTH the declared type and the file's first bytes ("magic numbers")
const multer = require('multer');
const config = require('../config');
const { badRequest } = require('./errors');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.upload.maxBytes, files: 1, fields: 5 },
  fileFilter: (req, file, cb) => {
    if (!config.upload.allowedMime.includes(file.mimetype)) return cb(badRequest('Only PNG or JPG images are accepted.'));
    cb(null, true);
  },
});

function sniffImage(buffer) {
  if (!buffer || buffer.length < 12) return null;
  if (buffer.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return 'image/jpeg';
  return null;
}

function requireRealImage(req, res, next) {
  if (!req.file) return next(badRequest('Please choose a document image to upload.'));
  if (!sniffImage(req.file.buffer)) return next(badRequest('This file is not a valid PNG or JPG image.'));
  next();
}

module.exports = { single: upload.single('document'), requireRealImage };
