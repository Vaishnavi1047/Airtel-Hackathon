// Tiny schema validator (keeps the project dependency-light and easy to read).
// rules: { field: { type, required, min, max, pattern, enum, maxLength, label } }
const { badRequest } = require('./errors');

function validate(body, rules) {
  const errors = [];
  const out = {};
  for (const [key, r] of Object.entries(rules)) {
    let v = body?.[key];
    const name = r.label || key;
    if (typeof v === 'string') v = v.trim();
    if (v === undefined || v === null || v === '') {
      if (r.required) errors.push(`${name} is required.`);
      continue;
    }
    if (r.type === 'string') {
      if (typeof v !== 'string') { errors.push(`${name} must be text.`); continue; }
      if (r.maxLength && v.length > r.maxLength) errors.push(`${name} must be at most ${r.maxLength} characters.`);
      if (r.minLength && v.length < r.minLength) errors.push(`${name} must be at least ${r.minLength} characters.`);
      if (r.pattern && !r.pattern.test(v)) errors.push(r.message || `${name} is not in the right format.`);
    } else if (r.type === 'number') {
      v = Number(v);
      if (!Number.isFinite(v)) { errors.push(`${name} must be a number.`); continue; }
      if (r.min !== undefined && v < r.min) errors.push(`${name} must be at least ${r.min}.`);
      if (r.max !== undefined && v > r.max) errors.push(`${name} must be at most ${r.max}.`);
    } else if (r.type === 'boolean') {
      if (typeof v !== 'boolean') { errors.push(`${name} must be true or false.`); continue; }
    } else if (r.type === 'array') {
      if (!Array.isArray(v)) { errors.push(`${name} must be a list.`); continue; }
      if (r.max && v.length > r.max) errors.push(`${name} has too many items.`);
      if (r.min && v.length < r.min) errors.push(`${name} needs at least ${r.min} item(s).`);
    } else if (r.type === 'object') {
      if (typeof v !== 'object' || Array.isArray(v)) { errors.push(`${name} must be an object.`); continue; }
    }
    if (r.enum && !r.enum.includes(v)) errors.push(`${name} must be one of: ${r.enum.join(', ')}.`);
    out[key] = v;
  }
  if (errors.length) throw badRequest('Please correct the highlighted details.', errors);
  return out;
}

module.exports = { validate };
