const router = require('express').Router();
const crypto = require('crypto');
const config = require('../config');
const { wrap, badRequest, notFound, ApiError } = require('../middleware/errors');
const { validate } = require('../middleware/validate');
const { quote } = require('../services/catalogue');
const { tierForCity } = require('../services/dataService');
const { maskMobile, maskEmail } = require('../services/text');
const User = require('../models/User');
const Order = require('../models/Order');
const Kyc = require('../models/Kyc');
const svc = require('../services/orderService');

function publicOrder(order, user, kyc) {
  const info = kyc ? svc.evaluateKyc(kyc, order) : { required: [], missing: [] };
  const currentIndex = svc.STATUSES.indexOf(order.orderStatus);
  const at = Object.fromEntries(order.timeline.map((t) => [t.status, t]));
  return {
    orderId: order.orderId,
    bundleName: order.bundleName,
    businessName: order.customer?.businessName,
    ownerName: order.customer?.ownerName,
    city: order.customer?.city,
    contact: user ? { mobile: maskMobile(user.mobile), email: maskEmail(user.email) } : null,
    selectedProducts: order.selectedProducts,
    monthlyPrice: order.monthlyPrice, listMonthlyPrice: order.listMonthlyPrice, setupFee: order.setupFee,
    contractDuration: order.contractDuration, installDays: order.installDays, requiresGstin: order.requiresGstin,
    payment: order.payment,
    orderDate: order.createdAt,
    expectedActivationDate: order.expectedActivationDate,
    orderStatus: order.orderStatus,
    installationSlot: order.installationSlot?.date ? order.installationSlot : null,
    stages: svc.STAGES.map((s, i) => ({ ...s, state: order.orderStatus === 'SERVICE_ACTIVATED' || i < currentIndex ? 'done' : i === currentIndex ? 'current' : 'upcoming', at: at[s.status]?.at || null, note: at[s.status]?.note || null })),
    pendingActions: svc.pendingActions(order, kyc, info),
    slotOptions: order.orderStatus === 'KYC_APPROVED' ? { dates: svc.slotOptions(order), windows: svc.SLOT_WINDOWS } : null,
    kyc: svc.publicKyc(kyc),
    supportRequests: (order.supportRequests || []).map((s) => ({ ticketId: s.ticketId, topic: s.topic, at: s.at })),
    demoMode: config.demoMode,
  };
}

// POST /api/orders - checkout. Prices are always re-calculated on the server from the catalogue.
router.post('/', wrap(async (req, res) => {
  const b = validate(req.body, {
    businessName: { type: 'string', required: true, minLength: 2, maxLength: 120, label: 'Business name' },
    ownerName: { type: 'string', required: true, minLength: 2, maxLength: 80, pattern: /^[\p{L}\p{M} .'-]+$/u, label: 'Owner name', message: 'Owner name can only contain letters and spaces.' },
    mobile: { type: 'string', required: true, pattern: /^[6-9]\d{9}$/, label: 'Mobile number', message: 'Mobile number must be 10 digits and start with 6, 7, 8 or 9.' },
    email: { type: 'string', required: true, maxLength: 120, pattern: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/, label: 'Email', message: 'Please enter a valid email address.' },
    address: { type: 'string', required: true, minLength: 10, maxLength: 300, label: 'Business address' },
    city: { type: 'string', maxLength: 60 },
    businessType: { type: 'string', maxLength: 60 },
    bundleName: { type: 'string', maxLength: 80 },
    items: { type: 'array', required: true, min: 1, max: 30, label: 'Selected bundle' },
    profile: { type: 'object' },
    paymentConfirmed: { type: 'boolean', required: true, label: 'Demo payment confirmation' },
  });
  if (!b.paymentConfirmed) throw badRequest('Please confirm the demo payment to place the order.');

  const p = b.profile || {};
  const profile = { cityTier: b.city ? tierForCity(b.city) : Number(p.cityTier) || 2, employees: Number(p.employees) || 1, sites: Number(p.sites) || 1, hasGstin: p.hasGstin === true };
  const q = quote(b.items, profile);
  if (!q.valid) throw new ApiError(422, 'This bundle cannot be ordered as it is.', q.issues.map((i) => i.en));

  const user = await User.findOneAndUpdate(
    { mobile: b.mobile },
    { name: b.ownerName, mobile: b.mobile, email: b.email.toLowerCase(), businessName: b.businessName, businessType: b.businessType, address: b.address, city: b.city },
    { upsert: true, new: true, runValidators: true, setDefaultsOnInsert: true },
  );

  const now = new Date();
  const order = await Order.create({
    orderId: svc.newOrderId(),
    userId: user._id,
    bundleName: b.bundleName || 'Custom bundle',
    selectedProducts: q.lines.map((l) => ({ productId: l.productId, name: l.name, category: l.category, unit: l.unit, qty: l.qty, unitPrice: l.unitPrice, monthly: l.monthly, setup: l.setup, minContractMonths: l.minContractMonths, installDays: l.installDays })),
    monthlyPrice: q.totals.monthly, listMonthlyPrice: q.totals.listMonthly, setupFee: q.totals.setup,
    contractDuration: q.totals.contractMonths, installDays: q.totals.installDays, requiresGstin: q.requiresGstin,
    profile: { ...profile, city: b.city, businessType: b.businessType },
    customer: { businessName: b.businessName, ownerName: b.ownerName, city: b.city },
    payment: { mode: 'DEMO', reference: `DEMO-PAY-${crypto.randomBytes(4).toString('hex').toUpperCase()}`, amount: q.totals.firstBill, paidAt: now },
    orderStatus: 'KYC_VERIFICATION',
    timeline: [{ status: 'ORDER_PLACED', at: now, note: 'Demo payment received' }, { status: 'KYC_VERIFICATION', at: now, note: 'Waiting for your KYC details' }],
    // 1 day for KYC + the slowest product's typical_install_days from the catalogue
    expectedActivationDate: svc.addDays(now, 1 + q.totals.installDays),
  });
  const kyc = await Kyc.create({ orderId: order.orderId, purgeAfter: svc.addDays(now, config.retention.kycRecordDays) });

  res.status(201).json({ ok: true, data: publicOrder(order, user, kyc) });
}));

router.get('/:orderId', wrap(async (req, res) => {
  const order = await svc.loadOrder(req.params.orderId);
  if (!order) throw notFound('We could not find an order with this ID. Please check it and try again.');
  const [user, kyc] = await Promise.all([User.findById(order.userId), Kyc.findOne({ orderId: order.orderId })]);
  res.json({ ok: true, data: publicOrder(order, user, kyc) });
}));

// PATCH /api/orders/:orderId/status
//   { action: 'schedule', date: 'YYYY-MM-DD', window: '9 am - 12 noon' }   customer books installation (after KYC approval)
//   { action: 'advance' }                                                 DEMO ONLY: simulate the field team moving to the next stage
router.patch('/:orderId/status', wrap(async (req, res) => {
  const b = validate(req.body, { action: { type: 'string', required: true, enum: ['schedule', 'advance'] }, date: { type: 'string', pattern: /^\d{4}-\d{2}-\d{2}$/ }, window: { type: 'string', maxLength: 30 } });
  const order = await svc.loadOrder(req.params.orderId);
  if (!order) throw notFound('Order not found');

  if (b.action === 'schedule') {
    if (order.orderStatus !== 'KYC_APPROVED') throw new ApiError(409, 'Installation can be booked once KYC is approved and before a date has been fixed.');
    if (!svc.slotOptions(order).includes(b.date) || !svc.SLOT_WINDOWS.includes(b.window)) throw badRequest('Please choose one of the offered dates and time windows.');
    order.installationSlot = { date: b.date, window: b.window };
    order.expectedActivationDate = new Date(`${b.date}T12:00:00.000Z`);
    svc.moveTo(order, 'INSTALLATION_SCHEDULED', `Booked by customer for ${b.date}, ${b.window}`);
  } else {
    if (!config.demoMode) throw new ApiError(403, 'Stage simulation is switched off (DEMO_MODE=false).');
    const next = { INSTALLATION_SCHEDULED: ['INSTALLATION_IN_PROGRESS', 'Engineer on site (simulated)'], INSTALLATION_IN_PROGRESS: ['SERVICE_ACTIVATED', 'Services tested and live (simulated)'] }[order.orderStatus];
    if (!next) {
      const why = { KYC_VERIFICATION: 'Finish KYC first - approval is automatic once every check passes.', KYC_APPROVED: 'Choose an installation date first.', SERVICE_ACTIVATED: 'This order is already active.' }[order.orderStatus] || 'This order cannot move forward yet.';
      throw new ApiError(409, why);
    }
    svc.moveTo(order, next[0], next[1]);
  }
  await order.save();
  const [user, kyc] = await Promise.all([User.findById(order.userId), Kyc.findOne({ orderId: order.orderId })]);
  res.json({ ok: true, data: publicOrder(order, user, kyc) });
}));

// POST /api/orders/:orderId/support - simulated help request
router.post('/:orderId/support', wrap(async (req, res) => {
  const b = validate(req.body, { topic: { type: 'string', required: true, maxLength: 60 }, message: { type: 'string', maxLength: 500 } });
  const order = await svc.loadOrder(req.params.orderId);
  if (!order) throw notFound('Order not found');
  if ((order.supportRequests || []).length >= 10) throw new ApiError(429, 'You already have several open requests. Our team will call you back.');
  const ticketId = `HELP-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  order.supportRequests.push({ topic: b.topic, message: b.message || '', ticketId, at: new Date() });
  await order.save();
  res.status(201).json({ ok: true, data: { ticketId, message: 'Request received (simulated). In a live service a support agent would call you back within 2 working hours.' } });
}));

module.exports = router;
