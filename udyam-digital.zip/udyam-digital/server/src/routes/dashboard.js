const router = require('express').Router();
const crypto = require('crypto');
const config = require('../config');
const { wrap, notFound, ApiError } = require('../middleware/errors');
const { validate } = require('../middleware/validate');
const { baseline } = require('../services/leadScoring');
const Lead = require('../models/Lead');
const Order = require('../models/Order');

// The dashboard shows lead contact details, so it sits behind a simple access code (demo-grade, not real authentication).
function sameCode(given) {
  const a = Buffer.from(String(given || '')), b = Buffer.from(config.partnerAccessCode);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
router.post('/login', (req, res, next) => (sameCode(req.body?.code) ? res.json({ ok: true, data: { granted: true } }) : next(new ApiError(401, 'That access code is not correct.'))));
router.use((req, res, next) => (sameCode(req.get('x-partner-code')) ? next() : next(new ApiError(401, 'Partner access code required.'))));

const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// GET /api/dashboard/summary
router.get('/summary', wrap(async (req, res) => {
  const open = await Lead.find({ outcome: { $ne: 'Activated' } }).select('priority needsHumanAssist digitalFixable potentialMonthlyRevenue followUpStatus leadStage segment').lean();
  const count = (fn) => open.filter(fn).length;
  const sum = (fn) => open.filter(fn).reduce((s, l) => s + (l.potentialMonthlyRevenue || 0), 0);
  const followUp = {};
  for (const l of open) followUp[l.followUpStatus] = (followUp[l.followUpStatus] || 0) + 1;
  const stage = {};
  for (const l of open) stage[l.leadStage] = (stage[l.leadStage] || 0) + 1;
  res.json({ ok: true, data: {
    baseline: baseline(),
    leads: {
      total: open.length + await Lead.countDocuments({ outcome: 'Activated' }),
      notConverted: open.length,
      needingHumanAssistance: count((l) => l.needsHumanAssist),
      highPriority: count((l) => l.priority === 'High'),
      mediumPriority: count((l) => l.priority === 'Medium'),
      lowPriority: count((l) => l.priority === 'Low'),
      digitalFixable: count((l) => l.digitalFixable),
      byStage: stage, byFollowUp: followUp,
    },
    pipeline: { potentialMonthlyRevenueAll: sum(() => true), potentialMonthlyRevenueHigh: sum((l) => l.priority === 'High') },
    liveOrders: { total: await Order.countDocuments({}), activated: await Order.countDocuments({ orderStatus: 'SERVICE_ACTIVATED' }) },
    scoring: { type: 'Rule-based demo score', note: 'Points are hand-set business rules plus one descriptive statistic from smb_leads.csv. It is not a trained machine-learning model and has not been validated on outcomes.' },
  } });
}));

// GET /api/dashboard/leads?priority=&stage=&segment=&needsHuman=&gstin=&digital=&followUp=&q=&sort=&page=&limit=
router.get('/leads', wrap(async (req, res) => {
  const q = req.query;
  const filter = {};
  if (q.outcome === 'all') { /* include customers */ } else if (q.outcome === 'Activated') filter.outcome = 'Activated'; else filter.outcome = { $ne: 'Activated' };
  if (['High', 'Medium', 'Low'].includes(q.priority)) filter.priority = q.priority;
  if (q.stage) filter.leadStage = String(q.stage);
  if (q.segment) filter.segment = String(q.segment);
  if (q.followUp && Lead.FOLLOW_UP.includes(q.followUp)) filter.followUpStatus = q.followUp;
  if (q.needsHuman === 'true') filter.needsHumanAssist = true;
  if (q.needsHuman === 'false') filter.needsHumanAssist = false;
  if (q.digital === 'true') filter.digitalFixable = true;
  if (q.gstin === 'true') filter.gstinAvailable = true;
  if (q.gstin === 'false') filter.gstinAvailable = false;
  if (q.q) filter.businessName = { $regex: escapeRe(String(q.q).slice(0, 50)), $options: 'i' };
  const sorts = { score: { propensityScore: -1, potentialMonthlyRevenue: -1 }, revenue: { potentialMonthlyRevenue: -1 }, name: { businessName: 1 } };
  const page = Math.max(1, parseInt(q.page, 10) || 1);
  const limit = Math.min(50, Math.max(5, parseInt(q.limit, 10) || 20));
  const [items, total] = await Promise.all([
    Lead.find(filter).sort(sorts[q.sort] || sorts.score).skip((page - 1) * limit).limit(limit)
      .select('leadId businessName businessType segment city leadStage dropReason gstinAvailable propensityScore priority needsHumanAssist digitalFixable recommendedBundle.name potentialMonthlyRevenue followUpStatus preferredLanguage').lean(),
    Lead.countDocuments(filter),
  ]);
  res.json({ ok: true, data: { items, total, page, pages: Math.max(1, Math.ceil(total / limit)), limit, followUpOptions: Lead.FOLLOW_UP } });
}));

router.get('/leads/:id', wrap(async (req, res) => {
  const lead = await Lead.findOne({ leadId: String(req.params.id).toUpperCase() }).lean();
  if (!lead) throw notFound('Lead not found');
  res.json({ ok: true, data: lead });
}));

// PATCH /api/dashboard/leads/:id  { followUpStatus, followUpNote }
router.patch('/leads/:id', wrap(async (req, res) => {
  const b = validate(req.body, { followUpStatus: { type: 'string', enum: Lead.FOLLOW_UP, label: 'Follow-up status' }, followUpNote: { type: 'string', maxLength: 500, label: 'Note' } });
  if (b.followUpStatus === undefined && b.followUpNote === undefined) throw new ApiError(400, 'Nothing to update.');
  const lead = await Lead.findOneAndUpdate({ leadId: String(req.params.id).toUpperCase() }, { ...b, followUpUpdatedAt: new Date() }, { new: true, runValidators: true }).lean();
  if (!lead) throw notFound('Lead not found');
  res.json({ ok: true, data: lead });
}));

module.exports = router;
