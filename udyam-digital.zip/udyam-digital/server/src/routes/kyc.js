const router = require('express').Router();
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const config = require('../config');
const { wrap, badRequest, notFound, ApiError } = require('../middleware/errors');
const { validate } = require('../middleware/validate');
const upload = require('../middleware/upload');
const { store } = require('../services/dataService');
const { validateGstin, validateUdyam } = require('../services/gstin');
const { similarity, maskGstin, maskUdyam } = require('../services/text');
const ocr = require('../services/ocr');
const docs = require('../services/kycDocs');
const svc = require('../services/orderService');
const Kyc = require('../models/Kyc');
const User = require('../models/User');

const NOTICE = {
  version: config.consentVersion,
  disclaimer: 'This is a simulated hackathon KYC. Checks run against mock registries and are not official government verification.',
  sections: [
    { title: 'What we collect', points: ['Your GSTIN and Udyam number (if you have them)', 'Photos of up to four documents: GST certificate, Udyam certificate, signatory ID and a recent utility bill', 'From those photos we read only: names, registration numbers, address and document dates'] },
    { title: 'Why we need it', points: ['To confirm the business exists and is active before services are installed', 'To confirm the person ordering is allowed to sign for the business', 'To confirm the installation address'] },
    { title: 'How it is processed', points: ['Numbers are looked up in mock GST and Udyam registries', 'Document photos are read by OCR software on our server and then discarded - the image itself is never saved', 'We keep only the few fields we read, the result of each check and a fingerprint (hash) of the file'] },
    { title: 'How long we keep it', points: [`KYC results are deleted automatically ${config.retention.kycRecordDays} days after your order`, 'Document images: not stored at all', 'You can ask support to delete your KYC record earlier'] },
    { title: 'Who can see it', points: ['You, through your order ID', 'The KYC review team, only when a check needs a human decision', 'Sales partners see masked identifiers only (for example 09••••••••••1Z5)'] },
  ],
};

router.get('/notice', (req, res) => res.json({ ok: true, data: NOTICE }));

async function load(orderId, withIds = false) {
  const order = await svc.loadOrder(orderId);
  if (!order) throw notFound('We could not find this order. Please check the order ID.');
  let q = Kyc.findOne({ orderId: order.orderId });
  if (withIds) q = q.select('+identifiers.gstin +identifiers.udyam');
  const kyc = await q;
  if (!kyc) throw notFound('KYC record not found for this order.');
  return { order, kyc };
}
const requireConsent = (kyc) => { if (kyc.consentStatus !== 'Given') throw new ApiError(403, 'Please read the notice and give consent before we process any KYC details.'); };
const respond = async (res, kyc, order, extra = {}) => { await svc.syncKyc(kyc, order); res.json({ ok: true, data: { ...extra, kyc: svc.publicKyc(kyc), orderStatus: order.orderStatus } }); };

// POST /api/kyc/consent  { orderId, accepted: true }
router.post('/consent', wrap(async (req, res) => {
  const b = validate(req.body, { orderId: { type: 'string', required: true, maxLength: 20 }, accepted: { type: 'boolean', required: true } });
  const { order, kyc } = await load(b.orderId);
  if (!b.accepted) throw badRequest('We cannot process KYC without your consent. You can still browse plans, or contact support for help.');
  kyc.consentStatus = 'Given';
  kyc.consent = { version: NOTICE.version, givenAt: new Date(), purposes: ['Business verification', 'Signatory verification', 'Installation address verification'] };
  await respond(res, kyc, order);
}));

// POST /api/kyc/gstin/verify  { orderId, gstin } or { orderId, skip: true }
router.post('/gstin/verify', wrap(async (req, res) => {
  const b = validate(req.body, { orderId: { type: 'string', required: true, maxLength: 20 }, gstin: { type: 'string', maxLength: 20 }, skip: { type: 'boolean' } });
  const { order, kyc } = await load(b.orderId, true);
  requireConsent(kyc);
  kyc.verificationDetails = kyc.verificationDetails || {};

  if (b.skip) {
    if (order.requiresGstin) throw new ApiError(422, 'Your order includes services that can only be sold with an active GSTIN, so this step cannot be skipped.');
    kyc.gstinStatus = 'Skipped';
    kyc.identifiers = { ...(kyc.identifiers || {}), gstin: undefined };
    kyc.verificationDetails.gstin = undefined;
    kyc.verificationDetails.documents = (kyc.verificationDetails.documents || []).filter((d) => d.type !== 'gst_certificate');
    return respond(res, kyc, order, { result: { status: 'Skipped', message: 'GSTIN step skipped.' } });
  }

  const v = validateGstin(b.gstin);
  if (!v.valid) throw badRequest(v.reason);
  const rec = store.gstin.get(v.gstin);
  const checks = [{ label: 'Format and check digit', result: 'pass', detail: `Valid 15-character GSTIN${v.stateName ? ` (state code ${v.stateCode}: ${v.stateName})` : ''}.` }];
  let status, message;
  const user = await User.findById(order.userId);

  if (!rec) {
    status = 'Rejected'; message = 'This GSTIN is not in the mock GST registry. Please check the number.';
    checks.push({ label: 'Registry lookup', result: 'fail', detail: 'No record found in mock_gstin_registry.csv.' });
  } else {
    checks.push({ label: 'Registry lookup', result: 'pass', detail: 'Record found in the mock GST registry.' });
    if (rec.status !== 'Active') {
      status = 'Rejected'; message = `This GST registration is ${rec.status}. Services cannot be activated on a ${rec.status.toLowerCase()} registration.`;
      checks.push({ label: 'Registration status', result: 'fail', detail: `Registry shows "${rec.status}".` });
    } else {
      checks.push({ label: 'Registration status', result: 'pass', detail: 'Active.' });
      const nameSim = Math.max(similarity(order.customer.businessName, rec.tradeName), similarity(order.customer.businessName, rec.legalName));
      const nameOk = nameSim >= 0.8;
      checks.push({ label: 'Business name', result: nameOk ? 'pass' : 'fail', detail: nameOk ? 'Matches the name on your order.' : `Your order says "${order.customer.businessName}" but the registry has "${rec.tradeName}".` });
      const city = (order.customer.city || '').toLowerCase();
      const addrOk = city ? rec.address.toLowerCase().includes(city) : similarity(user?.address, rec.address) >= 0.5;
      checks.push({ label: 'Location', result: addrOk ? 'pass' : 'warn', detail: addrOk ? 'Registered address is in the same city as your order.' : 'Registered address is in a different city from your order. Installation address will be confirmed from your address proof.' });
      status = nameOk ? 'Verified' : 'Mismatch';
      message = nameOk ? 'GSTIN found and active in the mock GST registry.' : 'The business name on your order does not match this GSTIN.';
    }
  }

  kyc.gstinStatus = status;
  kyc.identifiers = { ...(kyc.identifiers || {}), gstin: status === 'Verified' ? v.gstin : undefined };
  kyc.verificationDetails.gstin = rec
    ? { masked: maskGstin(v.gstin), legalName: rec.legalName, tradeName: rec.tradeName, constitution: rec.constitution, address: rec.address, state: rec.state, registrationStatus: rec.status, checks, checkedAt: new Date() }
    : { masked: maskGstin(v.gstin), registrationStatus: 'Not found', checks, checkedAt: new Date() };
  // A changed GSTIN makes an earlier GST certificate result meaningless.
  kyc.verificationDetails.documents = (kyc.verificationDetails.documents || []).filter((d) => d.type !== 'gst_certificate');
  await respond(res, kyc, order, { result: { status, message } });
}));

// POST /api/kyc/udyam/verify  { orderId, udyamNumber } or { orderId, skip: true }
router.post('/udyam/verify', wrap(async (req, res) => {
  const b = validate(req.body, { orderId: { type: 'string', required: true, maxLength: 20 }, udyamNumber: { type: 'string', maxLength: 30 }, skip: { type: 'boolean' } });
  const { order, kyc } = await load(b.orderId, true);
  requireConsent(kyc);
  kyc.verificationDetails = kyc.verificationDetails || {};

  if (b.skip) {
    kyc.udyamStatus = 'Skipped';
    kyc.identifiers = { ...(kyc.identifiers || {}), udyam: undefined };
    kyc.verificationDetails.udyam = undefined;
    kyc.verificationDetails.documents = (kyc.verificationDetails.documents || []).filter((d) => d.type !== 'udyam_certificate');
    return respond(res, kyc, order, { result: { status: 'Skipped', message: 'Udyam step skipped. It is optional.' } });
  }

  const v = validateUdyam(b.udyamNumber);
  if (!v.valid) throw badRequest(v.reason);
  const rec = store.udyam.get(v.udyam);
  const checks = [{ label: 'Format', result: 'pass', detail: 'Valid Udyam number format.' }];
  let status, message;
  if (!rec) {
    status = 'Rejected'; message = 'This Udyam number is not in the mock Udyam registry. Please check the number, or skip this optional step.';
    checks.push({ label: 'Registry lookup', result: 'fail', detail: 'No record found in mock_udyam_registry.csv.' });
  } else {
    checks.push({ label: 'Registry lookup', result: 'pass', detail: 'Record found in the mock Udyam registry.' });
    const expected = kyc.verificationDetails.gstin?.tradeName || order.customer.businessName;
    const nameOk = similarity(expected, rec.enterpriseName) >= 0.8;
    checks.push({ label: 'Enterprise name', result: nameOk ? 'pass' : 'fail', detail: nameOk ? 'Matches your business name.' : `Registry has "${rec.enterpriseName}" but your business is "${expected}".` });
    const gstState = kyc.verificationDetails.gstin?.state;
    if (gstState) checks.push({ label: 'State', result: gstState === rec.state ? 'pass' : 'warn', detail: gstState === rec.state ? 'Same state as your GST registration.' : `Udyam is registered in ${rec.state}, GST in ${gstState}.` });
    status = nameOk ? 'Verified' : 'Mismatch';
    message = nameOk ? 'Udyam registration found in the mock Udyam registry.' : 'This Udyam number belongs to a business with a different name.';
  }
  kyc.udyamStatus = status;
  kyc.identifiers = { ...(kyc.identifiers || {}), udyam: status === 'Verified' ? v.udyam : undefined };
  kyc.verificationDetails.udyam = rec
    ? { masked: maskUdyam(v.udyam), enterpriseName: rec.enterpriseName, enterpriseType: rec.enterpriseType, majorActivity: rec.majorActivity, city: rec.city, state: rec.state, checks, checkedAt: new Date() }
    : { masked: maskUdyam(v.udyam), checks, checkedAt: new Date() };
  kyc.verificationDetails.documents = (kyc.verificationDetails.documents || []).filter((d) => d.type !== 'udyam_certificate');
  await respond(res, kyc, order, { result: { status, message } });
}));

const uploadLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 60, standardHeaders: true, legacyHeaders: false, message: { ok: false, error: { message: 'Too many uploads. Please wait a few minutes and try again.' } } });

// POST /api/kyc/upload  multipart/form-data: orderId, docType, document (PNG/JPG, max 5 MB)
router.post('/upload', uploadLimiter, upload.single, upload.requireRealImage, wrap(async (req, res) => {
  const b = validate(req.body, { orderId: { type: 'string', required: true, maxLength: 20 }, docType: { type: 'string', required: true, enum: Object.keys(docs.DOC_TYPES), label: 'Document type' } });
  const { order, kyc } = await load(b.orderId, true);
  requireConsent(kyc);
  if (b.docType === 'gst_certificate' && kyc.gstinStatus !== 'Verified') throw new ApiError(409, 'Please verify your GSTIN first, then upload the GST certificate.');
  if (b.docType === 'udyam_certificate' && kyc.udyamStatus !== 'Verified') throw new ApiError(409, 'Please verify your Udyam number first, then upload the Udyam certificate.');
  if (['Not started', 'Rejected', 'Mismatch'].includes(kyc.gstinStatus) && order.requiresGstin) throw new ApiError(409, 'Please complete the GSTIN step before uploading documents.');

  const fileHash = crypto.createHash('sha256').update(req.file.buffer).digest('hex');
  let result;
  try {
    result = await ocr.recognise(req.file.buffer);
  } catch (e) {
    console.error('[ocr] failed:', e.message);
    throw new ApiError(422, 'We could not process this image. Please try a clearer PNG or JPG photo.');
  } finally {
    req.file.buffer = null; // drop the image from memory as soon as OCR is done
  }

  const user = await User.findById(order.userId);
  const gstin = kyc.identifiers?.gstin, udyam = kyc.identifiers?.udyam;
  const outcome = docs.evaluate(b.docType, result, {
    gstin, gstinRecord: gstin ? store.gstin.get(gstin) : null,
    udyam, udyamRecord: udyam ? store.udyam.get(udyam) : null,
    businessName: order.customer.businessName, ownerName: order.customer.ownerName, address: user?.address,
    referenceDate: config.kycReferenceDate,
  });

  kyc.verificationDetails = kyc.verificationDetails || {};
  const others = (kyc.verificationDetails.documents || []).filter((d) => d.type !== b.docType);
  kyc.verificationDetails.documents = [...others, { type: b.docType, status: outcome.status, message: outcome.message, fields: outcome.fields, checks: outcome.checks, ocrConfidence: outcome.ocrConfidence, fileHash, processedAt: new Date() }];
  kyc.markModified('verificationDetails');
  console.log(`[kyc] ${order.orderId} ${b.docType} -> ${outcome.status} (ocr ${outcome.ocrConfidence}%, file ${fileHash.slice(0, 8)}…)`); // no personal data in logs
  await respond(res, kyc, order, { document: { type: b.docType, label: docs.DOC_TYPES[b.docType].label, ...outcome } });
}));

// GET /api/kyc/:orderId/status
router.get('/:orderId/status', wrap(async (req, res) => {
  const { order, kyc } = await load(req.params.orderId);
  const info = svc.evaluateKyc(kyc, order);
  res.json({ ok: true, data: { kyc: svc.publicKyc(kyc), requiredDocuments: info.required.map((t) => ({ type: t, label: svc.DOC_LABEL[t] })), optionalDocuments: [], missingDocuments: info.missing, orderStatus: order.orderStatus, requiresGstin: order.requiresGstin, business: { name: order.customer.businessName, ownerName: order.customer.ownerName }, referenceDate: config.kycReferenceDate } });
}));

module.exports = router;
