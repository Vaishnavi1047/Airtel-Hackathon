const router = require('express').Router();
const { wrap, notFound } = require('../middleware/errors');
const { validate } = require('../middleware/validate');
const { store, tierForCity } = require('../services/dataService');
const { quote, publicProduct, PRICE_POLICY } = require('../services/catalogue');

const profileFrom = (src = {}) => ({
  cityTier: src.city ? tierForCity(src.city) : Number(src.cityTier) || 2,
  employees: Number(src.employees) || 1,
  sites: Number(src.sites) || 1,
  hasGstin: src.hasGstin === true || src.hasGstin === 'true',
});

// GET /api/products?category=&cityTier=&employees=&sites=&hasGstin=   (eligibility is included when a profile is passed)
router.get('/', (req, res) => {
  const withProfile = ['cityTier', 'city', 'employees', 'sites', 'hasGstin'].some((k) => req.query[k] !== undefined);
  const profile = withProfile ? profileFrom(req.query) : null;
  let list = store.products;
  if (req.query.category) list = list.filter((p) => p.category.toLowerCase() === String(req.query.category).toLowerCase());
  res.json({ ok: true, data: { products: list.map((p) => publicProduct(p, profile)), categories: [...new Set(store.products.map((p) => p.category))], pricePolicy: PRICE_POLICY, source: 'product_catalogue.csv' } });
});

router.get('/:id', (req, res, next) => {
  const p = store.productById.get(String(req.params.id).toUpperCase());
  if (!p) return next(notFound('Product not found'));
  res.json({ ok: true, data: publicProduct(p) });
});

// POST /api/products/quote  body: { items: [{ productId, qty }], profile: { city | cityTier, employees, sites, hasGstin } }
router.post('/quote', wrap(async (req, res) => {
  const b = validate(req.body, { items: { type: 'array', required: true, min: 1, max: 30 }, profile: { type: 'object' } });
  res.json({ ok: true, data: quote(b.items, profileFrom(b.profile)) });
}));

module.exports = router;
module.exports.profileFrom = profileFrom;
