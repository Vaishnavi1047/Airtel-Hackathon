// Small helper endpoints: app settings for the UI, GSTIN auto-fill at checkout, and the sample documents for the demo.
const router = require('express').Router();
const path = require('path');
const fs = require('fs');
const config = require('../config');
const { wrap, badRequest, notFound } = require('../middleware/errors');
const { store, cities } = require('../services/dataService');
const { validateGstin } = require('../services/gstin');
const { CATEGORIES, NEEDS, INTERNET } = require('../services/advisorContent');
const llm = require('../services/llm');
const { baseline } = require('../services/leadScoring');

router.get('/meta', (req, res) => res.json({ ok: true, data: {
  cities: cities(), categories: CATEGORIES.map(({ id, en, hi }) => ({ id, en, hi })), needs: NEEDS.map(({ id, en, hi }) => ({ id, en, hi })), internet: INTERNET.map(({ id, en, hi }) => ({ id, en, hi })),
  demoMode: config.demoMode, llmEnabled: llm.enabled(), kycReferenceDate: config.kycReferenceDate,
  baseline: (() => { const b = baseline(); return { totalLeads: b.totalLeads, activatedCustomers: b.activatedCustomers, conversionRate: b.conversionRate, avgActivationDays: b.avgActivationDays, avgFollowUpCalls: b.avgFollowUpCalls }; })(),
  dataset: { products: store.products.length, leads: store.leads.length, gstinRecords: store.gstin.size, udyamRecords: store.udyam.size },
} }));

// GET /api/lookup/gstin/:gstin - lets checkout pre-fill the business name and address from the mock registry.
router.get('/lookup/gstin/:gstin', wrap(async (req, res) => {
  const v = validateGstin(req.params.gstin);
  if (!v.valid) throw badRequest(v.reason);
  const rec = store.gstin.get(v.gstin);
  if (!rec) throw notFound('This GSTIN is not in the mock GST registry.');
  const cityGuess = cities().find((c) => rec.address.includes(c.city))?.city || '';
  res.json({ ok: true, data: { tradeName: rec.tradeName, legalName: rec.legalName, address: rec.address, state: rec.state, city: cityGuess, status: rec.status } });
}));

// Sample (specimen) applicants and documents shipped with the hackathon data pack - for demos only.
router.get('/demo/applicants', (req, res) => res.json({ ok: true, data: store.demoApplicants }));

const SAMPLE_RE = /^[A-Z]\d{2}_(gst_certificate|udyam_certificate|signatory_id|address_proof)\.png$/;
router.get('/demo/documents/:file', (req, res, next) => {
  const file = String(req.params.file);
  if (!SAMPLE_RE.test(file)) return next(notFound('Sample document not found'));
  const full = path.join(config.dataDir, 'kyc_documents', file);
  if (!fs.existsSync(full)) return next(notFound('Sample document not found'));
  res.type('png').sendFile(full);
});

module.exports = router;
