const router = require('express').Router();
const { wrap } = require('../middleware/errors');
const { validate } = require('../middleware/validate');
const advisor = require('../services/advisor');
const { recommend } = require('../services/recommender');

// POST /api/advisor/chat - one turn of the conversation.
// body: { sessionId?, lang?: 'en'|'hi', action?: 'start'|'answer'|'edit'|'restart'|'lang'|'question', field?, value?, message? }
router.post('/chat', wrap(async (req, res) => {
  const body = req.body || {};
  validate(body, {
    sessionId: { type: 'string', maxLength: 64 },
    lang: { type: 'string', enum: ['en', 'hi'] },
    action: { type: 'string', enum: ['start', 'answer', 'edit', 'restart', 'lang', 'question'] },
    field: { type: 'string', enum: advisor.FIELDS },
    message: { type: 'string', maxLength: 500 },
  });
  res.json({ ok: true, data: await advisor.handle(body) });
}));

// POST /api/advisor/recommend - recommendation straight from a profile (no chat needed).
// body: { businessType, employees, sites, city, currentInternet, needs: [], hasGstin }
router.post('/recommend', wrap(async (req, res) => {
  const p = validate(req.body, {
    businessType: { type: 'string', required: true, maxLength: 40 },
    employees: { type: 'number', required: true, min: 1, max: 5000 },
    sites: { type: 'number', required: true, min: 1, max: 500 },
    city: { type: 'string', maxLength: 60 },
    currentInternet: { type: 'string', maxLength: 40 },
    needs: { type: 'array', max: 20 },
    hasGstin: { type: 'boolean', required: true },
  });
  res.json({ ok: true, data: recommend(p) });
}));

module.exports = router;
