// Fills the Lead collection from smb_leads.csv (with scores) the first time the server starts.
const Lead = require('./models/Lead');
const { store } = require('./services/dataService');
const { scoreLead } = require('./services/leadScoring');

async function seedLeads({ force = false } = {}) {
  const existing = await Lead.countDocuments({});
  if (!force && existing === store.leads.length) {
    // Re-score only if the scoring rules changed since the leads were stored (compares one lead as a fingerprint).
    const fresh = scoreLead(store.leads[0]);
    const kept = await Lead.findOne({ leadId: fresh.leadId }).lean();
    if (kept && kept.propensityScore === fresh.propensityScore && kept.recommendedBundle?.name === fresh.recommendedBundle.name) return { seeded: false, count: existing };
  }
  await Lead.deleteMany({});
  const docs = store.leads.map(scoreLead);
  for (let i = 0; i < docs.length; i += 500) await Lead.insertMany(docs.slice(i, i + 500), { ordered: false });
  return { seeded: true, count: docs.length };
}

module.exports = { seedLeads };
