// Connects to MongoDB. Order of preference:
//   1. MONGODB_URI from server/.env (for example a free MongoDB Atlas cluster)
//   2. a MongoDB already running on this computer
//   3. a temporary in-memory MongoDB started automatically (first run downloads it once; data resets on restart)
const mongoose = require('mongoose');
const config = require('./config');

let memoryServer = null;

async function tryConnect(uri, timeoutMs) {
  await mongoose.connect(uri, { serverSelectionTimeoutMS: timeoutMs });
  return uri;
}

async function connect() {
  mongoose.set('strictQuery', true);
  if (config.mongoUri) {
    await tryConnect(config.mongoUri, 8000);
    return { mode: 'MONGODB_URI from .env' };
  }
  try {
    await tryConnect('mongodb://127.0.0.1:27017/udyam_digital', 1500);
    return { mode: 'local MongoDB on this computer (mongodb://127.0.0.1:27017/udyam_digital)' };
  } catch (e) {
    await mongoose.disconnect().catch(() => {});
  }
  console.log('  No MongoDB found on this computer - starting a temporary built-in one.');
  console.log('  (The first run downloads MongoDB once, about 100-500 MB. Please wait a minute or two.)');
  const { MongoMemoryServer } = require('mongodb-memory-server-core');
  memoryServer = await MongoMemoryServer.create({ instance: { dbName: 'udyam_digital' } });
  await tryConnect(memoryServer.getUri('udyam_digital'), 8000);
  return { mode: 'temporary built-in MongoDB (data is cleared when the server stops)' };
}

async function disconnect() {
  await mongoose.disconnect().catch(() => {});
  if (memoryServer) await memoryServer.stop().catch(() => {});
}

module.exports = { connect, disconnect };
