// Central place for every setting. Values come from server/.env (see .env.example).
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env'), quiet: true });

const bool = (v, fallback) => (v === undefined || v === '' ? fallback : String(v).toLowerCase() === 'true');

module.exports = {
  port: Number(process.env.PORT) || 4000,
  mongoUri: (process.env.MONGODB_URI || '').trim(),
  dataDir: process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, '..', '..', 'data'),
  llm: {
    apiKey: (process.env.LLM_API_KEY || process.env.OPENAI_API_KEY || '').trim(),
    baseUrl: (process.env.LLM_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, ''),
    model: process.env.LLM_MODEL || 'gpt-4o-mini',
  },
  partnerAccessCode: process.env.PARTNER_ACCESS_CODE || 'partner-demo',
  kycReferenceDate: process.env.KYC_REFERENCE_DATE || '2026-07-15',
  demoMode: bool(process.env.DEMO_MODE, true),
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  // Privacy note values shown on the consent screen and enforced in code.
  retention: { kycRecordDays: 180, documentImages: 'not stored' },
  consentVersion: '2026-07-v1',
  upload: { maxBytes: 5 * 1024 * 1024, allowedMime: ['image/png', 'image/jpeg'] },
};
