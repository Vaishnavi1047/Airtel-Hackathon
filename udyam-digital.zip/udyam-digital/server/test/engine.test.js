// Quick checks of the rules engine. No database or server needed:  cd server && npm test
const test = require('node:test');
const assert = require('node:assert');
const data = require('../src/services/dataService');
const { validateGstin, repairGstinFromOcr } = require('../src/services/gstin');

test('datasets load with the expected row counts', async () => {
  const s = await data.load();
  assert.equal(s.products.length, 25);
  assert.equal(s.leads.length, 5000);
  assert.equal(s.gstin.size, 3534);
  assert.equal(s.udyam.size, 2723);
});

test('GSTIN check digit: valid passes, typo fails, OCR look-alikes are repaired', () => {
  assert.equal(validateGstin('09DICXE7634A1Z5').valid, true);
  assert.equal(validateGstin('09DICXE7634A1Z6').valid, false);
  assert.equal(repairGstinFromOcr('27XUIXGO767D1ZP').gstin, '27XUIXG0767D1ZP');
});

test('quote uses catalogue prices and blocks ineligible or dependent products', async () => {
  await data.load();
  const { quote } = require('../src/services/catalogue');
  const ok = quote([{ productId: 'P01', qty: 1 }, { productId: 'P19', qty: 1 }, { productId: 'P23', qty: 2 }], { cityTier: 2, employees: 5, sites: 1, hasGstin: true });
  assert.equal(ok.valid, true);
  assert.equal(ok.totals.monthly, 999 + 599 + 199 * 2);   // bottom of each catalogue range for 3+ services
  assert.equal(ok.totals.setup, 2500 + 1800 * 2);
  assert.equal(ok.totals.contractMonths, 12);
  const noLink = quote([{ productId: 'P23', qty: 1 }], { cityTier: 2, employees: 5, sites: 1, hasGstin: true });
  assert.ok(noLink.issues.some((i) => i.code === 'DEPENDENCY'));
  const tier = quote([{ productId: 'P03', qty: 1 }], { cityTier: 2, employees: 5, sites: 1, hasGstin: false });
  assert.deepEqual(tier.issues.map((i) => i.code).sort(), ['CITY_TIER', 'GSTIN']);
});

test('every one of the 5,000 leads gets a valid recommended bundle', async () => {
  await data.load();
  const { recommend, profileFromLead } = require('../src/services/recommender');
  for (const lead of data.store.leads) {
    for (const o of recommend(profileFromLead(lead)).options) assert.ok(o.quote.valid && o.items.length, `invalid bundle for ${lead.leadId}`);
  }
});

test('advisor understands free text in English and Hindi', async () => {
  await data.load();
  const { parseAnswer } = require('../src/services/advisor');
  assert.equal(parseAnswer('businessType', 'Medical store').value, 'pharmacy');
  assert.equal(parseAnswer('employees', 'हम पाँच लोग हैं').value, 5);
  assert.equal(parseAnswer('hasGstin', 'nahi hai').value, false);
  assert.deepEqual(parseAnswer('needs', 'upi billing and cameras').value.sort(), ['cctv', 'pos']);
});
