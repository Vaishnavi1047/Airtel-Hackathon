// End-to-end check against a RUNNING server (npm start in another terminal):  node scripts/e2e.js
// 1) walks the full pharmacy journey, 2) runs every sample applicant (D01, K01-K12) through Smart KYC and prints what was caught.
const fs = require('fs');
const path = require('path');
const BASE = process.env.API || 'http://localhost:4000/api';
const DOCS = path.join(__dirname, '..', '..', 'data', 'kyc_documents');

async function api(method, url, body, headers = {}) {
  const isForm = body instanceof FormData;
  const res = await fetch(BASE + url, { method, headers: isForm ? headers : { 'Content-Type': 'application/json', ...headers }, body: body ? (isForm ? body : JSON.stringify(body)) : undefined });
  const json = await res.json();
  return { status: res.status, ...json };
}
const must = (r, what) => { if (!r.ok) throw new Error(`${what} failed (${r.status}): ${JSON.stringify(r.error)}`); return r.data; };

async function upload(orderId, docType, file) {
  const fd = new FormData();
  fd.append('orderId', orderId); fd.append('docType', docType);
  fd.append('document', new Blob([fs.readFileSync(path.join(DOCS, file))], { type: 'image/png' }), file);
  return api('POST', '/kyc/upload', fd);
}

async function kycRun(app, items, profile) {
  const order = must(await api('POST', '/orders', { businessName: app.businessName, ownerName: app.ownerName, mobile: '9' + String(Math.floor(Math.random() * 1e9)).padStart(9, '0'), email: 'owner@example.com', address: app.address, city: app.city, businessType: app.businessType, bundleName: 'Test bundle', items, profile, paymentConfirmed: true }), 'order');
  must(await api('POST', '/kyc/consent', { orderId: order.orderId, accepted: true }), 'consent');
  const out = { id: app.id, orderId: order.orderId };
  const g = await api('POST', '/kyc/gstin/verify', { orderId: order.orderId, gstin: app.gstin });
  out.gstin = g.ok ? g.data.result.status : `error: ${g.error.message}`;
  if (app.udyam) { const u = await api('POST', '/kyc/udyam/verify', { orderId: order.orderId, udyamNumber: app.udyam }); out.udyam = u.ok ? u.data.result.status : `error: ${u.error.message}`; }
  else { await api('POST', '/kyc/udyam/verify', { orderId: order.orderId, skip: true }); out.udyam = 'Skipped'; }
  for (const t of app.documents) {
    const r = await upload(order.orderId, t, `${app.id}_${t}.png`);
    out[t] = r.ok ? `${r.data.document.status}${r.data.document.status === 'Verified' ? '' : ' - ' + (r.data.document.checks.filter((c) => c.result !== 'pass' && c.result !== 'info').map((c) => c.detail).join(' | ') || r.data.document.message)}` : `blocked: ${r.error.message}`;
  }
  const s = must(await api('GET', `/kyc/${order.orderId}/status`), 'status');
  out.overall = s.kyc.overallStatus; out.orderStatus = s.orderStatus;
  return out;
}

(async () => {
  console.log('--- 1. Judge demo journey: medical store, 5 employees, 1 location ---');
  let chat = must(await api('POST', '/advisor/chat', { action: 'start', lang: 'en' }), 'chat start');
  const answers = ['Medical store', '5', '1', 'Lucknow', 'Home broadband', ['internet', 'pos', 'cctv'], 'yes'];
  for (const a of answers) chat = must(await api('POST', '/advisor/chat', { sessionId: chat.sessionId, ...(Array.isArray(a) ? { value: a } : { message: a }) }), 'chat answer');
  const rec = chat.recommendation; const opt = rec.options.find((o) => o.key === rec.recommendedKey);
  console.log('Recommended:', opt.name.en, '|', opt.quote.lines.map((l) => `${l.name} x${l.qty}`).join(', '), '|', `Rs ${opt.quote.totals.monthly}/mo + Rs ${opt.quote.totals.setup} setup, ${opt.quote.totals.contractMonths} months`);
  const items = [...opt.items.map((i) => ({ productId: i.productId, qty: i.qty })), { productId: opt.addOns[0].productId, qty: opt.addOns[0].qty }];
  const q = must(await api('POST', '/products/quote', { items, profile: rec.profile }), 'quote');
  console.log('With add-on', opt.addOns[0].name, '->', `Rs ${q.totals.monthly}/mo`, 'valid:', q.valid);
  const demo = must(await api('GET', '/demo/applicants')).find((a) => a.id === 'D01');
  const k = await kycRun(demo, items, rec.profile);
  console.log('KYC:', k);
  let o = must(await api('GET', `/orders/${k.orderId}`), 'order');
  console.log('Slots:', o.slotOptions.dates.join(', '));
  o = must(await api('PATCH', `/orders/${k.orderId}/status`, { action: 'schedule', date: o.slotOptions.dates[0], window: o.slotOptions.windows[0] }), 'schedule');
  o = must(await api('PATCH', `/orders/${k.orderId}/status`, { action: 'advance' }), 'advance');
  o = must(await api('PATCH', `/orders/${k.orderId}/status`, { action: 'advance' }), 'advance');
  console.log('Final status:', o.orderStatus, '| stages:', o.stages.map((s) => s.state).join(','));
  if (o.orderStatus !== 'SERVICE_ACTIVATED') throw new Error('Journey did not reach activation');

  console.log('\n--- 2. Smart KYC against every sample applicant ---');
  const basic = [{ productId: 'P01', qty: 1 }, { productId: 'P07', qty: 2 }];
  for (const app of must(await api('GET', '/demo/applicants')).filter((a) => a.id !== 'D01')) console.log(JSON.stringify(await kycRun(app, basic, { cityTier: 2, employees: 5, sites: 1, hasGstin: true }), null, 1));

  console.log('\n--- 3. Guard rails ---');
  const bad = await api('POST', '/products/quote', { items: [{ productId: 'P03', qty: 1 }, { productId: 'P23', qty: 1 }, { productId: 'P21', qty: 1 }], profile: { city: 'Lucknow', employees: 5, sites: 1, hasGstin: false } });
  console.log('Ineligible quote ->', bad.data.valid, bad.data.issues.map((i) => i.en));
  console.log('Dashboard without code ->', (await api('GET', '/dashboard/summary')).status);
  const sum = must(await api('GET', '/dashboard/summary', null, { 'x-partner-code': 'partner-demo' }), 'summary');
  console.log('Baseline:', sum.baseline.totalLeads, sum.baseline.activatedCustomers, (sum.baseline.conversionRate * 100).toFixed(2) + '%', sum.baseline.avgActivationDays.toFixed(1), 'days', 'Rs', Math.round(sum.baseline.acquisitionCostPerCustomer));
  console.log('Leads:', JSON.stringify(sum.leads), JSON.stringify(sum.pipeline));
  const leads = must(await api('GET', '/dashboard/leads?priority=High&limit=5&q=med', null, { 'x-partner-code': 'partner-demo' }), 'leads');
  console.log('Leads page:', leads.total, leads.items.map((l) => `${l.leadId} ${l.businessName} ${l.propensityScore}`));
  const p = must(await api('PATCH', `/dashboard/leads/${leads.items[0].leadId}`, { followUpStatus: 'Sent self-serve link', followUpNote: 'Sent on WhatsApp' }, { 'x-partner-code': 'partner-demo' }), 'patch');
  console.log('Lead update ->', p.followUpStatus);
  console.log('\nAll end-to-end checks completed.');
})().catch((e) => { console.error('\nE2E FAILED:', e.message); process.exit(1); });
