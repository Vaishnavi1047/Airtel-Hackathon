# Udyam Digital: privacy note (1 page)

All data in this prototype is synthetic, but we treated it as if it were real customer data.

**Collect only what each step needs**
- Advisor: business type, size, city, current internet, needs, GSTIN yes/no. No name or phone number is asked until checkout.
- Checkout: business name, owner name, mobile, email, address.
- KYC: GSTIN, Udyam number (optional), and four document photos.

**Consent before KYC**
- The KYC screen opens with a notice covering what is collected, why, how it is processed, how long it is kept and who can see it.
- The server refuses every KYC call (HTTP 403) until consent is recorded with a timestamp and notice version.

**Documents**
- Uploads are held in memory only, limited to one PNG/JPG of up to 5 MB, and checked by file signature as well as declared type.
- After OCR the image is dropped. We store only the few fields read from it, the result of each check and a SHA-256 fingerprint of the file.
- Signatory ID numbers and utility consumer numbers are stored masked (last 3 characters).

**Masking**
- GSTIN, Udyam number, mobile and email are masked in API responses and on screen (for example `09••••••••••1Z5`).
- Server logs contain order IDs and outcomes only, never names or identifiers.
- Sales partners see masked GSTINs; the dashboard sits behind an access code because it shows lead contact names.

**Retention**
- KYC records carry a `purgeAfter` date 180 days after the order and MongoDB deletes them automatically (TTL index).
- Advisor chat sessions live in server memory for 2 hours and are never written to the database.

**What this prototype does not do (and a production service must)**
- Real authentication: an order is opened with its order ID alone, and the partner code is a shared demo secret.
- Encryption at rest, audit logs, a consent-withdrawal screen and a data-deletion request flow.
- Registry checks here use mock CSV files and are not official government verification.
